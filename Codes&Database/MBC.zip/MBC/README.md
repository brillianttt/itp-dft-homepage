# MBC
Molecular Berry Curvature code. This code is only suitable for Quantum Espresso version 7.3.1.

## Install
1. Compile QE 7.3.1 first
2. Copy the files into EPW/src
3. Recompile

