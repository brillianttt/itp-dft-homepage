  !
  ! Copyright (C) 2016-2023 EPW-Collaboration
  ! Copyright (C) 2010-2016 Samuel Ponce', Roxana Margine, Carla Verdi, Feliciano Giustino
  ! Copyright (C) 2007-2009 Jesse Noffsinger, Brad Malone, Feliciano Giustino
  !
  ! This file is distributed under the terms of the GNU General Public
  ! License. See the file `LICENSE' in the root directory of the
  ! present distribution, or http://www.gnu.org/copyleft.gpl.txt .
  !
  !----------------------------------------------------------------------
  SUBROUTINE ephberry_shuffle(nqc, xqc, w_centers)
  !---------------------------------------------------------------------
  !!
  !! Wannier interpolation of electron-phonon vertex
  !!
  !! The routine is divided in two parts.
  !! 1) Full coarse grid to real-space Wannier transformation
  !! 2) Real-space Wannier to fine grid Bloch space interpolation
  !-----------------------------------------------------------------------
  !
  USE kinds,            ONLY : DP, i4b, i8b
  USE pwcom,            ONLY : nbnd, nks, nkstot, ef, nelec
  USE klist_epw,        ONLY : et_loc, xk_loc, isk_dummy
  USE cell_base,        ONLY : at, bg
  USE ions_base,        ONLY : nat, amass, ityp, tau
  USE modes,            ONLY : nmodes
  USE epw_stop,         ONLY : ephf_deallocate
  USE epwcom,           ONLY : nbndsub, fsthick, epwread, system_2d, plrn,         &
                               epwwrite, ngaussw, degaussw, lpolar, lifc, lscreen, &
                               etf_mem, scr_typ, nw_specfun, loptabs,              &
                               elecselfen, phonselfen, nest_fn, a2f, specfun_ph,   &
                               vme, eig_read, ephwrite, elecselfen_ahc,            &
                               efermi_read, fermi_energy, specfun_el, band_plot,   &
                               scattering, nstemp, int_mob, scissor, carrier,      &
                               iterative_bte, longrange, scatread, nqf1, prtgkk,   &
                               nqf2, nqf3, mp_mesh_k, restart, plselfen,           &
                               specfun_pl, lindabs, use_ws, epbread, fermi_plot,   &
                               epmatkqread, restart_step, nsmear, ii_partion,      &
                               nqc1, nqc2, nqc3, nkc1, nkc2, nkc3, assume_metal,   &
                               eliashberg, meshnum, time_rev_U_plrn, wfpt,         &
                               ii_g, start_mesh, ii_lscreen, molecular_berry_calc, &
                               mbc_write_am, mbc_accustic_limit, mbc_smearing, nkf1, nkf2, nkf3, &
                               MBC_phonself_calc, mbc_k_diss_calc ! ZS added
  USE control_flags,    ONLY : iverbosity
  USE noncollin_module, ONLY : noncolin
  USE constants_epw,    ONLY : ryd2ev, ryd2mev, one, two, zero, czero, eps40, cone,&
                               twopi, ci, kelvin2eV, eps6, eps8, eps10, eps12, eps14, eps16, byte2Mb
  USE io_files,         ONLY : prefix, diropn, tmp_dir
  USE io_global,        ONLY : stdout, ionode
  USE io_var,           ONLY : iunepmatwe, iunepmatwp, iuntaucb,                   &
                               iunepmatwp2, iunrestart, iuntau, iuntaucb

  ! ZS added wf1r, wf1i
  USE elph2,            ONLY : cu, cuq, lwin, lwinq,                               &
                               chw, chw_ks, cvmew, cdmew, rdw, adapt_smearing,     &
                               epmatwp, epmatq, wf, wff, wff1, wf1r, wf1i, ideg_map, igroups, etf, etf_ks, xqf, xkf,         &
                               wkf, dynq, nqtotf, nkqf, epf17, nkf, nqf, et_ks,    &
                               ibndmin, ibndmax, lambda_all, dmec, dmef, vmef,     &
                               sigmai_all, sigmai_mode, gamma_all, epsi, zstar,    &
                               efnew, sigmar_all, zi_all, nkqtotf, eps_rpa,        &
                               sigmar_all, zi_allvb, inv_tau_all, eta, nbndfst,    &
                               inv_tau_allcb, zi_allcb, exband, gamma_v_all,       &
                               esigmar_all, esigmai_all, lower_bnd, upper_bnd,     &
                               a_all, a_all_ph, wscache, lambda_v_all,             &
                               nktotf, gtemp, xkq, dos, nbndskip, nbndep,          &
                               qrpl, Qmat, ef0_fca, selecq, emib3tz,               &
                               epsilon2_abs_all, epsilon2_abs_lorenz_all, crrw,    &
                               eimpf17, epstf_therm, qtf2_therm, partion, eta_imp, &
                               sum_E, E_grid, maxdim, dwf17, sigma_ahc_hdw,        &
                               sigma_ahc_act, sigma_ahc_uf, sigma_ahc_ldw, totq,   &
                               MBC, Nesting_q, ufe_allq, ufe1_allq, MBC_Gamma_total, epf17_plane, kplane, etf_plane, &
                               ikp_loc, ikp_loc_begin, ikp_loc_end, nkp_total, nkp_local, rest_kp, UF_GAMMA, UF_GAMMA_DATA ! ZS added
  USE wan2bloch,        ONLY : dmewan2bloch, hamwan2bloch, dynwan2bloch,           &
                               ephwan2blochp, ephwan2bloch, vmewan2bloch,          &
                               dynifc2blochf, vmewan2blochp, rrwan2bloch,          &
                               dwwan2blochp, sthwan2blochp, dgwan2blochp
  USE bloch2wan,        ONLY : hambloch2wan, dmebloch2wan, dynbloch2wan,           &
                               vmebloch2wan, ephbloch2wane, ephbloch2wanp,         &
                               ephbloch2wanp_mem
  USE wigner,           ONLY : wigner_seitz_wrap
  USE io_eliashberg,    ONLY : write_ephmat, count_kpoints, kmesh_fine, kqmap_fine,&
                               check_restart_ephwrite, write_dos, write_phdos,     &
                               file_open_ephmat
  USE transport,        ONLY : transport_coeffs, scattering_rate_q
  USE grid,             ONLY : qwindow_wrap, loadkmesh_fst, xqf_otf
  USE printing,         ONLY : print_gkk, plot_band, plot_fermisurface
  USE io_epw,           ONLY : rwepmatw, epw_read, epw_write
  USE io_transport,     ONLY : tau_read, iter_open, print_ibte, iter_merge
  USE io_selfen,        ONLY : selfen_el_read, spectral_read, selfen_ph_write
  USE transport_iter,   ONLY : iter_restart, transport_setup, transport_restart
  USE close_epw,        ONLY : iter_close
  USE division,         ONLY : fkbounds
  USE mp,               ONLY : mp_barrier, mp_bcast, mp_sum
  USE io_global,        ONLY : ionode_id, stdout
  USE mp_global,        ONLY : inter_pool_comm, npool, my_pool_id
  USE mp_world,         ONLY : mpime, world_comm
  USE low_lvl,          ONLY : system_mem_usage, mem_size
  USE utilities,        ONLY : compute_dos, broadening, fermicarrier, fermiwindow, &
                               calcpartion, broadening_imp, fermiwindow_kplane ! ZS added
  USE grid,             ONLY : loadqmesh_serial, loadkmesh_para, load_rebal
  USE selfen,           ONLY : selfen_phon_q, selfen_elec_q, selfen_pl_q,          &
                               nesting_fn_q, MBC_phon_q, write_MBC, write_uf_phonon,  & 
                               calc_am_of_phonon, plot_band_mbc, eigensystem_c, Nesting_phon_q, & 
                               write_mbc_nesting, selfen_phon_q_MBC, MBC_diss_k, write_MBC_k_diss ! ZS added
  USE spectral_func,    ONLY : spectral_func_el_q, spectral_func_ph_q, a2f_main,   &
                               spectral_func_pl_q
  USE rigid_epw,        ONLY : rpa_epsilon, tf_epsilon, calc_qtf2_therm,           &
                               rgd_imp_epw_fine, calc_epstf_therm, epsi_thickn_2d, &
                               compute_umn_f, rgd_blk_epw_fine_sh
  USE indabs,           ONLY : indabs_main, renorm_eig, fermi_carrier_indabs,      &
                               prepare_indabs
  USE io_indabs,        ONLY : indabs_read
  USE polaron,          ONLY : plrn_flow_select, plrn_prepare, plrn_save_g_to_file,&
                               is_mirror_q, is_mirror_k, kpg_map, ikq_all
  USE qdabs,            ONLY : qdabs_main, prepare_qdabs
  USE wfpt_mod,         ONLY : wfpt_bloch2wan_setup, wfpt_bloch2wan_iq,            &
                               wfpt_bloch2wan_finalize, wfpt_wan2bloch_setup
  USE selfen_ahc,       ONLY : selfen_elec_ahc_active, compute_dw_truncated,       &
                               ahc_run_static_wfpt, selfen_print
#if defined(__MPI)
  USE parallel_include, ONLY : MPI_MODE_RDONLY, MPI_INFO_NULL, MPI_OFFSET_KIND,    &
                               MPI_OFFSET
#endif
  !
  IMPLICIT NONE
  !
  INTEGER, INTENT(in) :: nqc
  !! number of qpoints in the coarse grid
  REAL(KIND = DP), INTENT(in) :: xqc(3, nqc)
  !! qpoint list, coarse mesh
  REAL(KIND = DP), INTENT(inout) :: w_centers(3, nbndsub)
  !! Wannier centers
  !
  ! Local variables
  CHARACTER(LEN = 256) :: filint
  !! Name of the file to write/read
  LOGICAL :: already_skipped
  !! Skipping band during the Wannierization
  LOGICAL :: exst
  !! If the file exist
  LOGICAL :: first_cycle
  !! Check wheter this is the first cycle after a restart.
  LOGICAL :: first_q
  !! Check if this is the first q point
  LOGICAL :: mirror_k
  !! Mirror symmetry for k-points
  LOGICAL :: mirror_q
  !! Mirror symmetry for q-points
  LOGICAL :: mirror_kpq
  !! Mirror symmetry for (k+q)-points
  INTEGER :: ios
  !! INTEGER variable for I/O control
  INTEGER :: iq
  !! Counter on coarse q-point grid
  INTEGER :: iqq
  !! Counter on coarse q-point grid
  INTEGER :: iq_restart
  !! Counter on coarse q-point grid
  INTEGER :: qind
  !! Index of q-point either on full q-grid or within qwindow
  INTEGER :: ik
  !! Counter on coarse k-point grid
  INTEGER :: ikk
  !! Counter on k-point when you have paired k and q
  INTEGER :: ikq
  !! Paired counter so that q is adjacent to its k
  INTEGER :: ibnd
  !! Counter on band
  INTEGER :: jbnd
  !! Counter on band
  INTEGER :: imode
  !! Counter on mode
  INTEGER :: na
  !! Counter on atom
  INTEGER :: mu
  !! counter on mode
  INTEGER :: nu
  !! counter on mode
  INTEGER :: fermicount
  !! Number of states at the Fermi level
  INTEGER :: lrepmatw
  !! record length while reading file
  INTEGER :: ir
  !! Counter for WS loop
  INTEGER :: nrws
  !! Number of real-space Wigner-Seitz
  INTEGER :: valueRSS(2)
  !! Return virtual and resisdent memory from system
  INTEGER :: ierr
  !! Error status
  INTEGER :: nrr_k
  !! Number of WS points for electrons
  INTEGER :: nrr_q
  !! Number of WS points for phonons
  INTEGER :: nrr_g
  !! Number of WS points for electron-phonons
  INTEGER :: dims
  !! Dims is either nbndsub if use_ws or 1 if not
  INTEGER :: dims2
  !! Dims is either nat if use_ws or 1 if not
  INTEGER :: iw
  !! Counter on bands when use_ws == .TRUE.
  INTEGER :: iw2
  !! Counter on bands when use_ws == .TRUE.
  INTEGER :: itmp, jtmp
  !! Temperate index
  INTEGER :: icbm
  !! Index of the CBM
  INTEGER :: ipool
  !! Cpu index.
  INTEGER :: npool_tmp
  !! Temporary number of pools
  INTEGER :: ctype
  !! Calculation type: -1 = hole, +1 = electron and 0 = both.
  INTEGER :: QD_mesh
  !! mesh index for quasidegenerate perturbation
  INTEGER :: mesh_dum, mesh_leng
  !! mesh dummy index for quasidegenerate perturbation
  INTEGER :: cycle_quad
  !! building Hamiltonian or performing calculation
  INTEGER :: nc = 1
  !! Index of the outer interpolation loop
  INTEGER*8 :: unf_recl
  !! Record length
  INTEGER :: direct_io_factor
  !! Type of IOlength
  INTEGER :: ideg_count  ! ZS added
  !! Conter for the degeneracy
  INTEGER :: idg  ! ZS added
  !! idex for the degeneracy groups
  INTEGER :: ndg  ! ZS added
  !! degeneracy 
  INTEGER :: info ! ZS added
  !! diagonalization infomation
  INTEGER :: ifail ! ZS added
  !! fail infomation
  INTEGER :: iunit_wsndeg! ZS added
  !! fail infomation
  INTEGER :: lrepmatw2_restart(npool)
  !! To restart opening files
  INTEGER :: lrepmatw5_restart(npool)
  !! To restart opening files
  INTEGER, ALLOCATABLE :: irvec_k(:, :)
  !! Integer components of the ir-th Wigner-Seitz grid point in the basis
  !! of the lattice vectors for electrons
  INTEGER, ALLOCATABLE :: irvec_q(:, :)
  !! INTEGER components of the ir-th Wigner-Seitz grid point for phonons
  INTEGER, ALLOCATABLE :: irvec_g(:, :)
  !! INTEGER components of the ir-th Wigner-Seitz grid point for electron-phonon
  INTEGER, ALLOCATABLE :: ndegen_k(:, :, :)
  !! Wigner-Seitz number of degenerescence (weights) for the electrons grid
  INTEGER, ALLOCATABLE :: ndegen_q(:, :, :)
  !! Wigner-Seitz weights for the phonon grid that depend on atomic positions $R + \tau(nb) - \tau(na)$
  INTEGER, ALLOCATABLE :: ndegen_g(:, :, :)
  !! Wigner-Seitz weights for the electron-phonon grid that depend on
  !! atomic positions $R - \tau(na)$
  INTEGER, PARAMETER :: nrwsx = 200
  !! Maximum number of real-space Wigner-Seitz
#if defined(__MPI)
  INTEGER(KIND = MPI_OFFSET_KIND) :: ind_tot
  !! Total number of points store on file
  INTEGER(KIND = MPI_OFFSET_KIND) :: ind_totcb
  !! Total number of points store on file (CB)
#else
  INTEGER(KIND = 8) :: ind_tot
  !! Total number of points store on file
  INTEGER(KIND = 8) :: ind_totcb
  !! Total number of points store on file (CB)
#endif
  REAL(KIND = DP) :: xxq(3)
  !! Current q-point
  REAL(KIND = DP) :: xxk(3)
  !! Current k-point on the fine grid
  REAL(KIND = DP) :: xkk(3)
  !! Current k-point on the fine grid
  REAL(KIND = DP) :: xkq2(3)
  !! Current k+q point on the fine grid
  REAL(KIND = DP) :: rws(0:3, nrwsx)
  !! Real-space wigner-Seitz vectors
  REAL(KIND = DP) :: atws(3, 3)
  !! Maximum vector: at*nq
  REAL(KIND = DP) :: etemp
  !! Temperature in Ry (this includes division by kb)
  REAL(KIND = DP) :: etemp_fca
  !! Temperature for free carrier absorption
  REAL(KIND = DP) :: ef0(nstemp)
  !! Fermi level for the temperature itemp
  REAL(KIND = DP) :: efcb(nstemp)
  !! Second Fermi level for the temperature itemp
  REAL(KIND = DP) :: dummy(3)
  !! Dummy variable
  REAL(KIND = DP) :: valmin(npool)
  !! Temporary broadening min value
  REAL(KIND = DP) :: valmax(npool)
  !! Temporary broadening max value
  REAL(KIND = DP) :: xxq_r(3)
  !! Q-points
  REAL(KIND = DP), EXTERNAL :: efermig
  !! External function to calculate the fermi energy
  REAL(KIND = DP), ALLOCATABLE :: etf_all(:, :)
  !! Eigen-energies on the fine grid collected from all pools in parallel case
  REAL(KIND = DP), ALLOCATABLE :: w2(:)
  !! Interpolated phonon frequency
  REAL(KIND = DP), ALLOCATABLE :: irvec_r(:, :)
  !! Wigner-Size supercell vectors, store in real instead of integer
  REAL(KIND = DP), ALLOCATABLE :: rdotk(:)
  !! $r\cdot k$
  REAL(KIND = DP), ALLOCATABLE :: rdotk2(:)
  !! $r\cdot k$
  REAL(KIND = DP), ALLOCATABLE :: wslen_k(:)
  !! real-space length for electrons, in units of alat
  REAL(KIND = DP), ALLOCATABLE :: wslen_q(:)
  !! real-space length for phonons, in units of alat
  REAL(KIND = DP), ALLOCATABLE :: wslen_g(:)
  !! real-space length for electron-phonons, in units of alat
  COMPLEX(KIND = DP), ALLOCATABLE :: epmatwe(:, :, :, :, :)
  !! e-p matrix  in wannier basis - electrons
  COMPLEX(KIND = DP), ALLOCATABLE :: epmatwe_mem(:, :, :, :)
  !! e-p matrix  in wannier basis - electrons (written on disk)
  COMPLEX(KIND = DP), ALLOCATABLE :: epmatwef(:, :, :, :)
  !! e-p matrix  in el wannier - fine Bloch phonon grid
  COMPLEX(KIND = DP), ALLOCATABLE :: epmatf(:, :, :)
  !! e-p matrix  in smooth Bloch basis, fine mesh
  COMPLEX(KIND = DP), ALLOCATABLE :: cufkk(:, :)
  !! Rotation matrix, fine mesh, points k
  COMPLEX(KIND = DP), ALLOCATABLE :: cufkq(:, :)
  !! the same, for points k+q

  COMPLEX(KIND = DP), ALLOCATABLE :: uf(:, :)
  !! Rotation matrix for phonons


  COMPLEX(KIND = DP), ALLOCATABLE :: ufe(:, :)  ! ZS added
  !! Rotation matrix for phonons uf = (1/\sqrt{m1 m2}) ufe

  COMPLEX(KIND = DP), ALLOCATABLE :: ufe_sub(:, :)  ! ZS added
  !! subspace of the 

  COMPLEX(KIND = DP), ALLOCATABLE :: uf1(:, :)  ! ZS added
  !! Rotation matrix for phonons ! ZS added
  !! (First order correction, For the non-degenerated states, we suppose this correction is zero) ! ZS added

  COMPLEX(KIND = DP), ALLOCATABLE :: Dyn1(:, :)  ! ZS added
  !! Rotation matrix for phonons ! ZS added
  !! (First order correction, For the non-degenerated states, we suppose this correction is zero) ! ZS added


  COMPLEX(KIND = DP), ALLOCATABLE :: cfac(:, :, :)
  !! Used to store $e^{2\pi r \cdot k}$ exponential
  COMPLEX(KIND = DP), ALLOCATABLE :: cfacq(:, :, :)
  !! Used to store $e^{2\pi r \cdot k+q}$ exponential
  COMPLEX(KIND = DP), ALLOCATABLE :: vmefp(:, :, :)
  !! Phonon velocity
  COMPLEX(KIND = DP), ALLOCATABLE :: tmp(:, :, :)
  !! Overlap k and k+q
  COMPLEX(KIND = DP), ALLOCATABLE :: A(:, :, :, :)
  !! Berry connection in Wannier representation
  COMPLEX(KIND = DP), ALLOCATABLE :: rrf(:, :, :)
  !! Interpolation position matrix elements on the fine mesh (ipol, nbnd, nbnd)
  COMPLEX(KIND = DP), ALLOCATABLE :: eimpmatf(:, :)
  !! carrier-ionized impurity matrix in smooth Bloch basis
  COMPLEX(KIND = DP), ALLOCATABLE :: bmatf(:, :)
  !! overlap U_k+q U_k^\dagger in smooth Bloch basis, fine mesh

  !! ZS added begin
  INTEGER :: im_last  ! the last index of the a  phonon degeneracy group
  INTEGER :: im_low   ! the first index of the a phonon degeneracy group
  INTEGER :: neigfound ! ZS added

  REAL(KIND = DP), ALLOCATABLE :: wDeg(:)      ! eigenvalues of DegeneDyn
  REAL(KIND = DP) :: ww0  ! ZERO order of the frequency^2 of some phonon
  REAL(KIND = DP) :: ww1 ! The modified frequency^2 of some phonon mode
  REAL(KIND = DP) :: ww ! The modified frequency^2 of some phonon mode

  !! for non-degenerate case
  COMPLEX(KIND = DP), ALLOCATABLE :: uf_tmp1(:) ! tmp wave function
  COMPLEX(KIND = DP), ALLOCATABLE :: uf_tmp2(:) ! tmp wave function


  !! for degenerate case
  COMPLEX(KIND = DP), ALLOCATABLE :: DegenDyn(:, :)  ! ZS added
  COMPLEX(KIND = DP), ALLOCATABLE :: ufDeg(:, :)     ! eigenvectors of DegeneDyn
  COMPLEX(KIND = DP), ALLOCATABLE :: uf_mat1(:, :)  ! ZS added
  COMPLEX(KIND = DP), ALLOCATABLE :: uf_mat2(:, :)  ! ZS added
  COMPLEX(KIND = DP), ALLOCATABLE :: uf_mat3(:, :)  ! ZS added

  !! ZS added for MBC(Gamma, k , k) distribution on electron BZ
  INTEGER :: iunitkplanefile
  INTEGER :: iunitufgammafile
  REAL(KIND = DP) :: uf_re, uf_im ! The modified frequency^2 of some phonon mode
  

  !! ZS added end
! 
!   !!! ZS DEBUG
!   INTEGER, DIMENSION(4):: max_index
!   INTEGER, DIMENSION(3):: max_index3
!   REAL(KIND = DP) :: max_val_real

  CALL start_clock('ephberry')

  !  ZS added: We are going to calculate the properties related to Molecular Berry Cuvature
  WRITE(stdout, '(/,5x,a)' ) ' We are going to calculate the properties related to MO Berry Phase related properties. '
  !
  IF (nbndsub /= nbndep) WRITE(stdout, '(/,5x,a,i4)' ) 'Band disentanglement is used: nbndsub = ', nbndsub
  !
  IF (.NOT. (epwread .AND. .NOT. epbread)) THEN
    ! ZS added
    CALL errore('ephberry_shuffle', 'Only epwread = TRUE is prohibit', 1)
  ENDIF


  !
  ALLOCATE(w2(3 * nat), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating w2', 1)
  w2(:) = zero
  !
  IF (lpolar) THEN
    ! ZS added
    CALL errore('ephberry_shuffle', 'Do not suppose lpolar = .true. now', 1)
  ENDIF

  IF (.NOT. epwread) THEN
    ! ZS added
    CALL errore('ephberry_shuffle', 'We only allow you calculate the Molecular Berry cuvature after you have done the wannierization,\n and read the corresponding quantities', 1)
  ENDIF

  IF (use_ws) THEN
    ! Use Wannier-centers to contstruct the WS for electonic part and el-ph part
    ! Use atomic position to contstruct the WS for the phonon part
    ! ZS added: Check debug
    WRITE(stdout, '(5x,a)' )    'MBC: We use Wannier centers to construct WS cell'
    dims  = nbndsub
    dims2 = nat
    CALL wigner_seitz_wrap(nkc1, nkc2, nkc3, nqc1, nqc2, nqc3, irvec_k, irvec_q, irvec_g, &
                           ndegen_k, ndegen_q, ndegen_g, wslen_k, wslen_q, wslen_g, &
                           w_centers, dims, tau, dims2)
  ELSE
    ! Center the WS at Gamma for electonic part, the phonon part and el-ph part
    WRITE(stdout, '(5x,a)' )    'MBC: We do not use Wannier centers to construct WS cell'
    dims  = 1
    dims2 = 1
    dummy(:) = (/0.0, 0.0, 0.0/)
    CALL wigner_seitz_wrap(nkc1, nkc2, nkc3, nqc1, nqc2, nqc3, irvec_k, irvec_q, irvec_g, &
                           ndegen_k, ndegen_q, ndegen_g, wslen_k, wslen_q, wslen_g, &
                           dummy, dims, dummy, dims2)
  ENDIF

  ! ZS debug: write the ndegen_k




  !
  ! Determine the size of the respective WS sets based on the length of the matrices
  nrr_k = SIZE(irvec_k(1, :))
  nrr_q = SIZE(irvec_q(1, :))
  nrr_g = SIZE(irvec_g(1, :))
  IF (use_ws) THEN
    WRITE(stdout, '(5x,a)' )    'Construct the Wigner-Seitz cell using Wannier centers and atomic positions '
    WRITE(stdout, '(5x,a,i8)' ) 'Number of WS vectors for electrons ',nrr_k
    WRITE(stdout, '(5x,a,i8)' ) 'Number of WS vectors for phonons ',nrr_q
    WRITE(stdout, '(5x,a,i8)' ) 'Number of WS vectors for electron-phonon ',nrr_g
    WRITE(stdout, '(5x,a,i8)' ) 'Maximum number of cores for efficient parallelization ',nrr_g * nat
  ELSE
    WRITE(stdout, '(5x,a)' )    'Use zone-centred Wigner-Seitz cells '
    WRITE(stdout, '(5x,a,i8)' ) 'Number of WS vectors for electrons ',nrr_k
    WRITE(stdout, '(5x,a,i8)' ) 'Number of WS vectors for phonons ',nrr_q
    WRITE(stdout, '(5x,a,i8)' ) 'Number of WS vectors for electron-phonon ',nrr_g
    WRITE(stdout, '(5x,a,i8)' ) 'Maximum number of cores for efficient parallelization ',nrr_g * nmodes
    WRITE(stdout, '(5x,a)' )    'Results may improve by using use_ws == .TRUE. '
  ENDIF
  !


  ! At this point, we will interpolate the Wannier rep to the Bloch rep
  IF (epwread .AND. .NOT. epbread) THEN
    !
    CALL epw_read(nrr_k, nrr_q, nrr_g)
  ELSE !if not epwread (i.e. need to calculate fmt file)
    CALL errore('ephberry_shuffle', 'MO Berry calculation request epwread = .true. currently', 1)
    !
  ENDIF ! (epwread .AND. .NOT. epbread)
  !
  ! Check Memory usage
  CALL system_mem_usage(valueRSS)
  !
  WRITE(stdout, '(a)' )             '     ==================================================================='
  WRITE(stdout, '(a,i10,a)' ) '     Memory usage:  VmHWM =',valueRSS(2)/1024,'Mb'
  WRITE(stdout, '(a,i10,a)' ) '                   VmPeak =',valueRSS(1)/1024,'Mb'
  WRITE(stdout, '(a)' )             '     ==================================================================='
  WRITE(stdout, '(a)' )             '     '
  !
  ! At this point, we will interpolate the Wannier rep to the Bloch rep
  ! for electrons, phonons and the ep-matrix
  !
  ! Load the fine-grid q and k grids (nkqtotf is computed inside).
  ! The k-point mapping between BZ and IBZ is allocated and computed here as well bztoibz and s_bztoibz
  ! etf_mem == 3 is a special optimization level to deal with ultra dense fine homogeneous grids.

  IF (etf_mem == 3) THEN
    CALL errore('ephberry_shuffle', 'MOC forbiden etf_mem == 3', 1)
  ENDIF


  ! ZS: Check change the order influence.  Results: Nothing happens
  ! CALL loadqmesh_serial()
  CALL loadkmesh_para()
  CALL loadqmesh_serial()

  IF (mpime == ionode_id) THEN
    WRITE(stdout, '(5x, "The Original q points for MBC are: ")')
    DO itmp = 1, nqtotf
      WRITE(stdout, '(5x, 3f20.5)') xqf(:, itmp)
    ENDDO
  ENDIF

  !! ZS: NOTE!!!!
  !! From now, I will change the xqf(:), which containing the q list of phonons. 
  !! For this, it just be cause in the presence of time-reversal symmetry, 
  !! The 1-weight MBC should be zero (See coding note.)
  !! But if the k and k+q points are not in the same mesh, the time-reversal symmetry could be breaking for 
  !! numerical error, and need large of nk1, nk2, nk3 to get a convergent result and keep the time-reversal symmetry.
  DO itmp = 1, nqtotf
    xqf(:, itmp) = xqf(:, itmp)
    xqf(1, itmp) = NINT(xqf(1, itmp)*DBLE(nkf1)) / DBLE(nkf1)
    xqf(2, itmp) = NINT(xqf(2, itmp)*DBLE(nkf2)) / DBLE(nkf2)
    xqf(3, itmp) = NINT(xqf(3, itmp)*DBLE(nkf3)) / DBLE(nkf3)
  ENDDO



  IF (mpime == ionode_id) THEN
    WRITE(stdout, '(5x, "The Modified q points for MBC are: ")')
    WRITE(stdout, '(5x, "nkf1, 2, 3 are: ", 3I8)') nkf1, nkf2, nkf3
    ! WRITE(stdout, '(5x, "DBLE(NINT(0.5*21))/DBLE(21)", f20.5)'),  NINT(0.5*DBLE(21)) / DBLE(21) ! For Debug
    DO itmp = 1, nqtotf
      WRITE(stdout, '(5x, 3f20.5)') xqf(:, itmp)
    ENDDO
  ENDIF


  ALLOCATE(wf(nmodes, nqtotf), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating wf', 1)

  ! Defines the total number of k-points
  nktotf = nkqtotf / 2   
  ! ZS added: In the ephberry_shuffule subroutine, We loop q point. and for each q, point, each k has a image k+q
  ! ZS added: thus the nktotf = nkqtotf / 2
  ! ZS added: the k mesh list is also organized as this, i.e., 
  ! ZS added: for a certain q, k, k+q list is [k1, k1+q, k2, k2+q, ... , kn, kn+q]

  ALLOCATE(epmatwef(nbndsub, nbndsub, nrr_k, nmodes), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating epmatwef', 1)
  ALLOCATE(etf(nbndsub, nkqf), STAT = ierr)    ! ZS added: The first time that etf be allocated, iterpolated electron energy (num_wann, nkqf)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating etf', 1)
  ALLOCATE(etf_ks(nbndsub, nkqf), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating etf_ks', 1)
  ALLOCATE(epmatf(nbndsub, nbndsub, nmodes), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating epmatf', 1)
  ALLOCATE(eimpmatf(nbndsub, nbndsub), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating eimpmatf', 1)
  ALLOCATE(cufkk(nbndsub, nbndsub), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating cufkk', 1)
  ALLOCATE(cufkq(nbndsub, nbndsub), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating cufkq', 1)
  ALLOCATE(uf(nmodes, nmodes), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating uf', 1)

  ALLOCATE(eps_rpa(nmodes), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating eps_rpa', 1)
  ALLOCATE(epstf_therm(nstemp), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating epstf_therm', 1)
  ALLOCATE(isk_dummy(nkqf), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating isk_dummy', 1)
  ALLOCATE(bmatf(nbndsub, nbndsub), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating bmatf', 1)



  ! ZS added
  ALLOCATE(uf1(nmodes, nmodes), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating uf1', 1)

  ALLOCATE(ufe(nmodes, nmodes), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating ufe', 1)

  ALLOCATE(ufe_allq(nmodes, nmodes, nqtotf), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating ufe_allq', 1)

  ALLOCATE(ufe1_allq(nmodes, nmodes, nqtotf), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating ufe1_allq', 1)

  ALLOCATE(Dyn1(nmodes, nmodes), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating Dyn1', 1)

  ! ZS added
  ALLOCATE(MBC(nmodes, nmodes, nqtotf), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating MBC', 1)
  MBC(:,:,:) = czero

  ALLOCATE(Nesting_q(nqtotf), STAT = ierr)
  IF (ierr /= 0) CALL errore('Nesting_phon_q', 'Error allocating Nesting_q', 1)
  Nesting_q(:) = zero


  ! ZS added
  ALLOCATE(wff(nmodes, nqtotf), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating wff', 1)

  ! ZS added
  ALLOCATE(wff1(nmodes, nqtotf), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating wff1', 1)

  ! ZS added
  ALLOCATE(wf1r(nmodes, nqtotf), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating wf1r', 1)

  ! ZS added
  ALLOCATE(wf1i(nmodes, nqtotf), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating wf1i', 1)

  ! ZS added
  ALLOCATE(ideg_map(nmodes, nqtotf), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating ideg_map', 1)


  ! ZS added
  ALLOCATE(uf_tmp1(nmodes), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating uf_tmp1', 1)
  ALLOCATE(uf_tmp2(nmodes), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating uf_tmp2', 1)

  ! ZS added
  ALLOCATE(igroups(nqtotf), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating igroups', 1)




  epmatwef(:, :, :, :) = czero
  etf(:, :)            = zero
  etf_ks(:, :)         = zero
  epmatf(:, :, :)      = czero
  eimpmatf(:, :)       = czero
  cufkk(:, :)          = czero
  cufkq(:, :)          = czero
  uf(:, :)             = czero
  uf1(:, :)            = czero ! ZS added
  ufe(:, :)            = czero ! ZS added
  ufe_allq(:, :, :)    = czero ! ZS added
  ufe1_allq(:, :, :)    = czero ! ZS added
  Dyn1(:, :)           = czero ! ZS added

  wf(:, :) = zero
  wff(:, :) = czero  ! ZS added
  wff1(:, :) = czero ! ZS added
  wf1r(:, :) = zero ! ZS added
  wf1i(:, :) = zero ! ZS added
  ideg_map(:,:) = 0 ! ZS added
  igroups(:) = 0


  eps_rpa(:)           = czero
  epstf_therm(:)       = zero
  isk_dummy(:)         = 0
  bmatf(:, :)          = czero



  ! Allocate velocity and dipole matrix elements after getting grid size
  IF (vme == 'wannier') THEN
     ALLOCATE(vmef(3, nbndsub, nbndsub, 2 * nkf), STAT = ierr)
     IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating vmef', 1)
     vmef(:, :, :, :) = czero
  ELSE
    ALLOCATE(dmef(3, nbndsub, nbndsub, 2 * nkf), STAT = ierr)
    IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating dmef', 1)
    dmef(:, :, :, :) = czero
  ENDIF
  !
  ALLOCATE(rrf(3, nbndsub, nbndsub), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating rrf', 1)
  rrf(:, :, :) = czero
  ALLOCATE(cfac(nrr_k, dims, dims), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating cfac', 1)
  ALLOCATE(cfacq(nrr_k, dims, dims), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating cfacq', 1)
  ALLOCATE(rdotk(nrr_k), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating rdotk', 1)
  ALLOCATE(rdotk2(nrr_k), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating rdotk2', 1)
  ! This is simply because dgemv take only real number (not integer)
  ALLOCATE(irvec_r(3, nrr_k), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating irvec_r', 1)
  irvec_r = REAL(irvec_k, KIND = DP)
  !
  ! Zeroing everything - initialization is important !
  cfac(:, :, :)  = czero
  cfacq(:, :, :) = czero
  rdotk(:)       = zero
  rdotk2(:)      = zero
  !
  ! ------------------------------------------------------
  ! Hamiltonian : Wannier -> Bloch (preliminary)
  ! ------------------------------------------------------
  !
  ! We here perform a preliminary interpolation of the hamiltonian
  ! in order to determine the fermi window ibndmin:ibndmax for later use.
  ! We will interpolate again afterwards, for each k and k+q separately
  !
  xxq = 0.d0
  !
  ! nkqf is the number of kpoints in the pool
  DO ik = 1, nkqf
    !
    xxk = xkf(:, ik)
    ! DEBUG
    WRITE(stdout, '(5x, a, 3f15.5)' ) 'xkk_is = ', xxk
    !
    IF (2 * (ik / 2) == ik) THEN
      !
      !  this is a k+q point : redefine as xkf (:, ik-1) + xxq
      !
      CALL cryst_to_cart(1, xxq, at, -1)
      xxk = xkf(:, ik - 1) + xxq
      CALL cryst_to_cart(1, xxq, bg, 1)
      !
    ENDIF
    !
    ! SP: Compute the cfac only once here since the same are use in both hamwan2bloch and dmewan2bloch
    ! + optimize the 2\pi r\cdot k with Blas
    CALL DGEMV('t', 3, nrr_k, twopi, irvec_r, 3, xxk, 1, 0.0_DP, rdotk, 1)
    !
    DO iw = 1, dims
      DO iw2 = 1, dims
        DO ir = 1, nrr_k
          IF (ndegen_k(ir, iw2, iw) > 0) cfac(ir, iw2, iw) = EXP(ci * rdotk(ir)) / ndegen_k(ir, iw2, iw)
        ENDDO
      ENDDO
    ENDDO
    !
    CALL hamwan2bloch(nbndsub, nrr_k, cufkk, etf(:, ik), chw, cfac, dims)
  ENDDO



  ! IF (mpime == ionode_id) THEN
  !   OPEN(NEWUNIT =  iunit_wsndeg, FILE = "WSCellDeg.fmt", IOSTAT = ierr, FORM='formatted', STATUS = 'replace', ACTION = 'write')

  !   WRITE(iunit_wsndeg, '(5x, a)')  "iw1, iw2, ir, irvec, ndegen"
  !   DO iw = 1, dims
  !     DO iw2 = 1, dims
  !       DO ir = 1, nrr_k
  !         WRITE(iunit_wsndeg, '(i5,  i5,  i5,  3i5, i5)') iw, iw2, ir, irvec_k(1, ir), irvec_k(2, ir), irvec_k(3, ir), ndegen_k(iw, iw2, ir)
  !       ENDDO
  !     ENDDO
  !   ENDDO

  !   CLOSE(iunit_wsndeg)
  ! ENDIF

  !
  WRITE(stdout,'(/5x,a,f10.6,a)') 'Fermi energy coarse grid = ', ef * ryd2ev, ' eV'  
  !
  IF (efermi_read) THEN
    ef = fermi_energy
    WRITE(stdout,'(/5x,a)') REPEAT('=',67)
    WRITE(stdout, '(/5x,a,f10.6,a)') 'Fermi energy is read from the input file: Ef = ', ef * ryd2ev, ' eV'
    WRITE(stdout,'(/5x,a)') REPEAT('=',67)
    !
    ! SP: even when reading from input the number of electron needs to be correct
    already_skipped = .FALSE.
    IF (nbndskip > 0) THEN
      IF (.NOT. already_skipped) THEN
        IF (noncolin) THEN
          nelec = nelec - one * nbndskip
        ELSE
          nelec = nelec - two * nbndskip
        ENDIF
        already_skipped = .TRUE.
        WRITE(stdout, '(/5x,"Skipping the first ", i4, " bands:")') nbndskip
        WRITE(stdout, '(/5x,"The Fermi level will be determined with ", f9.5, " electrons")') nelec
      ENDIF
    ENDIF
  ELSE
    ! ZS added
    CALL errore('ephberry_shuffle', 'MO Berry request efermi_read = true', 1)
  ENDIF ! If fermi_read


  ! ------------------------------------------------------------
  ! Apply a possible shift to eigenenergies (applied later)
  icbm = 1
  IF (ABS(scissor) > eps6) THEN
    ! ZS added
    CALL errore("ephberry_shuffle", "A scissor shift is not allowed while calculate MO Berry", 1)
  ENDIF
  !
  ! Identify the bands within fsthick from the Fermi level
  ! Return ibndmin and ibndmax

  ! ZS added: Here, we suppose that we consider all the electron bands
  CALL fermiwindow()
  nbndfst = ibndmax - ibndmin + 1  ! ZS Added Number of band in the fsthick window.
  !
  ! Define it only once for the full run.
  CALL fkbounds(nktotf, lower_bnd, upper_bnd)  ! ZS added: Used to distribute the k, k+q points in the different MPI process
  !

  ! In the case of crystal ASR
  IF (lifc) THEN
    !
    ! build the WS cell corresponding to the force constant grid
    !
    atws(:, 1) = at(:, 1) * DBLE(nqc1)
    atws(:, 2) = at(:, 2) * DBLE(nqc2)
    atws(:, 3) = at(:, 3) * DBLE(nqc3)
    rws(:, :)  = zero
    nrws       = 0
    ! initialize WS r-vectors
    CALL wsinit(rws, nrwsx, nrws, atws)
  ELSE
    atws(:, :) = zero
    rws(:, :)  = zero
    nrws       = 0
  ENDIF
  !
  ! Open the ephmatwp file here
#if defined(__MPI)
  IF (etf_mem == 1 .OR. etf_mem == 3) then
    ! Check for directory given by "outdir"
    !
    filint = TRIM(tmp_dir) // TRIM(prefix)//'.epmatwp'
    CALL MPI_FILE_OPEN(world_comm, filint, MPI_MODE_RDONLY, MPI_INFO_NULL, iunepmatwp2, ierr)
    IF (ierr /= 0) CALL errore('ephberry_shuffle', 'error in MPI_FILE_OPEN', 1)
  ENDIF
#else
  ! ZS added: etf_mem == 2 is not tested

  lrepmatw = 2 * nbndsub * nbndsub * nrr_k * nmodes
  filint = TRIM(tmp_dir) // TRIM(prefix)//'.epmatwp'
  INQUIRE(IOLENGTH = direct_io_factor) dummy(1)
  unf_recl = direct_io_factor * INT(lrepmatw, KIND = KIND(unf_recl))
  IF (unf_recl <= 0) CALL errore('epw_write', 'wrong record length', 3)
  OPEN(iunepmatwp, FILE = TRIM(ADJUSTL(filint)), IOSTAT = ierr, FORM='unformatted', &
       STATUS = 'unknown', ACCESS = 'direct', RECL = unf_recl)
  IF (ierr /= 0) CALL errore('epw_write', 'error opening ' // TRIM(filint), 1)
#endif
  !
  ! get the size of the matrix elements stored in each pool
  ! for informational purposes.  Not necessary
  !
  CALL mem_size(nmodes, nkf)
  !
  ALLOCATE(etf_all(nbndfst, nktotf), STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating etf_all', 1)
  etf_all(:, :) = zero
  !
  ! Allocate dos we do metals
  IF (assume_metal) THEN
    ALLOCATE(dos(nstemp), STAT = ierr)
    CALL errore("ephberry_shuffle", "MBC forbid assume_metal !!!!", 1)
    ! IF (ierr /= 0) CALL errore("ephberry_shuffle", "Error allocating dos", 1)
  ENDIF


  ! ZS Added: Here start to calculat the the properties related to the electron phonon coupling (but not only here)  
  ! ZS added: This if is useless...
  IF (.NOT. epmatkqread) THEN
    !
    IF (lifc) THEN
      ALLOCATE(wscache(-2 * nqc3:2 * nqc3, -2 * nqc2:2 * nqc2, -2 * nqc1:2 * nqc1, nat, nat), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating wscache', 1)
      wscache(:, :, :, :, :) = zero
    ENDIF
    !


    ! -----------------------------------------------------------------------
    ! Determines which q-points falls within the fsthick windows
    ! Store the result in the selecq.fmt file
    ! If the file exists, automatically restart from the file
    ! -----------------------------------------------------------------------
    ! CALL qwindow_wrap(totq, nrr_k, dims, ndegen_k, irvec_r, cufkk, cufkq)
    ! ZS added: cufkk(cufkq): The eigenvectors of electrons in at k (k+q), it is useless infact
    ! ZS added: generate selectq
    ! (nbndsub, nbndsub) dimension nbndsub is the number of wannier

    ! -----------------------------------------------------------------------
    ! ZS added: Here, we take all the q point in the filqf, and do not call the q finding process
    ! ZS added: In fact, the selecq (and the  related totq, qind, etc,) is not need any more,
    ! ZS added: But in case of the compatibility, we still keep these.
    ALLOCATE(selecq(nqtotf), STAT = ierr)
    IF (ierr /= 0) CALL errore('qwindow', 'Error allocating selecq', 1)
    DO iqq = 1, nqtotf
      selecq(iqq) = iqq
    ENDDO
    totq = nqtotf
    ! -----------------------------------------------------------------------



    !
    ! -----------------------------------------------------------------------
    ! Possible restart during step 1)
    ! -----------------------------------------------------------------------
    iq_restart = 1
    first_cycle = .FALSE.
    !
    ! Fine mesh set of g-matrices.  It is large for memory storage
    ALLOCATE(epf17(nbndfst, nbndfst, nmodes, nkf), STAT = ierr)
    IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating epf17', 1)
    ALLOCATE(tmp(nbndfst, nbndfst, nmodes), STAT = ierr)
    IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating tmp', 1)
    ALLOCATE(eimpf17(nbndfst, nbndfst, nkf), STAT = ierr)
    IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating eimpf17', 1)
    ! We allocate the phonon frequency on the q-points within the window
    ! IF (etf_mem == 3) THEN
    !   ALLOCATE(wf(nmodes, totq), STAT = ierr)
    !   IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating wf', 1)
    !   wf(:, :) = zero

    !   ! ZS added
    !   ALLOCATE(wf1r(nmodes, totq), STAT = ierr)
    !   IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating wf1r', 1)
    !   wf1r(:, :) = zero
    !   ALLOCATE(wf1i(nmodes, totq), STAT = ierr)
    !   IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating wf1i', 1)
    !   wf1i(:, :) = zero
    !   ! ZS added end
    ! ENDIF

    IF (specfun_el .OR. specfun_pl) THEN
      ALLOCATE(esigmar_all(nbndfst, nktotf, nw_specfun, nstemp), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating esigmar_all', 1)
      ALLOCATE(esigmai_all(nbndfst, nktotf, nw_specfun, nstemp), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating esigmai_all', 1)
      ALLOCATE(a_all(nw_specfun, nktotf, nstemp), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating a_all', 1)
      esigmar_all(:, :, :, :) = zero
      esigmai_all(:, :, :, :) = zero
      a_all(:, :, :) = zero
    ENDIF
    IF (specfun_ph) THEN
      ALLOCATE(a_all_ph(nw_specfun, totq, nstemp), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating a_all_ph', 1)
      a_all_ph(:, :, :) = zero
    ENDIF
    IF (scattering .AND. .NOT. iterative_bte) THEN
      ALLOCATE(inv_tau_all(nstemp, nbndfst, nktotf), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating inv_tau_all', 1)
      ALLOCATE(zi_allvb(nstemp, nbndfst, nktotf), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating zi_allvb', 1)
      inv_tau_all(:, :, :) = zero
      zi_allvb(:, :, :)    = zero
    ENDIF
    IF (int_mob .AND. carrier .AND. .NOT. iterative_bte) THEN
      ALLOCATE(inv_tau_allcb(nstemp, nbndfst, nktotf), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating inv_tau_allcb', 1)
      ALLOCATE(zi_allcb(nstemp, nbndfst, nktotf), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating zi_allcb', 1)
      inv_tau_allcb(:, :, :) = zero
      zi_allcb(:, :, :)      = zero
    ENDIF
    IF (elecselfen .OR. plselfen) THEN
      ALLOCATE(sigmar_all(nbndfst, nktotf, nstemp), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating sigmar_all', 1)
      ALLOCATE(sigmai_all(nbndfst, nktotf, nstemp), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating sigmai_all', 1)
      ALLOCATE(zi_all(nbndfst, nktotf, nstemp), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating zi_all', 1)
      sigmar_all(:, :, :) = zero
      sigmai_all(:, :, :) = zero
      zi_all(:, :, :)     = zero
      IF (iverbosity == 3) THEN
        ALLOCATE(sigmai_mode(nbndfst, nmodes, nktotf, nstemp), STAT = ierr)
        IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating sigmai_mode', 1)
        sigmai_mode(:, :, :, :) = zero
      ENDIF
    ENDIF ! elecselfen
    !
    IF (loptabs) THEN
      CALL errore('ephberry_shuffle', 'W90 berry do not allow loptabs=.true.')
      nc = 2
      IF(lindabs) THEN
        WRITE(stdout, '(/5x,a)') 'lindabs not allowed with loptabs= .true.'
        lindabs = .False.
      ENDIF
    ENDIF
    !
    IF (lindabs) CALL prepare_indabs()
    !
    IF (elecselfen_ahc) THEN
      ALLOCATE(sigma_ahc_act(nbndfst, nktotf, nstemp), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating sigma_ahc_act', 1)
      ALLOCATE(sigma_ahc_ldw(nbndfst, nktotf, nstemp), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating sigma_ahc_ldw', 1)
      ALLOCATE(sigma_ahc_hdw(nbndfst, nktotf, nstemp), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating sigma_ahc_hdw', 1)
      ALLOCATE(sigma_ahc_uf(nbndfst, nktotf, nstemp), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating sigma_ahc_uf', 1)
      sigma_ahc_act = czero
      sigma_ahc_ldw = zero
      sigma_ahc_hdw = zero
      sigma_ahc_uf = zero
    ENDIF ! elecselfen_ahc
    !
    IF (wfpt) CALL wfpt_wan2bloch_setup()
    !
    ! Polaron calculations: iq_restart may be set to totq in restart/interpolation mode.
    IF (plrn) call plrn_prepare(totq, iq_restart)
    !
    ! Restart in SERTA case or self-energy (electron or plasmon) case
    IF (restart) THEN
      CALL errore('ephberry', 'MBC calculation forbiden restart = true.', 1)
    ENDIF ! restart
    !



    !
    ! Adaptative smearing when degauss = 0
    adapt_smearing = .FALSE.
    IF (ABS(degaussw) < eps16) THEN

      ! ZS added: 
      CALL errore('ephberry_shuffle', 'MO Berry Do not allow degaussw = 0', 1)

      ALLOCATE(eta(nmodes, nbndfst, nkf), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating eta', 1)
      ALLOCATE(vmefp(3, nmodes, nmodes), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating vmefp', 1)
      ALLOCATE(eta_imp(nbndfst, nkf), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating eta_imp', 1)
      eta(:, :, :)   = zero
      eta_imp(:, :)  = zero
      vmefp(:, :, :) = czero
      adapt_smearing = .TRUE.
    ENDIF
    !
    !----------------------------------------------------------------------------!
    ! S. Tiwari: QD loop, There are two extra loops that appear when we do QDPT
    ! Loop 1 runs over the many-body energy slices which we call mesh and loop 2
    ! runs over nc=2 for two cycles, cycle 1 for building QDPT hamiltonian and
    ! cycle 2 for summing imaginary dielectric constant. In case of
    ! loptabs=False, nc=1 and mesh_leng=1, and hence, it does not affect other
    ! calculations.
    ! IF (loptabs) CALL prepare_qdabs(nrr_q, irvec_q, ndegen_q, rws, nrws)
    QD_mesh = 1


    IF (start_mesh == 0) THEN
      mesh_leng = meshnum
    ELSE
      ! ZS added:
      CALL errore('ephberry_shuffle', 'MO Berry request start_mesh to be zero', 1)
      ! mesh_leng = meshnum - start_mesh + 3 ! ZS comment
    ENDIF


    ! ZS added: Loop for the k, q, k+q meshes. meshnum = 1 by default, and so mesh_leng

    !  DO mesh_dum = 1, mesh_leng
    !  QD_mesh = mesh_dum
    !  DO cycle_quad = 1, nc   ! ZS ADD: if loptabs = false, nc is just 1.

    ! IF (cycle_quad == 1) THEN
    !   maxdim = 1
    ! ENDIF
    ! IF (mesh_dum > 1) THEN
    !   IF (mesh_dum < meshnum) THEN
    !     IF (start_mesh == 0) THEN
    !       QD_mesh = mesh_dum + start_mesh
    !     ELSE
    !       QD_mesh = mesh_dum + start_mesh - 2
    !     ENDIF
    !   ENDIF
    ! ENDIF
    ! sum_E = 0.d0
    ! IF (QD_mesh > 1) THEN
    !   ! E_grid is defined in prepare_qdabs and only non-zero after first QD_mesh
    !   IF ((E_grid(QD_mesh) == 0) .AND. (QD_mesh /= meshnum)) CYCLE
    !   ! Do not enter if no quasidegenerate state
    ! ENDIF



    !------------------------------------------------------------------------------!
    ! ZS comm: The truely Loop !!!!!! is HERE !!!!
    ! ZS comm: Loop for q
    ! ZS comment: Due to the structure of this code, totq is the real totq, not only the number of q in a MPI pool
    DO iqq = iq_restart, totq
      CALL start_clock('ep-interp')
      !
      epf17(:, :, :, :) = czero
      tmp(:, :, :)      = czero
      eimpf17(:, :, :)  = czero
      cufkk(:, :) = czero
      cufkq(:, :) = czero
      !
      iq = selecq(iqq)
      !

      IF (iqq /= iq) THEN
        call errore('ephberry_shuffle', "iqq /= iq, There must  something wrong", 1)
      ENDIF

      ! ZS added: In fact, iqq == select(iqq) = iq = qind in this subroutine
      IF (etf_mem == 3) THEN
        qind = iqq
        call errore('ephberry_shuffle', "etf_mem=3 is not allowed for ephberry_shuffle subroutine", 1)
      ELSE
        qind = iq
      ENDIF

      ! ZS added
      WRITE(stdout, '(5x, a, i10, a, i10)' ) 'EPC calculation progression on iq (fine) = ', iqq, '/', totq
      !
      ! xqf has to be in crystal coordinate
      IF (etf_mem == 3) THEN
        ! The q-point coordinate is generate on the fly for each q-point
        CALL xqf_otf(iq, xxq)
      ELSE
        xxq = xqf(:, iq)
      ENDIF

      xxq_r = xxq
      mirror_q = .FALSE.

      mirror_k = .FALSE.  ! ZS added

      ! DEBUG
      WRITE(stdout, '(5x, a, 3f15.5)' ) 'Q_points_are = ', xxq

      !
      ! ------------------------------------------------------
      ! dynamical matrix : Wannier -> Bloch
      ! ------------------------------------------------------
      !

      ! ZS added: calculate the eigenvalues and eigenstates of phonon
      IF (.NOT. lifc) THEN
        ! CALL dynwan2bloch(nmodes, nrr_q, irvec_q, ndegen_q, xxq_r, uf, w2, mirror_q)  ! ZS comment
        CALL dynwan2bloch(nmodes, nrr_q, irvec_q, ndegen_q, xxq_r, ufe, w2, mirror_q)   ! ZS added
      ELSE
        !TODO: apply degeneracy lift in dynifc2blochf
        ! ZS added: calculate the phonon modes.
        ! CALL dynifc2blochf(nmodes, rws, nrws, xxq_r, uf, w2, mirror_q)  ! ZS comment
        CALL dynifc2blochf(nmodes, rws, nrws, xxq_r, ufe, w2, mirror_q)   ! ZS added
      ENDIF
      !
      ! ...then take into account the mass factors and square-root the frequencies...
      !

      ! ZS added: Check the mass
      WRITE(stdout, '(/,5x,a, i5)' )    'Atom 1 type is= ', ityp(1)
      WRITE(stdout, '(/,5x,a, f12.6)' ) 'Atom 1 mass is= ', amass(ityp(1))
      ! WRITE(stdout, '(/,5x,a, i5)' )    'Atom 2 type is= ', ityp(2)
      ! WRITE(stdout, '(/,5x,a, f12.6)' ) 'Atom 2 mass is= ', amass(ityp(3))
      ! WRITE(stdout, '(/,5x,a, i5)' )    'Atom 3 type is= ', ityp(3)
      ! WRITE(stdout, '(/,5x,a, f12.6)' ) 'Atom 3 mass is= ', amass(ityp(3))

      ufe_allq(:, :, qind) = ufe
      ! ufe1_allq(:, :, qind) = ufe_allq(:, :, qind)
      ideg_count = 0

      DO nu = 1, nmodes
        !
        ! wf are the interpolated eigenfrequencies
        ! (omega on fine grid)
        !

        ! ZS added
        wff(nu, qind) = w2(nu)
        
        ! WRITE(stdout, '(/,5x,a, i5, f12.6, " meV^2")' ) 'Imode, Phonon Frequendcy^2 is= ', nu, ryd2mev*ryd2mev * wff(nu, qind)

        IF (w2(nu) > 0.0d0) THEN
          wf(nu, qind) =  DSQRT(ABS(w2(nu)))
        ELSE
          wf(nu, qind) = -DSQRT(ABS(w2(nu)))
        ENDIF
        !
        DO mu = 1, nmodes
          na = (mu - 1) / 3 + 1
          ! uf(mu, nu) = uf(mu, nu) / DSQRT(amass(ityp(na))) ! ZS comment
          uf(mu, nu) = ufe(mu, nu) / DSQRT(amass(ityp(na)))  ! ZS added
        ENDDO

        ! ZS added: Check the degeneracy at iq
        IF (nu == 1) THEN
          ideg_count = 1
        ELSE
          
          IF ( ABS(w2(nu) - w2(nu-1)) > eps10 ) THEN
            ideg_count = ideg_count + 1
          ENDIF

        ENDIF
        ideg_map(nu, qind) = ideg_count

      ENDDO
      igroups(qind) = ideg_count

      WRITE(stdout, '(/,5x,a, 1000i5 )' ) 'Phonon degeneracy case is= ', ideg_map(:, qind)
      WRITE(stdout, '(/,5x,a, i5 )' ) 'Phonon degeneracy group number is= ', igroups(qind)



      !
      ! --------------------------------------------------------------
      ! epmat : Wannier el and Wannier ph -> Wannier el and Bloch ph
      ! --------------------------------------------------------------
      !
      ! ZS added:  Electron phonon coupling matrix (phonon part) transformation
      ! ZS added:  Perform the Fourier transformation from Wannier rep to Bloch rep 
      ! ZS added:  and doing the gause transformation basised on the eigenvectors of phonons
      IF (.NOT. longrange) THEN
        CALL ephwan2blochp(nmodes, xxq, irvec_g, ndegen_g, nrr_g, ufe, epmatwef, nbndsub, nrr_k, dims, dims2)
      ENDIF
      !
      ! Number of k points with a band on the Fermi surface
      fermicount = 0
      !


      IF (lscreen) THEN
        IF (scr_typ == 0) CALL rpa_epsilon(xxq, wf(:, qind), nmodes, epsi, eps_rpa)
        IF (scr_typ == 1) CALL tf_epsilon(xxq, nmodes, epsi, eps_rpa)
      ENDIF
      !

      ! ZS added: calculate the g_mn(k, q) matrix, and storage them (local pool)
      ! This is a loop over k blocks in the pool (size of the local k-set)
      DO ik = 1, nkf
        !
        ! xkf is assumed to be in crys coord
        !
        ikk = 2 * ik - 1
        ikq = ikk + 1
        !
        xkk = xkf(:, ikk)
        xkq2 = xkk + xxq
        !


        ! ZS comment
        ! IF (plrn .AND. time_rev_U_plrn) THEN
        !   mirror_k = is_mirror_k(ik)
        ! ELSE
        !   mirror_k = .FALSE.
        ! ENDIF


        !
        ! note that ikq_all return the global index of k+q
        ! Since ikq2 is global index, we need is_mirror_q instead of is_mirror_k
        ! is_mirror_q uses global k/q index.
        ! this is different from is_mirror_k which needs local index k
        IF (plrn .AND. time_rev_U_plrn) THEN
          ! kpg_map return global index, thus xkf_all is needed
          mirror_kpq = is_mirror_q(ikq_all(ik, iq))
        ELSE
          mirror_kpq = .FALSE.
        ENDIF
        !
        CALL DGEMV('t', 3, nrr_k, twopi, irvec_r, 3, xkk, 1, 0.0_DP, rdotk, 1)
        CALL DGEMV('t', 3, nrr_k, twopi, irvec_r, 3, xkq2, 1, 0.0_DP, rdotk2, 1)
        !
        cfac(:, :, :)  = czero
        cfacq(:, :, :) = czero
        IF (use_ws) THEN
          DO iw = 1, dims
            DO iw2 = 1, dims
              DO ir = 1, nrr_k
                IF (ndegen_k(ir, iw2, iw) > 0) THEN
                  cfac(ir, iw2, iw)  = EXP(ci * rdotk(ir))  / ndegen_k(ir, iw2, iw)
                  cfacq(ir, iw2, iw) = EXP(ci * rdotk2(ir)) / ndegen_k(ir, iw2, iw)
                ENDIF
              ENDDO
            ENDDO
          ENDDO
        ELSE
          cfac(:, 1, 1)  = EXP(ci * rdotk(:))  / ndegen_k(:, 1, 1)
          cfacq(:, 1, 1) = EXP(ci * rdotk2(:)) / ndegen_k(:, 1, 1)
        ENDIF
        !
        ! ------------------------------------------------------
        ! hamiltonian : Wannier -> Bloch
        ! ------------------------------------------------------
        !
        ! Kohn-Sham first, then get the rotation matricies for following interp.
        IF (eig_read) THEN
          !
          CALL hamwan2bloch(nbndsub, nrr_k, cufkk, etf_ks(:, ikk), chw_ks, cfac, dims, mirror_k)
          CALL hamwan2bloch(nbndsub, nrr_k, cufkq, etf_ks(:, ikq), chw_ks, cfacq, dims, mirror_kpq)
          !
        ENDIF
        !

        ! ZS added: calculate the eigenvectors and the eigenvalues of electrons at k and k+q
        CALL hamwan2bloch(nbndsub, nrr_k, cufkk, etf(:, ikk), chw, cfac, dims, mirror_k)
        CALL hamwan2bloch(nbndsub, nrr_k, cufkq, etf(:, ikq), chw, cfacq, dims, mirror_kpq)
        !
        ! Apply a possible scissor shift
        etf(icbm:nbndsub, ikk) = etf(icbm:nbndsub, ikk) + scissor
        etf(icbm:nbndsub, ikq) = etf(icbm:nbndsub, ikq) + scissor
        !
        

        ! ZS added: calculate the dipole matrix
        IF (.NOT. scattering) THEN
          IF (vme == 'wannier') THEN
            !
            ! ------------------------------------------------------
            !  velocity: Wannier -> Bloch
            ! ------------------------------------------------------
            !
            IF (eig_read) THEN
              !
              ! Renormalize the eigenvalues and vmef with the read eigenvalues
              CALL renorm_eig(ikk, ikq, nrr_k, dims, ndegen_k, irvec_k, irvec_r, cufkk, cufkq, cfac, cfacq)
              !
            ELSE ! eig_read
              CALL vmewan2bloch(nbndsub, nrr_k, irvec_k, cufkk, vmef(:, :, :, ikk), &
                      etf(:, ikk), etf_ks(:, ikk), chw, cfac, dims)
              CALL vmewan2bloch(nbndsub, nrr_k, irvec_k, cufkq, vmef(:, :, :, ikq), &
                      etf(:, ikq), etf_ks(:, ikq), chw, cfacq, dims)
              CALL rrwan2bloch(nbndsub, nrr_k, cfac, dims, rrf(:, :, :))
            ENDIF
          ELSE
            !
            ! ------------------------------------------------------
            !  dipole: Wannier -> Bloch
            ! ------------------------------------------------------
            !
            CALL dmewan2bloch(nbndsub, nrr_k, cufkk, dmef(:, :, :, ikk), etf(:, ikk), etf_ks(:, ikk), cfac, dims)
            CALL dmewan2bloch(nbndsub, nrr_k, cufkq, dmef(:, :, :, ikq), etf(:, ikq), etf_ks(:, ikq), cfacq, dims)
            !
          ENDIF
        ENDIF
        !


        ! ZS added: calculate the full electron-phonon coupling matrix from wann-> bloch
        ! ZS added: for the kq mesh (k, k+q, q)
        IF (.NOT. scatread) THEN
          !
          ! Interpolate only when (k,k+q) both have at least one band
          ! within a Fermi shell of size fsthick
          IF (((MINVAL(ABS(etf(:, ikk) - ef)) < fsthick) .AND. &
              (MINVAL(ABS(etf(:, ikq) - ef)) < fsthick))) THEN
            !
            ! Compute velocities
            !
            IF (scattering) THEN
              IF (vme == 'wannier') THEN
                CALL vmewan2bloch &
                     (nbndsub, nrr_k, irvec_k, cufkk, vmef(:, :, :, ikk), etf(:, ikk), etf_ks(:, ikk), chw, cfac, dims)
                CALL vmewan2bloch &
                     (nbndsub, nrr_k, irvec_k, cufkq, vmef(:, :, :, ikq), etf(:, ikq), etf_ks(:, ikq), chw, cfacq, dims)
              ELSE
                CALL dmewan2bloch &
                    (nbndsub, nrr_k, cufkk, dmef(:, :, :, ikk), etf(:, ikk), etf_ks(:, ikk), cfac, dims)
                CALL dmewan2bloch &
                    (nbndsub, nrr_k, cufkq, dmef(:, :, :, ikq), etf(:, ikq), etf_ks(:, ikq), cfacq, dims)
              ENDIF
            ENDIF
            !
            ! Computes adaptative smearing
            !

            ! ZS comments
            !  IF (adapt_smearing) THEN
            !    ! Return the value of the adaptative broadening eta
            !    CALL broadening(ik, ikk, ikq, wf(:, qind), vmefp, eta)
            !    IF (ii_g) CALL broadening_imp(ik, ikk, ikq, eta_imp)
            !    !
            !  ENDIF ! adapt_smearing

            !
            ! --------------------------------------------------------------
            ! epmat : Wannier el and Bloch ph -> Bloch el and Bloch ph
            ! --------------------------------------------------------------
            !
            ! SP: Note: In case of polar materials, computing the long-range and short-range term
            !     separately might help speed up the convergence. Indeed the long-range term should be
            !     much faster to compute. Note however that the short-range term still contains a linear
            !     long-range part and therefore could still be a bit more difficult to converge than
            !     non-polar materials.

            CALL cryst_to_cart(1, xxq, bg, 1)
            epmatf(:, :, :) = czero

            ! ZS added:  Electron phonon coupling matrix (electron part) transformation
            ! ZS added:  Perform the Fourier transformation from Wannier rep to Bloch rep 
            ! ZS added:  and doing the gause transformation basised on the eigenvectors of electrons
            CALL ephwan2bloch(nbndsub, nrr_k, epmatwef, cufkk, cufkq, epmatf, nmodes, cfac, dims, xxq, rrf(:, :, :))
  
            ! ZS comment
            ! IF (ii_g) THEN
            !   eimpmatf(:, :) = czero
            !   CALL rgd_imp_epw_fine(nqc1, nqc2, nqc3, xxq, eimpmatf, epsi, cufkk, cufkq, one)
            ! ENDIF

            CALL cryst_to_cart(1, xxq, at, -1)
            !
            ! Store epmatf in memory
            !
            DO jbnd = ibndmin, ibndmax
              DO ibnd = ibndmin, ibndmax
                IF (lscreen) THEN
                  epf17(ibnd - ibndmin + 1, jbnd - ibndmin + 1, :, ik) = epmatf(ibnd, jbnd, :) / eps_rpa(:)
                ELSE
                  epf17(ibnd - ibndmin + 1, jbnd - ibndmin + 1, :, ik) = epmatf(ibnd, jbnd, :)
                ENDIF

                ! ZS comment
                ! IF (ii_g) eimpf17(ibnd - ibndmin + 1, jbnd - ibndmin + 1, ik) = eimpmatf(ibnd, jbnd)
              ENDDO
            ENDDO

            ! ZS added: Here, the code done the phonon gauge transformation through the eigenvectors of dynamic matrixs.
            ! ZS added: i.e., the phonon rotation, or in  the other words, in the diagonalized representation
            ! ZS added: But for get the mass-weighted MBC, we do not performed the corresponding gauge transformation

            ! Now do the eigenvector rotation: epmatf(j) = sum_i eptmp(i) * uf(i,j)
            ! tmp(:, :, :) = epf17(:, :, :, ik)

            ! ZS commented, For do not perform the gauge transformation
            ! CALL ZGEMM('n', 'n', nbndfst * nbndfst, nmodes, nmodes, cone, tmp(:,:, :), &
            !            nbndfst * nbndfst, ufe, nmodes, czero, epf17(:, :, :,ik), nbndfst * nbndfst)

          ENDIF ! in fsthick
        ENDIF ! scatread
        !

        !
      ENDDO  ! end loop over k points
      !

      IF (.NOT. scatread) THEN
        !
        CALL stop_clock('ep-interp')
        !
      ENDIF ! scatread


      CALL start_clock('MBC_calc')
      ! ZS added
      ! ZS added: calculate mass-weighted MBC
      ! ZS added: Calculating mass-weighted MBC request after doing all of the epf17 (or at the for the q and -q pair)
      ! After this, MBC is done for every mpi process, although this is not nessesary
      CALL MBC_phon_q(iqq, iq, totq)
      CALL Nesting_phon_q(iqq, iq, totq)
      CALL stop_clock('MBC_calc')
        !
    ENDDO  ! end loop over q points


    !! Write the MBC to file
    CALL write_MBC()


  !!--------------------------------------------------------------
  !! Now, we will calculate the G induced frequency change
  !! and from now, every process is  doing the same calculations
  !!--------------------------------------------------------------

  ! ZS added: Test
  ! MBC(:,:,:) = MBC(:,:,:) / 20.0

    DO iqq = 1, totq

      iq = selecq(iqq) ! ZS added:  in fact, iq = selecq(iqq) = iqq. This is just for the convention of the form


      WRITE(stdout, '(5x, "MBC pertubated phononon at iq = ", I5)')   iq

      DO idg= 1, igroups(iq)

        !!---------------------------------------------
        ! calculate the degeneracy of the idg-groups and the lowest phonon index of this group
        ndg = 0
        im_last = 0

        DO nu = 1, nmodes 

          IF ( ideg_map(nu, iqq) == idg) THEN
            ndg = ndg + 1
          ENDIF

          IF ( ideg_map(nu, iqq) <= idg) THEN
            im_last = im_last + 1
          ENDIF

        ENDDO
        im_low = im_last - ndg + 1
        !!---------------------------------------------


        !! Calculating the first order energy modification
        ww0 = wff(im_low, iq) ! Zero order frequency
        
        !!! ZS added: Do not consider the accoustic phonon and the phonon modes with image frequency.
        IF (ww0 < mbc_accustic_limit**2) THEN
          WRITE(stdout, '(5x, "iq = ", I5, "  Dyn1 Have been set to be zero for it is  !!!" )')   iq
          Dyn1 = czero
        ELSE
          Dyn1 = (2 * ci * SQRT(ww0)) * MBC(:, :, iq)
        ENDIF

        !! To ensurance the Hermition of Dyn 1 in case of the numerical error
        Dyn1 = (CONJG(TRANSPOSE(Dyn1)) + Dyn1) / 2.0


        WRITE(stdout, '(5x, "iq = ", I5, "idg igroup = ", I5, "ndg = ", I5)')   iq, idg, ndg

        IF (ndg == 1) THEN   ! Non-Degenerate case

          ! ww1 = <uf|Pertubation|uf>
          uf_tmp1(:) = ufe_allq(:, im_low, iq)
          uf_tmp2 = MATMUL(Dyn1, uf_tmp1)        ! Check and fix
          ww1 = REAL(DOT_PRODUCT(uf_tmp2, uf_tmp1))     ! Check and fix; If vec1, and vec2 are complex, dot_product doing conjg(vec1)*vec2
          ww = ww0 + ww1
          ! CALL ZGEMM('C', 'N', 1, nmodes, nmodes, cone, uf_tmp1, MBC(:, :, iq), nmodes,  )
          ! CALL ZGEMM('n', 'n', nbndfst * nbndfst, nmodes, nmodes, cone, tmp(:,:, :), &
          !                  nbndfst * nbndfst, uf, nmodes, czero, epf17(:, :, :,ik), nbndfst * nbndfst)
          IF (ww > 0.0d0) THEN
            wf1r(im_low, iq) =  DSQRT(ABS(ww))
          ELSE
            wf1r(im_low, iq) = -DSQRT(ABS(ww))
          ENDIF
          WRITE(stdout, '(5x, "ww0 is (Ry^2): ", pe15.3)')    ww0
          WRITE(stdout, '(5x, "<uf|uf> is : ", 2(pe15.3))')   DOT_PRODUCT(uf_tmp1, uf_tmp1)

          ufe1_allq(:, im_low, iq) = uf_tmp1

          WRITE(stdout, '(5x, " iq = " , I5, " idg group = ", I5, " ndg = ", I5, " freq. = ", pe20.5E3)')   iq, idg, ndg, ww

        ELSE  ! Degenerate case

          ALLOCATE(DegenDyn(ndg, ndg), STAT = ierr)
          IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating DegenDyn', 1)
          ALLOCATE(wDeg(ndg), STAT = ierr)
          IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating wDeg', 1)
          ALLOCATE(ufDeg(ndg, ndg), STAT = ierr)
          IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating ufDeg', 1)

          ALLOCATE(uf_mat1(nmodes, ndg), STAT = ierr)
          IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating uf_mat1', 1)
          ALLOCATE(uf_mat2(ndg, ndg), STAT = ierr)
          IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating uf_mat2', 1)
          ALLOCATE(uf_mat3(nmodes, ndg), STAT = ierr)
          IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating uf_mat3', 1)

          ! ALLOCATE(cwork(2*ndg), STAT = ierr)
          ! ALLOCATE(cwork(lwork), STAT = ierr)
          ! IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating cwork', 1)
          ! ALLOCATE(rwork(7*ndg), STAT = ierr)
          ! ! ALLOCATE(rwork(3*ndg-2), STAT = ierr)
          ! IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating rwork', 1)
          ! ALLOCATE(iwork(5*ndg), STAT = ierr)
          ! IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating iwork', 1)

          uf_mat1 = ufe_allq(:, im_low:im_last, iq)
          uf_mat2 = CONJG(TRANSPOSE(ufe_allq(:, im_low:im_last, iq)))
          uf_mat3= MATMUL(Dyn1, uf_mat1)
          DegenDyn = MATMUL(uf_mat2, uf_mat3)

          DegenDyn = CONJG(TRANSPOSE(DegenDyn))

          IF (mpime == ionode_id) THEN
            ! write the DegenDyn
            WRITE(stdout, '(5x, "#####################################################################")')
            WRITE(stdout, '(5x, "Degenracy occur for iq: ", i5)') iqq
            WRITE(stdout, '(5x, "ndeg is: ", i5)') ndg

            WRITE(stdout, '(5x, "Degenracy Matrix is: ")')
            WRITE(stdout, '(5x, "-------------------------------------------------")')
            DO itmp = 1, ndg
              WRITE(stdout, '(5x, 1000(pe15.3))')  DegenDyn(itmp, :)
            ENDDO
            WRITE(stdout, '(5x, "-------------------------------------------------")')

            ! WRITE(stdout, '(5x, "UMAT1 is: ")')
            ! DO itmp = 1, ndg
            !   WRITE(stdout, '(5x, 1000(pe15.3))')  uf_mat1(itmp, :)
            ! ENDDO
            ! WRITE(stdout, '(5x, "UMAT2 is: ")')
            ! DO itmp = 1, ndg
            !   WRITE(stdout, '(5x, 1000(pe15.3))')  uf_mat2(itmp, :)
            ! ENDDO
            ! WRITE(stdout, '(5x, "2*i*w*MBC is: ")')
            DO itmp = 1, nmodes 
              WRITE(stdout, '(5x, 1000(pe15.3))')  Dyn1(itmp, :)
            ENDDO
          ENDIF

          ! CALL zhpevx('V', 'A', 'U', ndg, DegenDyn, zero, zero, &
          !             0, 0, -one, ndg, wDeg, ufDeg, ndg, cwork, rwork, iwork, ifail, info)

          ! call zhpevx('v', 'a', 'u', ndg, DegenDyn, zero, zero, &
          !             0, 0, -one, neigfound, wDeg, ufDeg, ndg, cwork, rwork, iwork, ifail, info)

          ufDeg = DegenDyn ! How stupid the ZHEEV function are !!! STUPIED !!!
          CALL eigensystem_c('V', 'U', ndg, ufDeg, wDeg)
          ! CALL zheev('N', 'U', ndg, DegenDyn, ndg, wDeg, cwork, lwork, rwork, info) 
          ! WRITE(stdout, '(5x, "Diagonalized Information: ", i5)')  info
          ! WRITE(stdout, '(5x, "N eigenvalue are founded: ", i5)')  neigfound 
          WRITE(stdout, '(5x, "ww0 is (Ry^2): ", pe15.3)')   ww0
          WRITE(stdout, '(5x, "wDeg is (Ry^2): ", 10(PE15.3))'), wDeg

          uf_mat1= MATMUL(DegenDyn, ufDeg)  ! Omega * uf
          uf_mat2= MATMUL(CONJG(TRANSPOSE(ufDeg)), uf_mat1)
          ! WRITE(stdout, '(5x, "U^\dagger DegDyn U is: ")')  
          ! WRITE(stdout, '(5x, 1000e15.3)')  uf_mat2(1, :)
          ! WRITE(stdout, '(5x, 1000e15.3)')  uf_mat2(2, :)

          !   uf_mat1= MATMUL(DegenDyn, CONJG(TRANSPOSE(ufDeg)))  ! Omega * uf
          !   uf_mat2= MATMUL(ufDeg, uf_mat1)
          !   WRITE(stdout, '(5x, "U DegDyn U^\dagger is: ")')  
          !   WRITE(stdout, '(5x, 1000e15.3)')  uf_mat2(1, :)
          !   WRITE(stdout, '(5x, 1000e15.3)')  uf_mat2(2, :)

          !   uf_mat1= MATMUL(CONJG(TRANSPOSE(ufDeg)), ufDeg)  ! Omega * uf
          !   WRITE(stdout, '(5x, "U^\dagger  U is: ")')  
          !   WRITE(stdout, '(5x, 1000e15.3)')  uf_mat1(1, :)
          !   WRITE(stdout, '(5x, 1000e15.3)')  uf_mat1(2, :)

          DO nu = 1, ndg
            ww1 = REAL(wDeg(nu))
            ww = ww0 + ww1
            WRITE(stdout, '(/,5x,a, e15.3 )' ) 'wDeg^2 is: ', ww1

            IF (ww > 0.0d0) THEN
              wf1r(im_low + nu - 1, iq) =  DSQRT(ABS(ww))
            ELSE
              wf1r(im_low + nu - 1, iq) = -DSQRT(ABS(ww))
            ENDIF

            WRITE(stdout, '(5x, " iq = " , I5, " idg group = ", I5, " ndg = ", I5, " freq. = ", pe20.5E3)')   iq, idg, ndg, ww
            ! ufe1_allq(:, im_low + nu - 1, iq) = ufDeg(1, nu)*ufe_allq(:, im_low + nu - 1, iq) +  ufDeg(2, nu)*ufe_allq(:, im_low + nu - 1, iq)

          ENDDO

          uf_mat1 = ufe_allq(:, im_low:im_last, iq)
          uf_mat2 = MATMUL(uf_mat1, ufDeg)
          ufe1_allq(:, im_low:im_low+ndg-1, iq) = uf_mat2
          ! WRITE(stdout, '(/,5x,a, i5, 5x, i5 )' ) 'wave function of imode, iq : ', im_low + nu - 1, iq


          DEALLOCATE(DegenDyn, STAT = ierr)
          IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating DegenDyn', 1)
          DEALLOCATE(uf_mat1, STAT = ierr)
          IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating uf_mat1', 1)
          DEALLOCATE(uf_mat2, STAT = ierr)
          IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating uf_mat2', 1)
          DEALLOCATE(uf_mat3, STAT = ierr)
          IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating uf_mat3', 1)
          DEALLOCATE(wDeg, STAT = ierr)
          IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating wDeg', 1)
          DEALLOCATE(ufDeg, STAT = ierr)
          IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating ufDeg', 1)

          ! DEALLOCATE(cwork, STAT = ierr)
          ! IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating ufDeg', 1)
          ! DEALLOCATE(rwork, STAT = ierr)
          ! IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating ufDeg', 1)
          ! DEALLOCATE(iwork, STAT = ierr)
          ! IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating ufDeg', 1)
        ENDIF ! END degeneraacy case IF
        

      ENDDO ! END mode loop


    ENDDO ! END Q Loop

    CALL plot_band_mbc() ! ZS added: Always output the phonon frequency with MBC, for the one without MBC can be outputed by QE
    CALL write_uf_phonon()
    IF (mbc_write_am /= 0) THEN
      mbc_write_am = 1
      CALL calc_am_of_phonon()
      mbc_write_am = 2
      CALL calc_am_of_phonon()
    ENDIF
    CALL write_mbc_nesting()

    WRITE(stdout, '(5x, a, L)' ) 'mbc_k_diss_calc = ', mbc_k_diss_calc

    ! ZS added: Calculate the G(Gamma, k,k) over the electron BZ (only for the Gamma phonon q point)
    IF (mbc_k_diss_calc) THEN
      WRITE(stdout, '(/, 5x, a)' ) 'Now we calculate the MBC_Gamma disstribution over the electron BZ'

      ! Read the k plane from file
      IF (mpime == ionode_id) THEN
        OPEN(NEWUNIT = iunitkplanefile, FILE = 'kplane.dat', STATUS = 'old', FORM = 'formatted', IOSTAT = ios)

        IF (ios /= 0) CALL errore('ephberry_shuffle', 'opening file ' // 'kplane.dat', ABS(ios))

        READ(iunitkplanefile, *) nkp_total
        ALLOCATE(kplane(3, nkp_total), STAT = ierr)


        DO itmp = 1, nkp_total
          READ(iunitkplanefile, *) kplane(:, itmp)
        ENDDO ! ikp 

        CLOSE(iunitkplanefile, IOSTAT = ios)

      ENDIF ! mpime

      CALL mp_bcast(nkp_total, ionode_id, world_comm)
      
      IF (mpime /= ionode_id) THEN
        ALLOCATE(kplane(3, nkp_total), STAT = ierr)
        IF (ierr /= 0) CALL errore('loadkmesh_para', 'Error allocating kplane', 1)
      ENDIF
      CALL mp_bcast(kplane, ionode_id, world_comm)

      ! ZS comment: Note that although kplane is only allocated at the master mpi process,
      ! ZS comment: but after the bcast, it is allocated at all of the mpi processes by mp_bcast
      ! CALL mp_barrier(inter_pool_comm)


      WRITE(stdout, '(5x, a, i10)' ) 'NPOOL_IS = ', npool
      nkp_local = nkp_total /  npool   ! ZS added: The first time nkqf is calculated
      rest_kp = nkp_total - nkp_local * npool

      WRITE(stdout, '(5x, a, i10)' ) 'MY_POOLID_IS = ', mpime
      IF (mpime <= rest_kp - 1) THEN ! my_pool_id starts from 0
        nkp_local = nkp_local + 1
        ikp_loc_begin = mpime * nkp_local + 1
        ikp_loc_end = ikp_loc_begin + nkp_local - 1
      ELSE
        ikp_loc_begin = rest_kp * (nkp_local + 1) + (mpime - rest_kp) * nkp_local + 1 ! mp_pool_id starts from 0
        ikp_loc_end = ikp_loc_begin + nkp_local - 1
      ENDIF

      ! write(*,'(a,i3,100i6)') 'POOL, nkp_local, ik_begin, ik_end, rest', mpime, nkp_local, ikp_loc_begin, ikp_loc_end, rest_kp
      ! DEBUG
      ! DO itmp = ikp_loc_begin, ikp_loc_end
      !   xxk = kplane(:, itmp)
      !   WRITE(*, '(5x, a, i5, i5, 3f15.5)' ) 'Check kpoints of ipool, ik, and xxk: ' , mpime, itmp, xxk
      ! ENDDO 

      ALLOCATE(epf17_plane(nbndfst, nbndfst, nmodes, nkp_total), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating epf17_plane', 1)
      ! ALLOCATE(MBC_Gamma_total(nmodes, nkp_total), STAT = ierr)
      ALLOCATE(MBC_Gamma_total(nmodes, nkp_total), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error allocating MBC_Gamma_total', 1)
      ALLOCATE(etf_plane(nbndsub, nkp_total), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', ' Error allocating etf_plane', 1)
      ALLOCATE(UF_GAMMA(nmodes, nmodes), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', ' Error allocating UF_GAMMA', 1)
      ALLOCATE(UF_GAMMA_DATA(nmodes, 2*nmodes), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', ' Error allocating UF_GAMMA_DATA', 1)

      IF (mpime == ionode_id) THEN
        ! Read the phonon at Gamma from file
        OPEN(NEWUNIT = iunitufgammafile, FILE = 'uf_gamma.dat', STATUS = 'old', FORM = 'formatted', IOSTAT = ios)

        IF (ios /= 0) CALL errore('ephberry_shuffle', 'opening file ' // 'uf_gamma.dat', ABS(ios))


        DO itmp = 1, nmodes
            READ(iunitufgammafile, *) UF_GAMMA_DATA(itmp, :)
        ENDDO ! itmp 

        DO itmp = 1, nmodes
          DO jtmp = 1, nmodes
            UF_GAMMA(itmp, jtmp) = CMPLX(UF_GAMMA_DATA(itmp, 2*jtmp-1), UF_GAMMA_DATA(itmp, 2*jtmp), KIND=DP)
          ENDDO ! jtmp
        ENDDO ! itmp 

        CLOSE(iunitufgammafile, IOSTAT = ios) 
      ENDIF
      CALL mp_bcast(UF_GAMMA, ionode_id, world_comm)


      ! ZS DEBUG


      epf17_plane(:, :, :, :) = czero 
      tmp(:, :, :)      = czero
      eimpf17(:, :, :)  = czero
      cufkk(:, :) = czero
      MBC_Gamma_total(:, :) = czero
      !

      WRITE(stdout, '(5x, a)' ) 'Calculating the MBC(Gamma, k, k) over the electron BZ'


      xxq = zero
      xxq_r = xxq
      mirror_q = .FALSE.
      mirror_k = .FALSE.  ! ZS added


      DO ik = 1, nkp_local
        !
        ikp_loc = ikp_loc_begin + ik - 1
        xxk = kplane(:, ikp_loc)
        !
        ! IF (2 * (ik / 2) == ik) THEN
        !   !
        !   !  this is a k+q point : redefine as xkf (:, ik-1) + xxq
        !   !
        !   CALL cryst_to_cart(1, xxq, at, -1)
        !   xxk = xkf(:, ik - 1) + xxq
        !   CALL cryst_to_cart(1, xxq, bg, 1)
        !   !
        ! ENDIF
        !
        ! SP: Compute the cfac only once here since the same are use in both hamwan2bloch and dmewan2bloch
        ! + optimize the 2\pi r\cdot k with Blas
        CALL DGEMV('t', 3, nrr_k, twopi, irvec_r, 3, xxk, 1, 0.0_DP, rdotk, 1)
        !
        DO iw = 1, dims
          DO iw2 = 1, dims
            DO ir = 1, nrr_k
              IF (ndegen_k(ir, iw2, iw) > 0) cfac(ir, iw2, iw) = EXP(ci * rdotk(ir)) / ndegen_k(ir, iw2, iw)
            ENDDO
          ENDDO
        ENDDO
        !
        CALL hamwan2bloch(nbndsub, nrr_k, cufkk, etf_plane(:, ikp_loc), chw, cfac, dims)
      ENDDO

      CALL fermiwindow_kplane()
      nbndfst = ibndmax - ibndmin + 1  ! ZS Added Number of band in the fsthick window.

      !
      ! ------------------------------------------------------
      ! dynamical matrix : Wannier -> Bloch
      ! ------------------------------------------------------
      !

      ! ZS added: calculate the eigenvalues and eigenstates of phonon
      IF (.NOT. lifc) THEN
        ! CALL dynwan2bloch(nmodes, nrr_q, irvec_q, ndegen_q, xxq_r, uf, w2, mirror_q)  ! ZS comment
        CALL dynwan2bloch(nmodes, nrr_q, irvec_q, ndegen_q, xxq_r, ufe, w2, mirror_q)   ! ZS added
      ELSE
        !TODO: apply degeneracy lift in dynifc2blochf
        ! ZS added: calculate the phonon modes.
        ! CALL dynifc2blochf(nmodes, rws, nrws, xxq_r, uf, w2, mirror_q)  ! ZS comment
        CALL dynifc2blochf(nmodes, rws, nrws, xxq_r, ufe, w2, mirror_q)   ! ZS added
      ENDIF


      DO nu = 1, nmodes
        DO mu = 1, nmodes
          na = (mu - 1) / 3 + 1
          ! uf(mu, nu) = uf(mu, nu) / DSQRT(amass(ityp(na))) ! ZS comment
          uf(mu, nu) = ufe(mu, nu) / DSQRT(amass(ityp(na)))  ! 
        ENDDO
      ENDDO


      !
      ! --------------------------------------------------------------
      ! epmat : Wannier el and Wannier ph -> Wannier el and Bloch ph
      ! --------------------------------------------------------------
      !
      ! ZS added:  Electron phonon coupling matrix (phonon part) transformation
      ! ZS added:  Perform the Fourier transformation from Wannier rep to Bloch rep 
      ! ZS added:  and doing the gause transformation basised on the eigenvectors of phonons
      IF (.NOT. longrange) THEN
        CALL ephwan2blochp(nmodes, xxq, irvec_g, ndegen_g, nrr_g, ufe, epmatwef, nbndsub, nrr_k, dims, dims2)
      ENDIF
      !
      ! Number of k points with a band on the Fermi surface
      fermicount = 0
      !


      IF (lscreen) THEN
        IF (scr_typ == 0) CALL rpa_epsilon(xxq, wf(:, qind), nmodes, epsi, eps_rpa)
        IF (scr_typ == 1) CALL tf_epsilon(xxq, nmodes, epsi, eps_rpa)
      ENDIF
      !

      ! ZS added: calculate the g_mn(k, q) matrix, and storage them (local pool)
      ! This is a loop over k blocks in the pool (size of the local k-set)
      DO ik = 1, nkp_local
        !
        ! xkf is assumed to be in crys coord
        !
        !
        ikp_loc = ikp_loc_begin + ik - 1
        xkk = kplane(:, ikp_loc)
        xkq2 = xkk ! + xxq, but here xxq = 0


        !

        !
        CALL DGEMV('t', 3, nrr_k, twopi, irvec_r, 3, xkk, 1, 0.0_DP, rdotk, 1)
        CALL DGEMV('t', 3, nrr_k, twopi, irvec_r, 3, xkq2, 1, 0.0_DP, rdotk2, 1)
        !
        cfac(:, :, :)  = czero
        cfacq(:, :, :) = czero
        IF (use_ws) THEN
          DO iw = 1, dims
            DO iw2 = 1, dims
              DO ir = 1, nrr_k
                IF (ndegen_k(ir, iw2, iw) > 0) THEN
                  cfac(ir, iw2, iw)  = EXP(ci * rdotk(ir))  / ndegen_k(ir, iw2, iw)
                  cfacq(ir, iw2, iw) = EXP(ci * rdotk2(ir)) / ndegen_k(ir, iw2, iw)
                ENDIF
              ENDDO
            ENDDO
          ENDDO
        ELSE
          cfac(:, 1, 1)  = EXP(ci * rdotk(:))  / ndegen_k(:, 1, 1)
          cfacq(:, 1, 1) = EXP(ci * rdotk2(:)) / ndegen_k(:, 1, 1)
        ENDIF
        !
        ! ------------------------------------------------------
        ! hamiltonian : Wannier -> Bloch
        ! ------------------------------------------------------
        !
        ! Kohn-Sham first, then get the rotation matricies for following interp.
        IF (eig_read) THEN

          CALL errore('ephberry_shuffle', 'eig_read=TRUE is not allowed for mbc_k_diss_calc', 1)
          !
        ENDIF
        !

        ! ZS added: calculate the eigenvectors and the eigenvalues of electrons at k and k+q
        CALL hamwan2bloch(nbndsub, nrr_k, cufkk, etf_plane(:, ikp_loc), chw, cfac, dims, mirror_k)
        ! CALL hamwan2bloch(nbndsub, nrr_k, cufkq, etf(:, ikq), chw, cfacq, dims, mirror_kpq)
        !
        ! Apply a possible scissor shift
        !

        ! ZS added: calculate the full electron-phonon coupling matrix from wann-> bloch
          !
        IF ((MINVAL(ABS(etf_plane(:, ikp_loc) - ef)) < fsthick)) THEN

          CALL cryst_to_cart(1, xxq, bg, 1)
          epmatf(:, :, :) = czero

          ! ZS added:  Electron phonon coupling matrix (electron part) transformation
          ! ZS added:  Perform the Fourier transformation from Wannier rep to Bloch rep 
          ! ZS added:  and doing the gause transformation basised on the eigenvectors of electrons
          ! ZS comment: And not that although rrf, q is passed, but it is not used if longrange = .FALSE.
          CALL ephwan2bloch(nbndsub, nrr_k, epmatwef, cufkk, cufkk, epmatf, nmodes, cfac, dims, xxq, rrf(:, :, :))
  

          CALL cryst_to_cart(1, xxq, at, -1)

          DO jbnd = ibndmin, ibndmax
            DO ibnd = ibndmin, ibndmax
              IF (lscreen) THEN
                epf17_plane(ibnd - ibndmin + 1, jbnd - ibndmin + 1, :, ikp_loc) = epmatf(ibnd, jbnd, :) / eps_rpa(:)
              ELSE
                epf17_plane(ibnd - ibndmin + 1, jbnd - ibndmin + 1, :, ikp_loc) = epmatf(ibnd, jbnd, :)
              ENDIF
            ENDDO
          ENDDO

        ENDIF ! in fsthick
      ENDDO  ! end loop over k points
      !

      CALL MBC_diss_k()
      CALL write_MBC_k_diss()
    ENDIF


    IF (MBC_phonself_calc) THEN

      ALLOCATE(lambda_all(nmodes, nqtotf, nsmear, nstemp), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephwann_shuffle', 'Error allocating lambda_all', 1)
      ALLOCATE(lambda_v_all(nmodes, nqtotf, nsmear, nstemp), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephwann_shuffle', 'Error allocating lambda_v_all', 1)
      ALLOCATE(gamma_all(nmodes, nqtotf, nsmear, nstemp), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephwann_shuffle', 'Error allocating gamma_all', 1)
      ALLOCATE(gamma_v_all(nmodes, nqtotf, nsmear, nstemp), STAT = ierr)
      IF (ierr /= 0) CALL errore('ephwann_shuffle', 'Error allocating gamma_v_all', 1)
      lambda_all(:, :, :, :)   = zero
      lambda_v_all(:, :, :, :) = zero
      gamma_all(:, :, :, :)    = zero
      gamma_v_all(:, :, :, :)  = zero




      DO iq = 1, nqtotf

        ! ZS comment: Copied from the previous part but not all.
        ! ZS comment: For not all of them  are useful
        ! ZS comment: Also, some of them are modified

        epf17(:, :, :, :) = czero
        tmp(:, :, :)      = czero
        eimpf17(:, :, :)  = czero
        cufkk(:, :) = czero
        cufkq(:, :) = czero

        uf(:,:) = ufe1_allq(:,:,iq)
        DO nu = 1, nmodes
          !
          ! wf are the interpolated eigenfrequencies
          ! (omega on fine grid)
          !
          !
          DO mu = 1, nmodes
            na = (mu - 1) / 3 + 1
            uf(mu, nu) = uf(mu, nu) / DSQRT(amass(ityp(na)))
          ENDDO
        ENDDO


        ! ZS added
        WRITE(stdout, '(5x, a, i10, a, i10)' ) 'Phonon Self Energy with MBC progression on iq (fine) = ', iq, '/', totq
        !
        ! xqf has to be in crystal coordinate
        IF (etf_mem == 3) THEN
          ! The q-point coordinate is generate on the fly for each q-point
          CALL xqf_otf(iq, xxq)
        ELSE
          xxq = xqf(:, iq)
        ENDIF

        mirror_q = .FALSE.

        mirror_k = .FALSE.  ! ZS added

        !
        ! --------------------------------------------------------------
        ! epmat : Wannier el and Wannier ph -> Wannier el and Bloch ph
        ! --------------------------------------------------------------
        !
        ! ZS added:  Electron phonon coupling matrix (phonon part) transformation
        ! ZS added:  Perform the Fourier transformation from Wannier rep to Bloch rep 
        ! ZS added:  and doing the gause transformation basised on the eigenvectors of phonons
        IF (.NOT. longrange) THEN
          ! ZS_SELF
          ! CALL ephwan2blochp(nmodes, xxq, irvec_g, ndegen_g, nrr_g, ufe1_allq(:,:,iq), epmatwef, nbndsub, nrr_k, dims, dims2)
          CALL ephwan2blochp(nmodes, xxq, irvec_g, ndegen_g, nrr_g, uf, epmatwef, nbndsub, nrr_k, dims, dims2)
        ENDIF
        !
        ! Number of k points with a band on the Fermi surface
        fermicount = 0

        IF (lscreen) THEN
          ! ZS_SELF
          ! IF (scr_typ == 0) CALL rpa_epsilon(xxq, wf1r(:, iq), nmodes, epsi, eps_rpa)
          IF (scr_typ == 0) CALL rpa_epsilon(xxq, wf(:, iq), nmodes, epsi, eps_rpa)
          IF (scr_typ == 1) CALL tf_epsilon(xxq, nmodes, epsi, eps_rpa)
        ENDIF

        DO ik = 1, nkf
          !
          ! xkf is assumed to be in crys coord
          !
          ikk = 2 * ik - 1
          ikq = ikk + 1
          !
          xkk = xkf(:, ikk)
          xkq2 = xkk + xxq
          !

          !
          ! note that ikq_all return the global index of k+q
          ! Since ikq2 is global index, we need is_mirror_q instead of is_mirror_k
          ! is_mirror_q uses global k/q index.
          ! this is different from is_mirror_k which needs local index k
          IF (plrn .AND. time_rev_U_plrn) THEN
            ! kpg_map return global index, thus xkf_all is needed
            mirror_kpq = is_mirror_q(ikq_all(ik, iq))
          ELSE
            mirror_kpq = .FALSE.
          ENDIF
          !
          CALL DGEMV('t', 3, nrr_k, twopi, irvec_r, 3, xkk, 1, 0.0_DP, rdotk, 1)
          CALL DGEMV('t', 3, nrr_k, twopi, irvec_r, 3, xkq2, 1, 0.0_DP, rdotk2, 1)
          !
          cfac(:, :, :)  = czero
          cfacq(:, :, :) = czero
          IF (use_ws) THEN
            DO iw = 1, dims
              DO iw2 = 1, dims
                DO ir = 1, nrr_k
                  IF (ndegen_k(ir, iw2, iw) > 0) THEN
                    cfac(ir, iw2, iw)  = EXP(ci * rdotk(ir))  / ndegen_k(ir, iw2, iw)
                    cfacq(ir, iw2, iw) = EXP(ci * rdotk2(ir)) / ndegen_k(ir, iw2, iw)
                  ENDIF
                ENDDO
              ENDDO
            ENDDO
          ELSE
            cfac(:, 1, 1)  = EXP(ci * rdotk(:))  / ndegen_k(:, 1, 1)
            cfacq(:, 1, 1) = EXP(ci * rdotk2(:)) / ndegen_k(:, 1, 1)
          ENDIF
          !
          ! ------------------------------------------------------
          ! hamiltonian : Wannier -> Bloch
          ! ------------------------------------------------------
          !
          ! Kohn-Sham first, then get the rotation matricies for following interp.
          IF (eig_read) THEN
            !
            CALL hamwan2bloch(nbndsub, nrr_k, cufkk, etf_ks(:, ikk), chw_ks, cfac, dims, mirror_k)
            CALL hamwan2bloch(nbndsub, nrr_k, cufkq, etf_ks(:, ikq), chw_ks, cfacq, dims, mirror_kpq)
            !
          ENDIF
          !

          ! ZS added: calculate the eigenvectors and the eigenvalues of electrons at k and k+q
          CALL hamwan2bloch(nbndsub, nrr_k, cufkk, etf(:, ikk), chw, cfac, dims, mirror_k)
          CALL hamwan2bloch(nbndsub, nrr_k, cufkq, etf(:, ikq), chw, cfacq, dims, mirror_kpq)
          !
          ! Apply a possible scissor shift
          etf(icbm:nbndsub, ikk) = etf(icbm:nbndsub, ikk) + scissor
          etf(icbm:nbndsub, ikq) = etf(icbm:nbndsub, ikq) + scissor
          !


          ! ZS added: calculate the dipole matrix
          ! ZS comment: But now, we do not need them
          IF (.NOT. scattering) THEN
            IF (vme == 'wannier') THEN
              !
              ! ------------------------------------------------------
              !  velocity: Wannier -> Bloch
              ! ------------------------------------------------------
              !
              IF (eig_read) THEN
                !
                ! Renormalize the eigenvalues and vmef with the read eigenvalues
                CALL renorm_eig(ikk, ikq, nrr_k, dims, ndegen_k, irvec_k, irvec_r, cufkk, cufkq, cfac, cfacq)
                !
              ELSE ! eig_read
                CALL vmewan2bloch(nbndsub, nrr_k, irvec_k, cufkk, vmef(:, :, :, ikk), &
                        etf(:, ikk), etf_ks(:, ikk), chw, cfac, dims)
                CALL vmewan2bloch(nbndsub, nrr_k, irvec_k, cufkq, vmef(:, :, :, ikq), &
                        etf(:, ikq), etf_ks(:, ikq), chw, cfacq, dims)
                CALL rrwan2bloch(nbndsub, nrr_k, cfac, dims, rrf(:, :, :))
              ENDIF
            ELSE
              !
              ! ------------------------------------------------------
              !  dipole: Wannier -> Bloch
              ! ------------------------------------------------------
              !
              CALL dmewan2bloch(nbndsub, nrr_k, cufkk, dmef(:, :, :, ikk), etf(:, ikk), etf_ks(:, ikk), cfac, dims)
              CALL dmewan2bloch(nbndsub, nrr_k, cufkq, dmef(:, :, :, ikq), etf(:, ikq), etf_ks(:, ikq), cfacq, dims)
              !
            ENDIF
          ENDIF
          


          ! ZS added: calculate the full electron-phonon coupling matrix from wann-> bloch
          ! ZS added: for the kq mesh (k, k+q, q)
          IF (.NOT. scatread) THEN
            !
            ! Interpolate only when (k,k+q) both have at least one band
            ! within a Fermi shell of size fsthick
            IF (((MINVAL(ABS(etf(:, ikk) - ef)) < fsthick) .AND. &
                (MINVAL(ABS(etf(:, ikq) - ef)) < fsthick))) THEN
              !
              ! Compute velocities
              !
              IF (scattering) THEN
                IF (vme == 'wannier') THEN
                  CALL vmewan2bloch &
                       (nbndsub, nrr_k, irvec_k, cufkk, vmef(:, :, :, ikk), etf(:, ikk), etf_ks(:, ikk), chw, cfac, dims)
                  CALL vmewan2bloch &
                       (nbndsub, nrr_k, irvec_k, cufkq, vmef(:, :, :, ikq), etf(:, ikq), etf_ks(:, ikq), chw, cfacq, dims)
                ELSE
                  CALL dmewan2bloch &
                      (nbndsub, nrr_k, cufkk, dmef(:, :, :, ikk), etf(:, ikk), etf_ks(:, ikk), cfac, dims)
                  CALL dmewan2bloch &
                      (nbndsub, nrr_k, cufkq, dmef(:, :, :, ikq), etf(:, ikq), etf_ks(:, ikq), cfacq, dims)
                ENDIF
              ENDIF
              !
              ! Computes adaptative smearing
              !

              ! ZS comments
              !  IF (adapt_smearing) THEN
              !    ! Return the value of the adaptative broadening eta
              !    CALL broadening(ik, ikk, ikq, wf(:, qind), vmefp, eta)
              !    IF (ii_g) CALL broadening_imp(ik, ikk, ikq, eta_imp)
              !    !
              !  ENDIF ! adapt_smearing

              !
              ! --------------------------------------------------------------
              ! epmat : Wannier el and Bloch ph -> Bloch el and Bloch ph
              ! --------------------------------------------------------------
              !
              ! SP: Note: In case of polar materials, computing the long-range and short-range term
              !     separately might help speed up the convergence. Indeed the long-range term should be
              !     much faster to compute. Note however that the short-range term still contains a linear
              !     long-range part and therefore could still be a bit more difficult to converge than
              !     non-polar materials.

              CALL cryst_to_cart(1, xxq, bg, 1)
              epmatf(:, :, :) = czero

              ! ZS added:  Electron phonon coupling matrix (electron part) transformation
              ! ZS added:  Perform the Fourier transformation from Wannier rep to Bloch rep 
              ! ZS added:  and doing the gause transformation basised on the eigenvectors of electrons
              CALL ephwan2bloch(nbndsub, nrr_k, epmatwef, cufkk, cufkq, epmatf, nmodes, cfac, dims, xxq, rrf(:, :, :))
  
              ! ZS comment
              ! IF (ii_g) THEN
              !   eimpmatf(:, :) = czero
              !   CALL rgd_imp_epw_fine(nqc1, nqc2, nqc3, xxq, eimpmatf, epsi, cufkk, cufkq, one)
              ! ENDIF

              CALL cryst_to_cart(1, xxq, at, -1)
              !
              ! Store epmatf in memory
              !
              DO jbnd = ibndmin, ibndmax
                DO ibnd = ibndmin, ibndmax
                  IF (lscreen) THEN
                    epf17(ibnd - ibndmin + 1, jbnd - ibndmin + 1, :, ik) = epmatf(ibnd, jbnd, :) / eps_rpa(:)
                  ELSE
                    epf17(ibnd - ibndmin + 1, jbnd - ibndmin + 1, :, ik) = epmatf(ibnd, jbnd, :)
                  ENDIF

                ENDDO
              ENDDO

              ! ZS added: Here, the code done the phonon gauge transformation through the eigenvectors of dynamic matrixs.
              ! ZS added: i.e., the phonon rotation, or in  the other words, in the diagonalized representation
              ! ZS added: But for get the mass-weighted MBC, we do not performed the corresponding gauge transformation

              ! WRITE(stdout, '(/, 5x, "FUCK_BUG_MBC: iq and ik is:", 2I8)'), iq, ik
              ! max_val_real = MAXVAL(REAL(epf17))
              ! max_index = MAXLOC(REAL(epf17))
              ! WRITE(stdout, '(/, 5x, "FUCK_BUG_MBC: MAX value and the index ", pe20.5E3, 4I8)'), max_val_real, max_index
              ! WRITE(stdout, '(/, 5x, "FUCK_BUG_MBC: BEFORE ROTATION REAL(epf17(1, 14, 3, 1)) is", pe20.5E3)'), REAL(epf17(1, 14, 3, 1))
              ! Now do the eigenvector rotation: epmatf(j) = sum_i eptmp(i) * uf(i,j)
              tmp(:, :, :) = epf17(:, :, :, ik)

              ! Transform the eph matrix with the phonon wavefunction with  MBC
              ! ZS_SELF
              ! CALL ZGEMM('n', 'n', nbndfst * nbndfst, nmodes, nmodes, cone, tmp(:,:, :), &
              !            nbndfst * nbndfst, ufe1_allq(:,:,iq), nmodes, czero, epf17(:, :, :,ik), nbndfst * nbndfst)
              CALL ZGEMM('n', 'n', nbndfst * nbndfst, nmodes, nmodes, cone, tmp(:,:, :), &
                        nbndfst * nbndfst, uf, nmodes, czero, epf17(:, :, :,ik), nbndfst * nbndfst)

              ! WRITE(stdout, '(/, 5x, "FUCK_BUG_MBC: AFTER  ROTATION REAL(epf17(1, 14, 3, 1)) is", pe20.5E3)'), REAL(epf17(1, 14, 3, 1))

            ENDIF ! in fsthick
          ENDIF ! scatread
          !
        ENDDO  ! end loop over k points

        CALL selfen_phon_q_MBC(iqq, iq, totq)
      

      ENDDO ! IQ

      CALL selfen_ph_write()


    ENDIF  ! MBC_phonon_self










    ! Check Memory usage
    CALL system_mem_usage(valueRSS)
    !
    WRITE(stdout, '(a)' )             '     ==================================================================='
    WRITE(stdout, '(a,i10,a)' ) '     Memory usage:  VmHWM =',valueRSS(2)/1024,'Mb'
    WRITE(stdout, '(a,i10,a)' ) '                   VmPeak =',valueRSS(1)/1024,'Mb'
    WRITE(stdout, '(a)' )             '     ==================================================================='
    WRITE(stdout, '(a)' )


    IF (iterative_bte) THEN
      ! SP - IF allocated should be avoided
      ! FIXME

      ! ZS added
      CALL errore('ephberry_shuffle', 'MBC do not allow iterative_bte = .true.', 1)

      IF (ALLOCATED(emib3tz)) THEN
        DEALLOCATE(emib3tz, STAT = ierr)
        IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating emib3tz', 1)
      ENDIF
    ENDIF
    !
    ! ZS comments end


    ! Now deallocate
    DEALLOCATE(epf17, STAT = ierr)
    IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating epf17', 1)
    DEALLOCATE(tmp, STAT = ierr)
    IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating tmp', 1)
    DEALLOCATE(eimpf17, STAT= ierr)
    IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating eimpf17', 1)
    DEALLOCATE(selecq, STAT = ierr)
    IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating selecq', 1)



    IF (scattering .AND. .NOT. iterative_bte) THEN
      DEALLOCATE(inv_tau_all, STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating inv_tau_all', 1)
      DEALLOCATE(zi_allvb, STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating zi_allvb', 1)
    ENDIF


    IF (int_mob .AND. carrier .AND. .NOT. iterative_bte) THEN
      DEALLOCATE(inv_tau_allcb, STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating inv_tau_allcb', 1)
      DEALLOCATE(zi_allcb, STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating zi_allcb', 1)
    ENDIF



    IF (elecselfen .OR. plselfen) THEN
      DEALLOCATE(sigmar_all, STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating sigmar_all', 1)
      DEALLOCATE(sigmai_all, STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating sigmai_all', 1)
      DEALLOCATE(zi_all, STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating zi_all', 1)
      IF (iverbosity == 3) THEN
        DEALLOCATE(sigmai_mode, STAT = ierr)
        IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating sigmai_mode', 1)
      ENDIF
    ENDIF


    IF (specfun_el .OR. specfun_pl) THEN
      DEALLOCATE(esigmar_all, STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating esigmar_all', 1)
      DEALLOCATE(esigmai_all, STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating esigmai_all', 1)
      DEALLOCATE(a_all, STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating a_all', 1)
    ENDIF


    IF (specfun_ph) THEN
      DEALLOCATE(a_all_ph, STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating a_all_ph', 1)
    ENDIF

    IF (lifc) THEN
      DEALLOCATE(wscache, STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating wscache', 1)
    ENDIF

    IF (elecselfen_ahc) THEN
      DEALLOCATE(sigma_ahc_act, STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating sigma_ahc_act', 1)
      DEALLOCATE(sigma_ahc_ldw, STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating sigma_ahc_ldw', 1)
      DEALLOCATE(sigma_ahc_hdw, STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating sigma_ahc_hdw', 1)
      DEALLOCATE(sigma_ahc_uf, STAT = ierr)
      IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating sigma_ahc_uf', 1)
    ENDIF ! elecselfen_ahc


    !
    ! Now do the second step of mobility
    IF (iterative_bte) CALL transport_restart(etf_all, ind_tot, ind_totcb, ef0, efcb)

    !
  ENDIF ! (.NOT. epmatkqread)


  DEALLOCATE(bmatf, STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating bmatf', 1)


  !
  CALL ephf_deallocate(nrr_k, nrr_q, nrr_g, dims, dims2, epmatwef, cufkk, cufkq, uf, w2, &
                       cfac, cfacq, rdotk, rdotk2, irvec_r, irvec_k, irvec_q, irvec_g,   &
                       ndegen_k, ndegen_q, ndegen_g, wslen_k, wslen_q, wslen_g, etf_all, &
                       epmatf, eimpmatf)


  ! ZS added
  DEALLOCATE(wff, STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating wff', 1)
  DEALLOCATE(wff1, STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating wff1', 1)
  DEALLOCATE(wf1r, STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating wf1r', 1)
  DEALLOCATE(wf1i, STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating wf1i', 1)
  DEALLOCATE(uf1, STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating uf1', 1)
  DEALLOCATE(ideg_map, STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating ideg_map', 1)
  DEALLOCATE(igroups, STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating igroups', 1)
  DEALLOCATE(ufe, STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating ufe', 1)
  DEALLOCATE(ufe_allq, STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating ufe_allq', 1)
  DEALLOCATE(ufe1_allq, STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating ufe1_allq', 1)

  DEALLOCATE(uf_tmp1, STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating uf_tmp1', 1)
  DEALLOCATE(uf_tmp2, STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating uf_tmp2', 1)

  DEALLOCATE(Dyn1, STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating Dyn1', 1)
  DEALLOCATE(MBC, STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating ', 1)
  DEALLOCATE(Nesting_q, STAT = ierr)
  IF (ierr /= 0) CALL errore('ephberry_shuffle', 'Error deallocating Nesting_q', 1)



  IF (MBC_phonself_calc) THEN
    DEALLOCATE(lambda_all, STAT = ierr)
    IF (ierr /= 0) CALL errore('ephwann_shuffle', 'Error deallocating lambda_all', 1)
    DEALLOCATE(lambda_v_all, STAT = ierr)
    IF (ierr /= 0) CALL errore('ephwann_shuffle', 'Error deallocating lambda_v_all', 1)
    DEALLOCATE(gamma_all, STAT = ierr)
    IF (ierr /= 0) CALL errore('ephwann_shuffle', 'Error deallocating gamma_all', 1)
    DEALLOCATE(gamma_v_all, STAT = ierr)
    IF (ierr /= 0) CALL errore('ephwann_shuffle', 'Error deallocating gamma_v_all', 1)
  ENDIF

  IF (mbc_k_diss_calc) THEN
    DEALLOCATE(MBC_Gamma_total, STAT = ierr)
    IF (ierr /= 0) CALL errore('ephwann_shuffle', 'Error deallocating MBC_Gamma_total', 1)
    DEALLOCATE(epf17_plane, STAT = ierr)
    IF (ierr /= 0) CALL errore('ephwann_shuffle', 'Error deallocating epf17_plane', 1)
    DEALLOCATE(kplane, STAT = ierr)
    IF (ierr /= 0) CALL errore('ephwann_shuffle', 'Error deallocating kplane', 1)
    DEALLOCATE(etf_plane, STAT = ierr)
    IF (ierr /= 0) CALL errore('ephwann_shuffle', 'Error deallocating eft_plane', 1)
    DEALLOCATE(UF_GAMMA, STAT = ierr)
    IF (ierr /= 0) CALL errore('ephwann_shuffle', 'Error deallocating UF_GAMMA', 1)
    DEALLOCATE(UF_GAMMA_DATA, STAT = ierr)
    IF (ierr /= 0) CALL errore('ephwann_shuffle', 'Error deallocating UF_GAMMA_DATA', 1)
  ENDIF

  !
  CALL stop_clock('ephberry')
  !
  !--------------------------------------------------------------------------
  END SUBROUTINE ephberry_shuffle
  !--------------------------------------------------------------------------
