  !
  ! Copyright (C) 2016-2023 EPW-Collaboration
  ! Copyright (C) 2016-2019 Samuel Ponce', Roxana Margine, Feliciano Giustino
  ! Copyright (C) 2010-2016 Samuel Ponce', Roxana Margine, Carla Verdi, Feliciano Giustino
  ! Copyright (C) 2007-2009 Jesse Noffsinger, Brad Malone, Feliciano Giustino
  !
  ! This file is distributed under the terms of the GNU General Public
  ! License. See the file `LICENSE' in the root directory of the
  ! present distribution, or http://www.gnu.org/copyleft.gpl.txt .
  !
  !----------------------------------------------------------------------
  MODULE selfen
  !----------------------------------------------------------------------
  !!
  !! This module contains the various self-energy routines
  !!
  IMPLICIT NONE
  !
  CONTAINS
    !
    !-----------------------------------------------------------------------
    SUBROUTINE selfen_elec_q(iqq, iq, totq, first_cycle)
    !-----------------------------------------------------------------------
    !!
    !!  Compute the imaginary part of the electron self energy due to electron-
    !!  phonon interaction in the Migdal approximation. This corresponds to
    !!  the electron linewidth (half width). The phonon frequency is taken into
    !!  account in the energy selection rule.
    !!
    !!  Use matrix elements, electronic eigenvalues and phonon frequencies
    !!  from ep-wannier interpolation
    !!
    !!  This routines computes the contribution from phonon iq to all k-points
    !!  The outer loop in ephwann_shuffle.f90 will loop over all iq points
    !!  The contribution from each iq is summed at the end of this subroutine
    !!  for iqq=totq to recover the per-ik electron self energy
    !!
    !!  RM 24/02/2014
    !!  Redefined the size of sigmar_all, sigmai_all, and zi_all within the fermi windwow
    !!
    !-----------------------------------------------------------------------
    USE kinds,         ONLY : DP
    USE io_global,     ONLY : stdout
    USE io_var,        ONLY : linewidth_elself
    USE modes,         ONLY : nmodes
    USE epwcom,        ONLY : nstemp, nbndsub, shortrange, fsthick, ngaussw, degaussw, &
                              eps_acustic, efermi_read, fermi_energy, restart, restart_step
    USE pwcom,         ONLY : ef
    USE elph2,         ONLY : etf, ibndmin, ibndmax, nkqf, xqf, eta, nbndfst, &
                              nkf, epf17, wf, wqf, xkf, nkqtotf, adapt_smearing, &
                              sigmar_all, sigmai_all, sigmai_mode, zi_all, efnew, &
                              nktotf, lower_bnd, gtemp
    USE control_flags, ONLY : iverbosity
    USE constants_epw, ONLY : kelvin2eV, ryd2mev, ryd2ev, one, two, zero, ci, eps6, eps8
    USE constants,     ONLY : pi
    USE mp,            ONLY : mp_barrier, mp_sum
    USE mp_global,     ONLY : inter_pool_comm
    USE mp_world,      ONLY : mpime
    USE io_global,     ONLY : ionode_id
    USE io_selfen,     ONLY : selfen_el_write
    USE poolgathering, ONLY : poolgather2
    !
    IMPLICIT NONE
    !
    CHARACTER(LEN = 20) :: tp
    !! string for temperatures
    CHARACTER(LEN = 256) :: fileselfen
    !! file name for self energy
    LOGICAL, INTENT(inout) :: first_cycle
    !! Use to determine weather this is the first cycle after restart
    INTEGER, INTENT(in) :: iqq
    !! Q-point index from selecq.fmt window
    INTEGER, INTENT(in) :: iq
    !! Q-point index from full grid
    INTEGER, INTENT(in) :: totq
    !! Total number of q-points from the selecq.fmt grid.
    !
    ! Local variables
    INTEGER :: n
    !! Integer for the degenerate average over eigenstates
    INTEGER :: ik
    !! Counter on the k-point index
    INTEGER :: ikk
    !! k-point index
    INTEGER :: ikq
    !! q-point index
    INTEGER :: ibnd
    !! Counter on bands at k
    INTEGER :: jbnd
    !! Counter on bands at k+q
    INTEGER :: imode
    !! Counter on mode
    INTEGER :: fermicount
    !! Number of states on the Fermi surface
    INTEGER :: itemp
    !! Counter on temperatures
    INTEGER :: ierr
    !! Error status
    !
    REAL(KIND = DP) :: g2
    !! Electron-phonon matrix elements squared in Ry^2
    REAL(KIND = DP) :: ef0
    !! Fermi energy level
    REAL(KIND = DP) :: ekk
    !! Eigen energy at k on the fine grid relative to the Fermi level
    REAL(KIND = DP) :: ekk1
    !! Temporary variable to the eigenenergies at k for the degenerate average
    REAL(KIND = DP) :: ekq
    !! Eigen energy at k+q on the fine grid relative to the Fermi level
    REAL(KIND = DP) :: etmp1
    !! Temporary variable to store etmp1 = ekk - (ekq - wq)
    REAL(KIND = DP) :: etmp2
    !! Temporary variable to strore etmp2 = ekk - (ekq + wq)
    REAL(KIND = DP) :: sq_etmp1
    !! Temporary variable to store etmp1^2
    REAL(KIND = DP) :: sq_etmp2
    !! Temporary variable to store etmp2^2
    REAL(KIND = DP) :: wgkq
    !! Fermi-Dirac occupation factor $f_{mk+q}(T)$
    REAL(KIND = DP) :: fact1
    !! Temporary variable to store $f_{mk+q}(T) + n_{q\nu}(T)$
    REAL(KIND = DP) :: fact2
    !! Temporary variable to store $1 - f_{mk+q}(T) + n_{q\nu}(T)$
    REAL(KIND = DP) :: weight
    !! Self-energy factor
    !!$$ N_q \Re(\frac{f_{mk+q}(T) + n_{q\nu}(T)}{\varepsilon_{nk} - \varepsilon_{mk+q} + \omega_{q\nu} - i\delta}) $$
    !!$$ + N_q \Re(\frac{1 - f_{mk+q}(T) + n_{q\nu}(T)}{\varepsilon_{nk} - \varepsilon_{mk+q} - \omega_{q\nu} - i\delta}) $$
    REAL(KIND = DP) :: w0g1
    !! Dirac delta at k for the imaginary part of $\Sigma$
    REAL(KIND = DP) :: w0g2
    !! Dirac delta at k+q for the imaginary part of $\Sigma$
    REAL(KIND = DP) :: inv_degaussw
    !! Inverse of degaussw define for efficiency reasons
    REAL(KIND = DP) :: inv_eptemp
    !! Inverse of temperature define for efficiency reasons
    REAL(KIND = DP) :: eta_tmp
    !! Temporary variable eta2
    REAL(KIND = DP) :: sq_eta_tmp
    !! Temporary eta2^2
    REAL(KIND = DP) :: inv_eta_tmp
    !! Temporary varialbe inv_eta
    REAL(KIND = DP) :: tmp1
    !! Temporary variable to store real part of Sigma for the degenerate average
    REAL(KIND = DP) :: tmp2
    !! Temporary variable to store imag part of Sigma for the degenerate average
    REAL(KIND = DP) :: tmp3
    !! Temporary variable to store Z for the degenerate average
    REAL(KIND = DP) :: sigmar_tmp(nbndfst)
    !! Temporary array to store the real-part of Sigma
    REAL(KIND = DP) :: sigmai_tmp(nbndfst)
    !! Temporary array to store the imag-part of Sigma
    REAL(KIND = DP) :: zi_tmp(nbndfst)
    !! Temporary array to store the Z
    REAL(KIND = DP), EXTERNAL :: wgauss
    !! Fermi-Dirac distribution function (when -99)
    REAL(KIND = DP), EXTERNAL :: w0gauss
    !! This function computes the derivative of the Fermi-Dirac function
    !! It is therefore an approximation for a delta function
    REAL(KIND = DP) :: wq(nmodes)
    !! Phonon frequency on the fine grid
    REAL(KIND = DP) :: inv_wq(nmodes)
    !! $frac{1}{2\omega_{q\nu}}$ defined for efficiency reasons
    REAL(KIND = DP) :: g2_tmp(nmodes)
    !! If the phonon frequency is too small discart g
    REAL(KIND = DP) :: wgq(nmodes)
    !! Bose occupation factor $n_{q\nu}(T)$
    REAL(KIND = DP) :: eta2(nbndfst, nmodes, nktotf)
    !! Temporary array to store the current smearing eta
    REAL(KIND = DP) :: inv_eta(nbndfst, nmodes, nktotf)
    !! Temporary array to store the inverse of the eta for speed purposes
    REAL(KIND = DP), ALLOCATABLE :: xkf_all(:, :)
    !! Collect k-point coordinate from all pools in parallel case
    REAL(KIND = DP), ALLOCATABLE :: etf_all(:, :)
    !! Collect eigenenergies from all pools in parallel case
    !
    ! SP: Define the inverse so that we can efficiently multiply instead of dividing
    inv_degaussw = one /degaussw
    ! To avoid if branching in the loop
    inv_eta(:, :, :) = zero
    IF (adapt_smearing) THEN
      DO ik = 1, nkf
        DO ibnd = 1, nbndfst
          DO imode = 1, nmodes
            inv_eta(ibnd, imode, ik) = one / (DSQRT(two) * eta(imode, ibnd, ik))
            eta2(ibnd, imode, ik) = DSQRT(two) * eta(imode, ibnd, ik)
          ENDDO
        ENDDO
      ENDDO
    ELSE
      DO ik = 1, nkf
        DO ibnd = 1, nbndfst
          DO imode = 1, nmodes
            inv_eta(ibnd, imode, ik) = inv_degaussw
            eta2(ibnd, imode, ik) = degaussw
          ENDDO
        ENDDO
      ENDDO
    ENDIF
    DO itemp = 1, nstemp ! loop over temperatures
      inv_eptemp   = one / gtemp(itemp)
      !
      ! Now pre-treat phonon modes for efficiency
      ! Treat phonon frequency and Bose occupation
      wq(:) = zero
      DO imode = 1, nmodes
        wq(imode) = wf(imode, iq)
        IF (wq(imode) > eps_acustic) THEN
          g2_tmp(imode) = one
          wgq(imode)    = wgauss(-wq(imode) * inv_eptemp, -99)
          wgq(imode)    = wgq(imode) / (one - two * wgq(imode))
          inv_wq(imode) = one / (two * wq(imode))
        ELSE
          g2_tmp(imode) = zero
          wgq(imode)    = zero
          inv_wq(imode) = zero
        ENDIF
      ENDDO
      !
      IF (iqq == 1) THEN
        !
        WRITE(stdout, '(/5x, a)') REPEAT('=', 67)
        WRITE(stdout, '(5x, "Electron (Imaginary) Self-Energy in the Migdal Approximation")')
        WRITE(stdout, '(5x, a/)') REPEAT('=', 67)
        !
        IF (fsthick < 1.d3) WRITE(stdout, '(/5x, a, f10.6, a)' ) 'Fermi Surface thickness = ', fsthick * ryd2ev, ' eV'
        WRITE(stdout, '(/5x, a, f10.6, a)') 'Golden Rule strictly enforced with T = ', gtemp(itemp) * ryd2ev, ' eV'
        !
      ENDIF
      !
      ! Fermi level
      !
      IF (efermi_read) THEN
        ef0 = fermi_energy
      ELSE
        ef0 = efnew
      ENDIF
      !
      IF ((iqq == 1) .AND. .NOT. adapt_smearing) THEN
        WRITE(stdout, 100) degaussw * ryd2ev, ngaussw
        WRITE(stdout, '(a)') ' '
      ENDIF
      !
      IF (restart) THEN
        ! Make everythin 0 except the range of k-points we are working on
        sigmar_all(:, 1:lower_bnd - 1, :) = zero
        sigmar_all(:, lower_bnd + nkf:nktotf, :) = zero
        sigmai_all(:, 1:lower_bnd - 1, :) = zero
        sigmai_all(:, lower_bnd + nkf:nktotf, :) = zero
        zi_all(:, 1:lower_bnd - 1, :) = zero
        zi_all(:, lower_bnd + nkf:nktotf, :) = zero
        !
      ENDIF
      !
      ! In the case of a restart do not add the first step
      IF (first_cycle .and. itemp == nstemp) THEN
        first_cycle = .FALSE.
      ELSE
        !
        ! loop over all k points of the fine mesh
        !
        fermicount = 0
        DO ik = 1, nkf
          !
          ikk = 2 * ik - 1
          ikq = ikk + 1
          !
          ! here we must have ef, not ef0, to be consistent with ephwann_shuffle
          ! (but in this case they are the same)
          !
          IF ((MINVAL(ABS(etf(:, ikk) - ef)) < fsthick) .AND. &
              (MINVAL(ABS(etf(:, ikq) - ef)) < fsthick)) THEN
            !
            fermicount = fermicount + 1
            DO imode = 1, nmodes
              DO ibnd = 1, nbndfst
                !
                ! the energy of the electron at k (relative to Ef)
                ekk = etf(ibndmin - 1 + ibnd, ikk) - ef0
                !
                eta_tmp     = eta2(ibnd, imode, ik)
                sq_eta_tmp  = eta_tmp**two
                inv_eta_tmp = inv_eta(ibnd, imode, ik)
                !
                DO jbnd = 1, nbndfst
                  !
                  ! the energy of the electron at k+q (relative to Ef)
                  ekq = etf(ibndmin - 1 + jbnd, ikq) - ef0
                  ! the Fermi occupation at k+q
                  wgkq = wgauss(-ekq * inv_eptemp, -99)
                  !
                  ! here we take into account the zero-point DSQRT(hbar/2M\omega)
                  ! with hbar = 1 and M already contained in the eigenmodes
                  ! g2 is Ry^2, wkf must already account for the spin factor
                  !
                  ! SP: Shortrange is disabled for efficiency reasons
                  !IF (shortrange .AND. ( ABS(xqf(1, iq))> eps8 .OR. ABS(xqf(2, iq))> eps8 &
                  !   .OR. ABS(xqf(3, iq))> eps8 )) THEN
                  !  ! SP: The abs has to be removed. Indeed the epf17 can be a pure imaginary
                  !  !     number, in which case its square will be a negative number.
                  !  g2 = REAL((epf17(jbnd, ibnd, imode, ik)**two) * inv_wq(imode) * g2_tmp(imode))
                  !ELSE
                  !  g2 = (ABS(epf17(jbnd, ibnd, imode, ik))**two) * inv_wq(imode) * g2_tmp(imode)
                  !ENDIF
                  !
                  g2 = (ABS(epf17(jbnd, ibnd, imode, ik))**two) * inv_wq(imode) * g2_tmp(imode)
                  !
                  ! There is a sign error for wq in Eq. 9 of Comp. Phys. Comm. 181, 2140 (2010). - RM
                  ! The sign was corrected according to Eq. (7.282) page 489 from Mahan's book
                  ! (Many-Particle Physics, 3rd edition)
                  !
                  fact1 =       wgkq + wgq(imode)
                  fact2 = one - wgkq + wgq(imode)
                  etmp1 = ekk - (ekq - wq(imode))
                  etmp2 = ekk - (ekq + wq(imode))
                  sq_etmp1 = etmp1 * etmp1
                  sq_etmp2 = etmp2 * etmp2
                  !
                  weight = wqf(iq) * REAL(fact1 / (etmp1 - ci * eta_tmp) + fact2 / (etmp2 - ci * eta_tmp))
                  !
                  ! \Re\Sigma [Eq. 3 in Comput. Phys. Commun. 209, 116 (2016)]
                  sigmar_all(ibnd, ik + lower_bnd - 1, itemp) = sigmar_all(ibnd, ik + lower_bnd - 1, itemp) + g2 * weight
                  !
                  ! Logical implementation
                  ! weight = wqf(iq) * aimag(                                                  &
                  !         ( (       wgkq + wgq ) / ( ekk - ( ekq - wq ) - ci * degaussw )  +  &
                  !           ( one - wgkq + wgq ) / ( ekk - ( ekq + wq ) - ci * degaussw ) ) )
                  !
                  ! Delta implementation
                  w0g1 = w0gauss(etmp1 * inv_eta_tmp, 0) * inv_eta_tmp
                  w0g2 = w0gauss(etmp2 * inv_eta_tmp, 0) * inv_eta_tmp
                  !
                  weight = pi * wqf(iq) * (fact1 * w0g1 + fact2 * w0g2)
                  !
                  ! \Im\Sigma using delta approx. [Eq. 8 in Comput. Phys. Commun. 209, 116 (2016)]
                  sigmai_all(ibnd, ik + lower_bnd - 1, itemp) = sigmai_all(ibnd, ik + lower_bnd - 1, itemp) + g2 * weight
                  !
                  ! Mode-resolved
                  IF (iverbosity == 3) THEN
                    sigmai_mode(ibnd, imode, ik + lower_bnd - 1, itemp) = sigmai_mode(ibnd, imode, ik + lower_bnd - 1, itemp) + &
                            g2 * weight
                  ENDIF
                  !
                  ! Z FACTOR: -\frac{\partial\Re\Sigma}{\partial\omega}
                  !
                  weight = wqf(iq) * &
                           (fact1 * (sq_etmp1 - sq_eta_tmp) / (sq_etmp1 + sq_eta_tmp)**two +  &
                            fact2 * (sq_etmp2 - sq_eta_tmp) / (sq_etmp2 + sq_eta_tmp)**two)
                  !
                  zi_all(ibnd, ik + lower_bnd - 1, itemp) = zi_all(ibnd, ik + lower_bnd - 1, itemp) + g2 * weight
                  !
                ENDDO !jbnd
              ENDDO !ibnd
            ENDDO !imode
          ENDIF ! endif  fsthick
        ENDDO ! end loop on k
        !
        ! Creation of a restart point
        IF (restart) THEN
          IF (MOD(iqq, restart_step) == 0 .and. itemp == nstemp) THEN
            WRITE(stdout, '(5x, a, i10)' ) 'Creation of a restart point at ', iqq
            CALL mp_sum(sigmar_all, inter_pool_comm)
            CALL mp_sum(sigmai_all, inter_pool_comm)
            CALL mp_sum(zi_all, inter_pool_comm)
            CALL mp_sum(fermicount, inter_pool_comm)
            CALL mp_barrier(inter_pool_comm)
            CALL selfen_el_write(iqq, totq, nktotf, sigmar_all, sigmai_all, zi_all)
          ENDIF
        ENDIF
      ENDIF ! in case of restart, do not do the first one
    ENDDO ! itemp
    !
    ! The k points are distributed among pools: here we collect them
    !
    IF (iqq == totq) THEN
      !
      ALLOCATE(xkf_all(3, nkqtotf), STAT = ierr)
      IF (ierr /= 0) CALL errore('selfen_elec_q', 'Error allocating xkf_all', 1)
      ALLOCATE(etf_all(nbndsub, nkqtotf), STAT = ierr)
      IF (ierr /= 0) CALL errore('selfen_elec_q', 'Error allocating etf_all', 1)
      xkf_all(:, :) = zero
      etf_all(:, :) = zero
      !
#if defined(__MPI)
      !
      ! note that poolgather2 works with the doubled grid (k and k+q)
      !
      CALL poolgather2(3, nkqtotf, nkqf, xkf, xkf_all)
      CALL poolgather2(nbndsub, nkqtotf, nkqf, etf, etf_all)
      CALL mp_sum(sigmar_all, inter_pool_comm)
      CALL mp_sum(sigmai_all, inter_pool_comm)
      IF (iverbosity == 3) CALL mp_sum(sigmai_mode, inter_pool_comm)
      CALL mp_sum(zi_all, inter_pool_comm)
      CALL mp_sum(fermicount, inter_pool_comm)
      CALL mp_barrier(inter_pool_comm)
      !
#else
      !
      xkf_all = xkf
      etf_all = etf
      !
#endif
      !
      DO itemp = 1, nstemp
        ! Average over degenerate eigenstates:
        WRITE(stdout, '(5x,"Average over degenerate eigenstates is performed")')
        WRITE(stdout, '(5x, a, f8.3, a)') "Temperature: ", gtemp(itemp) * ryd2ev / kelvin2eV, "K"
        !
        DO ik = 1, nktotf
          ikk = 2 * ik - 1
          ikq = ikk + 1
          !
          DO ibnd = 1, nbndfst
            ekk = etf_all(ibndmin - 1 + ibnd, ikk)
            n = 0
            tmp1 = zero
            tmp2 = zero
            tmp3 = zero
            DO jbnd = 1, nbndfst
              ekk1 = etf_all(ibndmin - 1 + jbnd, ikk)
              IF (ABS(ekk1 - ekk) < eps6) THEN
                n    = n + 1
                tmp1 = tmp1 + sigmar_all(jbnd, ik, itemp)
                tmp2 = tmp2 + sigmai_all(jbnd, ik, itemp)
                tmp3 = tmp3 + zi_all(jbnd, ik, itemp)
              ENDIF
              !
            ENDDO ! jbnd
            sigmar_tmp(ibnd) = tmp1 / FLOAT(n)
            sigmai_tmp(ibnd) = tmp2 / FLOAT(n)
            zi_tmp(ibnd)     = tmp3 / FLOAT(n)
            !
          ENDDO ! ibnd
          sigmar_all(:, ik, itemp) = sigmar_tmp(:)
          sigmai_all(:, ik, itemp) = sigmai_tmp(:)
          zi_all(:, ik, itemp)     = zi_tmp(:)
          !
        ENDDO ! nktotf
        !
        ! Output electron SE here after looping over all q-points (with their contributions
        ! summed in sigmar_all, etc.)
        !
        WRITE(stdout, '(5x,"WARNING: only the eigenstates within the Fermi window are meaningful")')
        !
        IF (mpime == ionode_id) THEN
          ! Write to file
          WRITE(tp, "(f8.3)") gtemp(itemp) * ryd2ev / kelvin2eV
          fileselfen = 'linewidth.elself.' // trim(adjustl(tp)) // 'K'
          OPEN(UNIT = linewidth_elself, FILE = fileselfen)
          WRITE(linewidth_elself, '(a)') '# Electron linewidth = 2*Im(Sigma) (meV)'
          IF (iverbosity == 3) THEN
            WRITE(linewidth_elself, '(a)') '#      ik       ibnd                 E(ibnd)      imode          Im(Sigma)(meV)'
          ELSE
            WRITE(linewidth_elself, '(a)') '#      ik       ibnd                 E(ibnd)      Im(Sigma)(meV)'
          ENDIF
          !
          DO ik = 1, nktotf
            !
            ikk = 2 * ik - 1
            ikq = ikk + 1
            !
            WRITE(stdout, '(/5x, "ik = ", i7," coord.: ", 3f12.7)') ik, xkf_all(:, ikk)
            WRITE(stdout, '(5x, a)') REPEAT('-', 67)
            !
            DO ibnd = 1, nbndfst
              !
              ! note that ekk does not depend on q
              ekk = etf_all(ibndmin - 1 + ibnd, ikk) - ef0
              !
              ! calculate Z = 1 / ( 1 -\frac{\partial\Sigma}{\partial\omega} )
              zi_all(ibnd, ik, itemp) = one / (one + zi_all(ibnd, ik, itemp))
              !
              WRITE(stdout, 102) ibndmin - 1 + ibnd, ryd2ev * ekk, ryd2mev * sigmar_all(ibnd, ik, itemp), &
                                 ryd2mev * sigmai_all(ibnd,ik, itemp), zi_all(ibnd, ik, itemp), &
                                 one / zi_all(ibnd, ik, itemp) - one
              IF (iverbosity == 3) THEN
                DO imode = 1, nmodes
                  WRITE(linewidth_elself, '(i9, 2x)', ADVANCE = 'no') ik
                  WRITE(linewidth_elself, '(i9, 2x)', ADVANCE = 'no') ibndmin - 1 + ibnd
                  WRITE(linewidth_elself, '(E22.14, 2x)', ADVANCE = 'no') ryd2ev * ekk
                  WRITE(linewidth_elself, '(i9, 2x)', ADVANCE = 'no') imode
                  WRITE(linewidth_elself, '(E22.14, 2x)') ryd2mev * sigmai_mode(ibnd, imode, ik, itemp)
                ENDDO
              ELSE
                WRITE(linewidth_elself, '(i9, 2x)', ADVANCE = 'no') ik
                WRITE(linewidth_elself, '(i9, 2x)', ADVANCE = 'no') ibndmin - 1 + ibnd
                WRITE(linewidth_elself, '(E22.14, 2x)', ADVANCE = 'no') ryd2ev * ekk
                WRITE(linewidth_elself, '(E22.14, 2x)') ryd2mev * sigmai_all(ibnd, ik, itemp)
              ENDIF
              !
            ENDDO
            WRITE(stdout, '(5x, a/)') REPEAT('-', 67)
            !
          ENDDO
          CLOSE(linewidth_elself)
        ENDIF
        !
        DO ibnd = 1, nbndfst
          DO ik = 1, nktotf
            !
            ikk = 2 * ik - 1
            ikq = ikk + 1
            !
            ! note that ekk does not depend on q
            ekk = etf_all(ibndmin - 1 + ibnd, ikk) - ef0
            !
            ! calculate Z = 1 / (1 - \frac{\partial\Sigma}{\partial\omega})
            !zi_all(ibnd,ik) = one / (one + zi_all(ibnd,ik))
            !
            WRITE(stdout, '(2i9, 5f12.4)') ik, ibndmin - 1 + ibnd, ryd2ev * ekk, ryd2mev * sigmar_all(ibnd, ik, itemp), &
                           ryd2mev * sigmai_all(ibnd, ik, itemp), zi_all(ibnd, ik, itemp), &
                           one / zi_all(ibnd, ik, itemp) - one
            !
          ENDDO
          !
          WRITE(stdout, '(a)') '  '
          !
        ENDDO
        !
      ENDDO ! itemp
      DEALLOCATE(xkf_all, STAT = ierr)
      IF (ierr /= 0) CALL errore('selfen_elec_q', 'Error deallocating xkf_all', 1)
      DEALLOCATE(etf_all, STAT = ierr)
      IF (ierr /= 0) CALL errore('selfen_elec_q', 'Error deallocating etf_all', 1)
      !
    ENDIF
    !
    100 FORMAT(5x, 'Gaussian Broadening: ', f10.6, ' eV, ngauss=', i4)
    102 FORMAT(5x, 'E( ', i3, ' )=', f9.4, ' eV   Re[Sigma]=', f15.6, ' meV Im[Sigma]=', &
               f15.6, ' meV     Z=', f15.6, ' lam=', f15.6)
    !
    RETURN
    !
    !-----------------------------------------------------------------------
    END SUBROUTINE selfen_elec_q
    !-----------------------------------------------------------------------
    !
    !-----------------------------------------------------------------------
    SUBROUTINE selfen_phon_q(iqq, iq, totq)
    !-----------------------------------------------------------------------
    !!
    !! Compute the imaginary part of the phonon self energy due to electron-
    !! phonon interaction in the Migdal approximation. This corresponds to
    !! the phonon linewidth (half width). The phonon frequency is taken into
    !! account in the energy selection rule.
    !!
    !! Use matrix elements, electronic eigenvalues and phonon frequencies
    !! from ep-wannier interpolation.  This routine is similar to the one above
    !! but it is ONLY called from within ephwann_shuffle and calculates
    !! the selfenergy for one phonon at a time.  Much smaller footprint on
    !! the disk
    !!
    !! RM 24/02/2014
    !! redefined the size of coskkq, vkk, vkq within the fermi windwow
    !! cleaned up the subroutine
    !!
    !-----------------------------------------------------------------------
    USE kinds,      ONLY : DP
    USE io_global,  ONLY : stdout
    USE modes,      ONLY : nmodes
    USE epwcom,     ONLY : nbndsub, fsthick, efermi_read, fermi_energy,  &
                           nstemp, ngaussw, degaussw, shortrange,        &
                           nsmear, delta_smear, eps_acustic, specfun_ph, &
                           delta_approx, vme
    USE pwcom,      ONLY : nelec, ef
    USE klist_epw,  ONLY : isk_dummy
    USE elph2,      ONLY : epf17, ibndmax, ibndmin, etf, wkf, xqf, wqf, nkqf,   &
                           nkf, wf, nkqtotf, xqf, lambda_all, lambda_v_all,     &
                           dmef, vmef, gamma_all, gamma_v_all, efnew, nbndfst, &
                           gtemp, nktotf, adapt_smearing
    USE mp,         ONLY : mp_barrier, mp_sum
    USE mp_global,  ONLY : inter_pool_comm
    USE constants_epw, ONLY : kelvin2eV, ryd2mev, ryd2ev, one, two, zero, eps4, eps6, eps8, eps10, eps12
    USE constants,  ONLY : pi
    !
    IMPLICIT NONE
    !
    INTEGER, INTENT(in) :: iqq
    !! Current q-point index from the selecq
    INTEGER, INTENT(in) :: iq
    !! Current q-point index
    INTEGER, INTENT(in) :: totq
    !! Total number of q-points in selecq.fmt
    !
    ! Local variables
    !
    CHARACTER(LEN = 20) :: tp
    !! String for temperatures
    CHARACTER(LEN = 256) :: filephself
    !! File name for phonon self energy
    INTEGER :: ik
    !! Counter on the k-point index
    INTEGER :: ikk
    !! k-point index
    INTEGER :: ikq
    !! q-point index
    INTEGER :: ibnd
    !! Counter on bands at k
    INTEGER :: jbnd
    !! Counter on bands at k+q
    INTEGER :: imode
    !! Counter on mode
    INTEGER :: jmode
    !! Counter on mode
    INTEGER :: fermicount
    !! Number of states on the Fermi surface
    INTEGER :: ismear
    !! Number of smearing values for the Gaussian function
    INTEGER :: n
    !! Counter on number of mode degeneracies
    INTEGER :: itemp
    !! Counter on temperatuers
    !
    REAL(KIND = DP) :: g2
    !! Electron-phonon matrix elements squared in Ry^2
    REAL(KIND = DP) :: ef0
    !! Fermi energy level
    REAL(KIND = DP) :: dosef
    !! Density of state N(Ef)
    REAL(KIND = DP) :: ekk
    !! Eigen energy at k on the fine grid relative to the Fermi level
    REAL(KIND = DP) :: ekq
    !! Eigen energy at k+q on the fine grid relative to the Fermi level
    REAL(KIND = DP) :: wgkk
    !! Fermi-Dirac occupation factor $f_{nk}(T)$
    REAL(KIND = DP) :: wgkq
    !! Fermi-Dirac occupation factor $f_{nk+q}(T)$
    REAL(KIND = DP) :: weight
    !! Imaginary part of the phonhon self-energy factor
    !!$$ \pi N_q \Im(\frac{f_{nk}(T) - f_{mk+q(T)}}{\varepsilon_{nk}-\varepsilon_{mk+q}-\omega_{q\nu}+i\delta}) $$
    !! In practice the imaginary is performed with a delta Dirac
    REAL(KIND = DP) :: w0g1
    !! Dirac delta at k for the imaginary part of $\Sigma$
    REAL(KIND = DP) :: w0g2
    !! Dirac delta at k+q for the imaginary part of $\Sigma$
    REAL(KIND = DP) :: degaussw0
    !! degaussw0 = (ismear-1) * delta_smear + degaussw
    REAL(KIND = DP) :: inv_degaussw0
    !! Inverse degaussw0 for efficiency reasons
    REAL(KIND = DP) :: inv_eptemp
    !! Inverse of temperature define for efficiency reasons
    REAL(KIND = DP) :: lambda_tot
    !! Integrated lambda function
    REAL(KIND = DP) :: lambda_tr_tot
    !! Integrated transport lambda function
    REAL(KIND = DP) :: tmp1
    !! Temporary value of lambda for av.
    REAL(KIND = DP) :: tmp2
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: tmp3
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: tmp4
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: DDOT
    !! Dot product function
    REAL(KIND = DP), EXTERNAL :: dos_ef
    !! Function to compute the Density of States at the Fermi level
    REAL(KIND = DP), EXTERNAL :: efermig
    !! Return the fermi energy
    REAL(KIND = DP), EXTERNAL :: wgauss
    !! Fermi-Dirac distribution function (when -99)
    REAL(KIND = DP), EXTERNAL :: w0gauss
    !! This function computes the derivative of the Fermi-Dirac function
    !! It is therefore an approximation for a delta function
    REAL(KIND = DP) :: wq(nmodes)
    !! Phonon frequency on the fine grid
    REAL(KIND = DP) :: inv_wq(nmodes)
    !! $frac{1}{2\omega_{q\nu}}$ defined for efficiency reasons
    REAL(KIND = DP) :: g2_tmp(nmodes)
    !! If the phonon frequency is too small discart g
    REAL(KIND = DP) :: gamma(nmodes)
    !! Gamma is the imaginary part of the phonon self-energy
    REAL(KIND = DP) :: gamma_v(nmodes)
    !! Gamma is the imaginary part of the phonon self-energy multiplied by (1-coskkq)
    REAL(KIND = DP) :: lambda_tmp(nmodes)
    !! Temporary value of lambda for av.
    REAL(KIND = DP) :: lambda_v_tmp(nmodes)
    !! Temporary value of lambda v for av.
    REAL(KIND = DP) :: gamma_tmp(nmodes)
    !! Temporary value of gamma for av.
    REAL(KIND = DP) :: gamma_v_tmp(nmodes)
    !! Temporary value of gamma v for av.
    REAL(KIND = DP) :: vkk(3, nbndfst)
    !! Electronic velocity $v_{nk}$
    REAL(KIND = DP) :: vkq(3, nbndfst)
    !! Electronic velocity $v_{nk+q}$
    REAL(KIND = DP) :: coskkq(nbndfst, nbndfst)
    !! $$(v_k \cdot v_{k+q}) / |v_k|^2$$
    !
    IF (adapt_smearing) CALL errore('selfen_phon_q', 'adapt_smearing cannot be used with phonon self-energy', 1)
    !
    !
    DO itemp = 1, nstemp  ! ZS added: If you just choose one  temperature, you do not need to consider it
      IF (iq == 1) THEN
        WRITE(stdout, '(/5x, a)') REPEAT('=',67)
        WRITE(stdout, '(5x, "Phonon (Imaginary) Self-Energy in the Migdal Approximation")')
        WRITE(stdout, '(5x, a/)') REPEAT('=',67)
        !
        IF (fsthick < 1.d3 ) WRITE(stdout, '(/5x, a, f10.6, a)' ) &
             'Fermi Surface thickness = ', fsthick * ryd2ev, ' eV'
        WRITE(stdout, '(/5x, a, f10.6, a)' ) 'Golden Rule strictly enforced with T = ', gtemp(itemp) * ryd2ev, ' eV'
        !
      ENDIF
      !
      !
      ! Now pre-treat phonon modes for efficiency
      ! Treat phonon frequency and Bose occupation
      wq(:) = zero  ! ZS added: frequency of phonon of each  mode on a specific q point
      DO imode = 1, nmodes
        wq(imode) = wf(imode, iq)
        IF (wq(imode) > eps_acustic) THEN
          g2_tmp(imode) = one
          inv_wq(imode) = one / (two * wq(imode))
        ELSE
          g2_tmp(imode) = zero
          inv_wq(imode) = zero
        ENDIF
      ENDDO
      !
      DO ismear = 1, nsmear   ! ZS added: For understanding the code, you can just focus on the one smear.
        !
        degaussw0 = (ismear - 1) * delta_smear + degaussw
        !
        ! SP: Multiplication is faster than division ==> Important if called a lot
        !     in inner loops
        inv_degaussw0 = one / degaussw0
        inv_eptemp   = one / gtemp(itemp)
        !
        ! Fermi level and corresponding DOS
        !
        IF (efermi_read) THEN
          ef0 = fermi_energy ! ZS added: We alway suppose that the Fermi energy is read from the epw input file.
        ELSEIF (nsmear > 1) THEN
          !
          ef0 = efermig(etf, nbndsub, nkqf, nelec, wkf, degaussw0, ngaussw, 0, isk_dummy)
          ! if some bands are skipped (nbndskip /= 0), nelec has already been
          ! recalculated in ephwann_shuffle
          !
        ELSE !SP: This is added for efficiency reason because the efermig routine is slow
          ef0 = efnew
        ENDIF
        !
        dosef = dos_ef(ngaussw, degaussw0, ef0, etf, wkf, nkqf, nbndsub)
        !  N(Ef) in the equation for lambda is the DOS per spin
        dosef = dosef / two ! ZS added: What if the SOC case?
        !
        IF (iq == 1) THEN
          WRITE (stdout, 100) degaussw0 * ryd2ev, ngaussw
          WRITE (stdout, 101) dosef / ryd2ev, ef0 * ryd2ev
        ENDIF
        !
        CALL start_clock('PH SELF-ENERGY')
        !
        fermicount = 0     ! ZS added:  number of states on Fermi level.
        wgkk = zero        ! ZS added: Fermi-Dirac occupation factor $f_{nk}(T)$
        w0g1 = zero        ! ZS added: Dirac delta at k for the imaginary part of $\Sigma$
        gamma(:)   = zero  ! ZS added: Gamma is the imaginary part of the phonon self-energy
        gamma_v(:) = zero  ! ZS added: Gamma for calculation of the transportation properties, and seems no need for our calculation
        !
        DO ik = 1, nkf
          !
          ikk = 2 * ik - 1
          ikq = ikk + 1
          !
          coskkq = zero
          ! coskkq = (vk dot vkq) / |vk|^2  appears in Grimvall 8.20
          ! this is different from :   coskkq = (vk dot vkq) / |vk||vkq|
          ! In principle the only coskkq contributing to lambda_tr are both near the
          ! Fermi surface and the magnitudes will not differ greatly between vk and vkq
          ! we may implement the approximation to the angle between k and k+q
          ! vectors also listed in Grimvall
          ! ZS added : Calculate the velocity of electrons
          IF (vme == 'wannier') THEN
            DO ibnd = 1, nbndfst
              DO jbnd = 1, nbndfst
                !
                ! vmef is in units of Ryd * bohr
                !
                vkk(:, ibnd) = REAL(vmef(:, ibndmin - 1 + ibnd, ibndmin - 1 + ibnd, ikk))
                vkq(:, jbnd) = REAL(vmef(:, ibndmin - 1 + jbnd, ibndmin - 1 + jbnd, ikq))
                IF (ABS(vkk(1, ibnd)**two + vkk(2, ibnd)**two + vkk(3, ibnd)**two) > eps4) &
                  coskkq(ibnd, jbnd) = DDOT(3, vkk(:, ibnd), 1, vkq(:, jbnd), 1) / &
                                       DDOT(3, vkk(:, ibnd), 1, vkk(:, ibnd), 1)
              ENDDO
            ENDDO
          ELSE
            DO ibnd = 1, nbndfst
              DO jbnd = 1, nbndfst
                !
                ! v_(k,i) = 1/m <ki|p|ki> = dmef (:, i,i,k)
                ! 1/m  = 2 in Rydberg atomic units
                !
                vkk(:, ibnd) = REAL(dmef(:, ibndmin - 1 + ibnd, ibndmin - 1 + ibnd, ikk))
                vkq(:, jbnd) = REAL(dmef(:, ibndmin - 1 + jbnd, ibndmin - 1 + jbnd, ikq))
                IF (ABS(vkk(1, ibnd)**two + vkk(2, ibnd)**two + vkk(3, ibnd)**two) > eps4) &
                  coskkq(ibnd, jbnd) = DDOT(3, vkk(:, ibnd), 1, vkq(:, jbnd), 1)  / &
                                       DDOT(3, vkk(:, ibnd), 1, vkk(:, ibnd), 1)
              ENDDO
            ENDDO
          ENDIF
          !
          ! Here we must have ef, not ef0, to be consistent with ephwann_shuffle
          IF ((MINVAL(ABS(etf(:, ikk) - ef)) < fsthick) .AND. &
              (MINVAL(ABS(etf(:, ikq) - ef)) < fsthick)) THEN
            !
            fermicount = fermicount + 1
            DO imode = 1, nmodes  ! ZS added: Loop for the phonon modes, Calculate the self energy of each phonon mode.
              !
              DO ibnd = 1, nbndfst   ! ZS added: Loop for electron bands in the Fermi window at k and k+q
                !
                !  the fermi occupation for k
                ekk = etf(ibndmin - 1 + ibnd, ikk) - ef0
                !
                IF (delta_approx) THEN
                  w0g1 = w0gauss(ekk * inv_degaussw0, 0) * inv_degaussw0
                ELSE
                  wgkk = wgauss(-ekk * inv_eptemp, -99)
                ENDIF
                !
                DO jbnd = 1, nbndfst
                  !
                  !  the fermi occupation for k+q
                  ekq = etf(ibndmin - 1 + jbnd, ikq) - ef0
                  !
                  ! here we take into account the zero-point DSQRT(hbar/2M\omega)
                  ! with hbar = 1 and M already contained in the eigenmodes
                  ! g2 is Ry^2, wkf must already account for the spin factor
                  !
                  IF (shortrange .AND. (ABS(xqf(1, iq)) > eps8 .OR. ABS(xqf(2, iq)) > eps8 &
                                        .OR. ABS(xqf(3, iq)) > eps8)) THEN
                    ! SP: The abs has to be removed. Indeed the epf17 can be a pure imaginary
                    !     number, in which case its square will be a negative number.
                    g2 = REAL((epf17(jbnd, ibnd, imode, ik)**two) * inv_wq(imode) * g2_tmp(imode))
                  ELSE
                    g2 = (ABS(epf17(jbnd, ibnd, imode, ik))**two) * inv_wq(imode) * g2_tmp(imode)
                  ENDIF
                  !
                  IF (delta_approx) THEN
                    !
                    w0g2 = w0gauss(ekq * inv_degaussw0, 0) * inv_degaussw0
                    ! the expression below is positive-definite, but also an
                    ! approximation which neglects some fine features
                    weight = pi * wq(imode) * wkf(ikk) * w0g1 * w0g2
                    !
                  ELSE
                    !
                    wgkq = wgauss(-ekq * inv_eptemp, -99)
                    !
                    ! = k-point weight * [f(E_k) - f(E_k+q)] / [E_k+q - E_k - w_q + id]
                    ! This is the imaginary part of the phonon self-energy, sans
                    ! the matrix elements [Eq. 4 in Comput. Phys. Commun. 209, 116 (2016)]
                    !
                    !weight = wkf (ikk) * (wgkk - wgkq) * AIMAG(cone / (ekq - ekk - wq - ci * degaussw0))
                    !
                    ! SP: The expression below is the imag part of phonon self-energy,
                    ! sans matrix elements [Eq. 9 in Comput. Phys. Commun. 209, 116 (2016)]
                    !  = pi * k-point weight * [f(E_k) - f(E_k+q)] * delta[E_k+q - E_k - w_q]
                    !
                    weight = pi * wkf(ikk) * (wgkk - wgkq) * w0gauss((ekq - ekk - wq(imode)) * inv_degaussw0, 0) * inv_degaussw0
                    !
                  ENDIF
                  !
                  gamma(imode)   = gamma(imode)   + weight * g2
                  gamma_v(imode) = gamma_v(imode) + weight * g2 * (1.0d0 - coskkq(ibnd, jbnd))
                  !
                ENDDO ! jbnd
              ENDDO   ! ibnd
            ENDDO ! loop on q-modes
          ENDIF ! endif fsthick
        ENDDO ! loop on k
        !
        CALL stop_clock('PH SELF-ENERGY')
        !
        ! collect contributions from all pools (sum over k-points)
        ! this finishes the integral over the BZ  (k)
        !
        CALL mp_sum(gamma, inter_pool_comm)
        CALL mp_sum(gamma_v, inter_pool_comm)
        CALL mp_sum(fermicount, inter_pool_comm)
        CALL mp_barrier(inter_pool_comm)
        !
        ! An average over degenerate phonon-mode is performed.
        DO imode = 1, nmodes
          n = 0
          tmp1 = zero
          tmp2 = zero
          tmp3 = zero
          tmp4 = zero
          DO jmode = 1, nmodes
            IF (ABS(wq(imode) - wq(jmode)) < eps6) THEN
              n = n + 1
              IF (wq(jmode) > eps_acustic) THEN
                tmp1 =  tmp1 + gamma(jmode)   / pi / wq(imode)**two / dosef
                tmp2 =  tmp2 + gamma_v(jmode) / pi / wq(imode)**two / dosef
              ENDIF
              tmp3 =  tmp3 + gamma(jmode)
              tmp4 =  tmp4 + gamma_v(jmode)
            ENDIF
          ENDDO ! jbnd
          lambda_tmp(imode)   = tmp1 / FLOAT(n)
          lambda_v_tmp(imode) = tmp2 / FLOAT(n)
          gamma_tmp(imode)    = tmp3 / FLOAT(n)
          gamma_v_tmp(imode)  = tmp4 / FLOAT(n)
        ENDDO
        lambda_all(:, iq, ismear, itemp)   = lambda_tmp(:)
        lambda_v_all(:, iq, ismear, itemp) = lambda_v_tmp(:)
        gamma_all(:, iq, ismear, itemp)    = gamma_tmp(:)
        gamma_v_all(:, iq, ismear, itemp)  = gamma_v_tmp(:)
        lambda_tot    = SUM(lambda_all(:, iq, ismear, itemp))
        lambda_tr_tot = SUM(lambda_v_all(:, iq, ismear, itemp))
        !
        WRITE(stdout, '(/5x, "ismear = ",i5," iq = ",i7," coord.: ", 3f9.5, " wt: ", f9.5, " Temp: ", f8.3, "K")') ismear, iq, &
                                                                      xqf(:, iq), wqf(iq), gtemp(itemp) * ryd2ev / kelvin2eV
        WRITE(stdout, '(5x, a)') REPEAT('-', 67)
        !
        DO imode = 1, nmodes
          !
          WRITE(stdout, 102) imode, lambda_all(imode, iq, ismear, itemp), &
                             ryd2mev * gamma_all(imode, iq, ismear, itemp), ryd2mev * wq(imode)
          WRITE(stdout, 104) imode, lambda_v_all(imode, iq, ismear, itemp), &
                             ryd2mev * gamma_v_all(imode, iq, ismear, itemp), ryd2mev * wq(imode)
          !
        ENDDO
        !
        WRITE(stdout, 103) lambda_tot
        WRITE(stdout, 105) lambda_tr_tot
        !
        IF (.NOT. specfun_ph) THEN
          WRITE(stdout, '(5x, a/)') REPEAT('-', 67)
          WRITE(stdout, '(/5x, a, i8, a, i8/)' ) 'Number of (k,k+q) pairs on the Fermi surface: ', fermicount, ' out of ', nktotf
        ENDIF
        !
      ENDDO !smears
      !
    ENDDO ! itemp
    100 FORMAT(5x, 'Gaussian Broadening: ', f10.6, ' eV, ngauss=', i4)
    101 FORMAT(5x, 'DOS =', f10.6, ' states/spin/eV/Unit Cell at Ef=', f10.6, ' eV')
    102 FORMAT(5x, 'lambda___( ', i3, ' )=', f15.6, '   gamma___=', f15.6, ' meV', '   omega=', f12.4, ' meV')
    103 FORMAT(5x, 'lambda___( tot )=', f15.6)
    104 FORMAT(5x, 'lambda_tr( ',i3,' )=', f15.6, '   gamma_tr=', f15.6, ' meV', '   omega=', f12.4, ' meV')
    105 FORMAT(5x, 'lambda_tr( tot )=', f15.6)
    !
    RETURN
    !
    !-----------------------------------------------------------------------
    END SUBROUTINE selfen_phon_q
    !-----------------------------------------------------------------------
    !

    SUBROUTINE selfen_phon_q_MBC(iqq, iq, totq)
    !-----------------------------------------------------------------------
    !!
    !! ZS: This part is not realeased, just as the dummy subroutine for the moment. 
    !! The real subroutine will be released in the future.
    !!
    !-----------------------------------------------------------------------
    USE kinds,      ONLY : DP
    USE io_global,  ONLY : stdout
    USE modes,      ONLY : nmodes
    USE epwcom,     ONLY : nbndsub, fsthick, efermi_read, fermi_energy,  &
                           nstemp, ngaussw, degaussw, shortrange,        &
                           nsmear, delta_smear, eps_acustic, specfun_ph, &
                           delta_approx, vme, mbc_accustic_limit   ! ZS added
    USE pwcom,      ONLY : nelec, ef
    USE klist_epw,  ONLY : isk_dummy
    USE elph2,      ONLY : epf17, ibndmax, ibndmin, etf, wkf, xqf, wqf, nkqf,   &
                           nkf, wf, nkqtotf, xqf, lambda_all, lambda_v_all,     &
                           dmef, vmef, gamma_all, gamma_v_all, efnew, nbndfst, &
                           gtemp, nktotf, adapt_smearing, wf1r      ! ZS added
    USE mp,         ONLY : mp_barrier, mp_sum
    USE mp_global,  ONLY : inter_pool_comm
    USE constants_epw, ONLY : kelvin2eV, ryd2mev, ryd2ev, one, two, zero, eps4, eps6, eps8, eps10, eps12
    USE constants,  ONLY : pi
    !
    IMPLICIT NONE
    !
    INTEGER, INTENT(in) :: iqq
    !! Current q-point index from the selecq
    INTEGER, INTENT(in) :: iq
    !! Current q-point index
    INTEGER, INTENT(in) :: totq
    !! Total number of q-points in selecq.fmt
    !
    ! Local variables
    !
    CHARACTER(LEN = 20) :: tp
    !! String for temperatures
    CHARACTER(LEN = 256) :: filephself
    !! File name for phonon self energy
    INTEGER :: ik
    !! Counter on the k-point index
    INTEGER :: ikk
    !! k-point index
    INTEGER :: ikq
    !! q-point index
    INTEGER :: ibnd
    !! Counter on bands at k
    INTEGER :: jbnd
    !! Counter on bands at k+q
    INTEGER :: imode
    !! Counter on mode
    INTEGER :: jmode
    !! Counter on mode
    INTEGER :: fermicount
    !! Number of states on the Fermi surface
    INTEGER :: ismear
    !! Number of smearing values for the Gaussian function
    INTEGER :: n
    !! Counter on number of mode degeneracies
    INTEGER :: itemp
    !! Counter on temperatuers
    !
    REAL(KIND = DP) :: g2
    !! Electron-phonon matrix elements squared in Ry^2
    REAL(KIND = DP) :: ef0
    !! Fermi energy level
    REAL(KIND = DP) :: dosef
    !! Density of state N(Ef)
    REAL(KIND = DP) :: ekk
    !! Eigen energy at k on the fine grid relative to the Fermi level
    REAL(KIND = DP) :: ekq
    !! Eigen energy at k+q on the fine grid relative to the Fermi level
    REAL(KIND = DP) :: wgkk
    !! Fermi-Dirac occupation factor $f_{nk}(T)$
    REAL(KIND = DP) :: wgkq
    !! Fermi-Dirac occupation factor $f_{nk+q}(T)$
    REAL(KIND = DP) :: weight
    !! Imaginary part of the phonhon self-energy factor
    !!$$ \pi N_q \Im(\frac{f_{nk}(T) - f_{mk+q(T)}}{\varepsilon_{nk}-\varepsilon_{mk+q}-\omega_{q\nu}+i\delta}) $$
    !! In practice the imaginary is performed with a delta Dirac
    REAL(KIND = DP) :: w0g1
    !! Dirac delta at k for the imaginary part of $\Sigma$
    REAL(KIND = DP) :: w0g2
    !! Dirac delta at k+q for the imaginary part of $\Sigma$
    REAL(KIND = DP) :: degaussw0
    !! degaussw0 = (ismear-1) * delta_smear + degaussw
    REAL(KIND = DP) :: inv_degaussw0
    !! Inverse degaussw0 for efficiency reasons
    REAL(KIND = DP) :: inv_eptemp
    !! Inverse of temperature define for efficiency reasons
    REAL(KIND = DP) :: lambda_tot
    !! Integrated lambda function
    REAL(KIND = DP) :: lambda_tr_tot
    !! Integrated transport lambda function
    REAL(KIND = DP) :: tmp1
    !! Temporary value of lambda for av.
    REAL(KIND = DP) :: tmp2
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: tmp3
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: tmp4
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: DDOT
    !! Dot product function
    REAL(KIND = DP), EXTERNAL :: dos_ef
    !! Function to compute the Density of States at the Fermi level
    REAL(KIND = DP), EXTERNAL :: efermig
    !! Return the fermi energy
    REAL(KIND = DP), EXTERNAL :: wgauss
    !! Fermi-Dirac distribution function (when -99)
    REAL(KIND = DP), EXTERNAL :: w0gauss
    !! This function computes the derivative of the Fermi-Dirac function
    !! It is therefore an approximation for a delta function
    REAL(KIND = DP) :: wq(nmodes)
    !! Phonon frequency on the fine grid
    REAL(KIND = DP) :: inv_wq(nmodes)
    !! $frac{1}{2\omega_{q\nu}}$ defined for efficiency reasons
    REAL(KIND = DP) :: g2_tmp(nmodes)
    !! If the phonon frequency is too small discart g
    REAL(KIND = DP) :: gamma(nmodes)
    !! Gamma is the imaginary part of the phonon self-energy
    REAL(KIND = DP) :: gamma_v(nmodes)
    !! Gamma is the imaginary part of the phonon self-energy multiplied by (1-coskkq)
    REAL(KIND = DP) :: lambda_tmp(nmodes)
    !! Temporary value of lambda for av.
    REAL(KIND = DP) :: lambda_v_tmp(nmodes)
    !! Temporary value of lambda v for av.
    REAL(KIND = DP) :: gamma_tmp(nmodes)
    !! Temporary value of gamma for av.
    REAL(KIND = DP) :: gamma_v_tmp(nmodes)
    !! Temporary value of gamma v for av.
    REAL(KIND = DP) :: vkk(3, nbndfst)
    !! Electronic velocity $v_{nk}$
    REAL(KIND = DP) :: vkq(3, nbndfst)
    !! Electronic velocity $v_{nk+q}$
    REAL(KIND = DP) :: coskkq(nbndfst, nbndfst)
    !! $$(v_k \cdot v_{k+q}) / |v_k|^2$$
    !
    IF (adapt_smearing) CALL errore('selfen_phon_q', 'adapt_smearing cannot be used with phonon self-energy', 1)
    !
    !
    DO itemp = 1, nstemp  ! ZS added: If you just choose one  temperature, you do not need to consider it
      IF (iq == 1) THEN
        WRITE(stdout, '(/5x, a)') REPEAT('=',67)
        WRITE(stdout, '(5x, "Phonon (Imaginary) Self-Energy in the Migdal Approximation")')
        WRITE(stdout, '(5x, a/)') REPEAT('=',67)
        !
        IF (fsthick < 1.d3 ) WRITE(stdout, '(/5x, a, f10.6, a)' ) &
             'Fermi Surface thickness = ', fsthick * ryd2ev, ' eV'
        WRITE(stdout, '(/5x, a, f10.6, a)' ) 'Golden Rule strictly enforced with T = ', gtemp(itemp) * ryd2ev, ' eV'
        !
      ENDIF
      !
      !
      ! Now pre-treat phonon modes for efficiency
      ! Treat phonon frequency and Bose occupation
      wq(:) = zero  ! ZS added: frequency of phonon of each  mode on a specific q point
      DO imode = 1, nmodes
        ! wq(imode) = wf1r(imode, iq) ZS_SELF
        ! wq(imode) = wf(imode, iq)
        wq(imode) = wf1r(imode, iq)
        IF (wq(imode) > eps_acustic) THEN
          g2_tmp(imode) = one
          inv_wq(imode) = one / (two * wq(imode))
        ELSE
          g2_tmp(imode) = zero
          inv_wq(imode) = zero
        ENDIF
      ENDDO
      !
      DO ismear = 1, nsmear   ! ZS added: For understanding the code, you can just focus on the one smear.
        !
        degaussw0 = (ismear - 1) * delta_smear + degaussw
        !
        ! SP: Multiplication is faster than division ==> Important if called a lot
        !     in inner loops
        inv_degaussw0 = one / degaussw0
        inv_eptemp   = one / gtemp(itemp)
        !
        ! Fermi level and corresponding DOS
        !
        IF (efermi_read) THEN
          ef0 = fermi_energy ! ZS added: We alway suppose that the Fermi energy is read from the epw input file.
        ELSEIF (nsmear > 1) THEN
          !
          ef0 = efermig(etf, nbndsub, nkqf, nelec, wkf, degaussw0, ngaussw, 0, isk_dummy)
          ! if some bands are skipped (nbndskip /= 0), nelec has already been
          ! recalculated in ephwann_shuffle
          !
        ELSE !SP: This is added for efficiency reason because the efermig routine is slow
          ef0 = efnew
        ENDIF
        !
        dosef = dos_ef(ngaussw, degaussw0, ef0, etf, wkf, nkqf, nbndsub)
        !  N(Ef) in the equation for lambda is the DOS per spin
        dosef = dosef / two ! ZS added: What if the SOC case?
        !
        IF (iq == 1) THEN
          WRITE (stdout, 100) degaussw0 * ryd2ev, ngaussw
          WRITE (stdout, 101) dosef / ryd2ev, ef0 * ryd2ev
        ENDIF
        !
        CALL start_clock('PH SELF-ENERGY')
        !
        fermicount = 0     ! ZS added:  number of states on Fermi level.
        wgkk = zero        ! ZS added: Fermi-Dirac occupation factor $f_{nk}(T)$
        w0g1 = zero        ! ZS added: Dirac delta at k for the imaginary part of $\Sigma$
        gamma(:)   = zero  ! ZS added: Gamma is the imaginary part of the phonon self-energy
        gamma_v(:) = zero  ! ZS added: Gamma for calculation of the transportation properties, and seems no need for our calculation
        !
        DO ik = 1, nkf
          !
          ikk = 2 * ik - 1
          ikq = ikk + 1
          !
          coskkq = zero
          ! coskkq = (vk dot vkq) / |vk|^2  appears in Grimvall 8.20
          ! this is different from :   coskkq = (vk dot vkq) / |vk||vkq|
          ! In principle the only coskkq contributing to lambda_tr are both near the
          ! Fermi surface and the magnitudes will not differ greatly between vk and vkq
          ! we may implement the approximation to the angle between k and k+q
          ! vectors also listed in Grimvall
          ! ZS added : Calculate the velocity of electrons
          IF (vme == 'wannier') THEN
            DO ibnd = 1, nbndfst
              DO jbnd = 1, nbndfst
                !
                ! vmef is in units of Ryd * bohr
                !
                vkk(:, ibnd) = REAL(vmef(:, ibndmin - 1 + ibnd, ibndmin - 1 + ibnd, ikk))
                vkq(:, jbnd) = REAL(vmef(:, ibndmin - 1 + jbnd, ibndmin - 1 + jbnd, ikq))
                IF (ABS(vkk(1, ibnd)**two + vkk(2, ibnd)**two + vkk(3, ibnd)**two) > eps4) &
                  coskkq(ibnd, jbnd) = DDOT(3, vkk(:, ibnd), 1, vkq(:, jbnd), 1) / &
                                       DDOT(3, vkk(:, ibnd), 1, vkk(:, ibnd), 1)
              ENDDO
            ENDDO
          ELSE
            DO ibnd = 1, nbndfst
              DO jbnd = 1, nbndfst
                !
                ! v_(k,i) = 1/m <ki|p|ki> = dmef (:, i,i,k)
                ! 1/m  = 2 in Rydberg atomic units
                !
                vkk(:, ibnd) = REAL(dmef(:, ibndmin - 1 + ibnd, ibndmin - 1 + ibnd, ikk))
                vkq(:, jbnd) = REAL(dmef(:, ibndmin - 1 + jbnd, ibndmin - 1 + jbnd, ikq))
                IF (ABS(vkk(1, ibnd)**two + vkk(2, ibnd)**two + vkk(3, ibnd)**two) > eps4) &
                  coskkq(ibnd, jbnd) = DDOT(3, vkk(:, ibnd), 1, vkq(:, jbnd), 1)  / &
                                       DDOT(3, vkk(:, ibnd), 1, vkk(:, ibnd), 1)
              ENDDO
            ENDDO
          ENDIF
          !
          ! Here we must have ef, not ef0, to be consistent with ephwann_shuffle
          IF ((MINVAL(ABS(etf(:, ikk) - ef)) < fsthick) .AND. &
              (MINVAL(ABS(etf(:, ikq) - ef)) < fsthick)) THEN
            !
            fermicount = fermicount + 1
            DO imode = 1, nmodes  ! ZS added: Loop for the phonon modes, Calculate the self energy of each phonon mode.
              !
              DO ibnd = 1, nbndfst   ! ZS added: Loop for electron bands in the Fermi window at k and k+q
                !
                !  the fermi occupation for k
                ekk = etf(ibndmin - 1 + ibnd, ikk) - ef0
                !
                IF (delta_approx) THEN
                  w0g1 = w0gauss(ekk * inv_degaussw0, 0) * inv_degaussw0
                ELSE
                  wgkk = wgauss(-ekk * inv_eptemp, -99)
                ENDIF
                !
                DO jbnd = 1, nbndfst
                  !
                  !  the fermi occupation for k+q
                  ekq = etf(ibndmin - 1 + jbnd, ikq) - ef0
                  !
                  ! here we take into account the zero-point DSQRT(hbar/2M\omega)
                  ! with hbar = 1 and M already contained in the eigenmodes
                  ! g2 is Ry^2, wkf must already account for the spin factor
                  !
                  IF (shortrange .AND. (ABS(xqf(1, iq)) > eps8 .OR. ABS(xqf(2, iq)) > eps8 &
                                        .OR. ABS(xqf(3, iq)) > eps8)) THEN
                    ! SP: The abs has to be removed. Indeed the epf17 can be a pure imaginary
                    !     number, in which case its square will be a negative number.
                    g2 = REAL((epf17(jbnd, ibnd, imode, ik)**two) * inv_wq(imode) * g2_tmp(imode))
                  ELSE
                    g2 = (ABS(epf17(jbnd, ibnd, imode, ik))**two) * inv_wq(imode) * g2_tmp(imode)
                  ENDIF
                  !
                  IF (delta_approx) THEN
                    !
                    w0g2 = w0gauss(ekq * inv_degaussw0, 0) * inv_degaussw0
                    ! the expression below is positive-definite, but also an
                    ! approximation which neglects some fine features
                    weight = pi * wq(imode) * wkf(ikk) * w0g1 * w0g2
                    !
                  ELSE
                    !
                    wgkq = wgauss(-ekq * inv_eptemp, -99)
                    !
                    ! = k-point weight * [f(E_k) - f(E_k+q)] / [E_k+q - E_k - w_q + id]
                    ! This is the imaginary part of the phonon self-energy, sans
                    ! the matrix elements [Eq. 4 in Comput. Phys. Commun. 209, 116 (2016)]
                    !
                    !weight = wkf (ikk) * (wgkk - wgkq) * AIMAG(cone / (ekq - ekk - wq - ci * degaussw0))
                    !
                    ! SP: The expression below is the imag part of phonon self-energy,
                    ! sans matrix elements [Eq. 9 in Comput. Phys. Commun. 209, 116 (2016)]
                    !  = pi * k-point weight * [f(E_k) - f(E_k+q)] * delta[E_k+q - E_k - w_q]
                    !
                    weight = pi * wkf(ikk) * (wgkk - wgkq) * w0gauss((ekq - ekk - wq(imode)) * inv_degaussw0, 0) * inv_degaussw0
                    !
                  ENDIF
                  !
                  gamma(imode)   = gamma(imode)   + weight * g2
                  gamma_v(imode) = gamma_v(imode) + weight * g2 * (1.0d0 - coskkq(ibnd, jbnd))
                  !
                ENDDO ! jbnd
              ENDDO   ! ibnd
            ENDDO ! loop on q-modes
          ENDIF ! endif fsthick
        ENDDO ! loop on k
        !
        CALL stop_clock('PH SELF-ENERGY')
        !
        ! collect contributions from all pools (sum over k-points)
        ! this finishes the integral over the BZ  (k)
        !
        CALL mp_sum(gamma, inter_pool_comm)
        CALL mp_sum(gamma_v, inter_pool_comm)
        CALL mp_sum(fermicount, inter_pool_comm)
        CALL mp_barrier(inter_pool_comm)
        !
        ! An average over degenerate phonon-mode is performed.
        DO imode = 1, nmodes
          n = 0
          tmp1 = zero
          tmp2 = zero
          tmp3 = zero
          tmp4 = zero
          DO jmode = 1, nmodes
            IF (ABS(wq(imode) - wq(jmode)) < eps6) THEN
              n = n + 1
              IF (wq(jmode) > eps_acustic) THEN
                tmp1 =  tmp1 + gamma(jmode)   / pi / wq(imode)**two / dosef
                tmp2 =  tmp2 + gamma_v(jmode) / pi / wq(imode)**two / dosef
              ENDIF
              tmp3 =  tmp3 + gamma(jmode)
              tmp4 =  tmp4 + gamma_v(jmode)
            ENDIF
          ENDDO ! jbnd
          lambda_tmp(imode)   = tmp1 / FLOAT(n)
          lambda_v_tmp(imode) = tmp2 / FLOAT(n)
          gamma_tmp(imode)    = tmp3 / FLOAT(n)
          gamma_v_tmp(imode)  = tmp4 / FLOAT(n)
        ENDDO
        lambda_all(:, iq, ismear, itemp)   = lambda_tmp(:)
        lambda_v_all(:, iq, ismear, itemp) = lambda_v_tmp(:)
        gamma_all(:, iq, ismear, itemp)    = gamma_tmp(:)
        gamma_v_all(:, iq, ismear, itemp)  = gamma_v_tmp(:)
        lambda_tot    = SUM(lambda_all(:, iq, ismear, itemp))
        lambda_tr_tot = SUM(lambda_v_all(:, iq, ismear, itemp))
        !
        WRITE(stdout, '(/5x, "ismear = ",i5," iq = ",i7," coord.: ", 3f9.5, " wt: ", f9.5, " Temp: ", f8.3, "K")') ismear, iq, &
                                                                      xqf(:, iq), wqf(iq), gtemp(itemp) * ryd2ev / kelvin2eV
        WRITE(stdout, '(5x, a)') REPEAT('-', 67)
        !
        WRITE(stdout, '(/5x, a/)' ) 'HERE MBCSELF 1'
        DO imode = 1, nmodes
          !
          WRITE(stdout, 102) imode, lambda_all(imode, iq, ismear, itemp), &
                             ryd2mev * gamma_all(imode, iq, ismear, itemp), ryd2mev * wq(imode)
          WRITE(stdout, 104) imode, lambda_v_all(imode, iq, ismear, itemp), &
                             ryd2mev * gamma_v_all(imode, iq, ismear, itemp), ryd2mev * wq(imode)
          !
        ENDDO
        WRITE(stdout, '(/5x, a/)' ) 'HERE MBCSELF 2'
        !
        WRITE(stdout, 103) lambda_tot
        WRITE(stdout, 105) lambda_tr_tot
        WRITE(stdout, '(/5x, a/)' ) 'HERE MBCSELF 3'
        !
        IF (.NOT. specfun_ph) THEN
          WRITE(stdout, '(5x, a/)') REPEAT('-', 67)
          WRITE(stdout, '(/5x, a, i8, a, i8/)' ) 'Number of (k,k+q) pairs on the Fermi surface: ', fermicount, ' out of ', nktotf
        ENDIF
        !
      ENDDO !smears
      !
    ENDDO ! itemp
    100 FORMAT(5x, 'Gaussian Broadening: ', f10.6, ' eV, ngauss=', i4)
    101 FORMAT(5x, 'DOS =', f10.6, ' states/spin/eV/Unit Cell at Ef=', f10.6, ' eV')
    102 FORMAT(5x, 'lambda___( ', i3, ' )=', f15.6, '   gamma___=', f15.6, ' meV', '   omega=', f12.4, ' meV')
    103 FORMAT(5x, 'lambda___( tot )=', f15.6)
    104 FORMAT(5x, 'lambda_tr( ',i3,' )=', f15.6, '   gamma_tr=', f15.6, ' meV', '   omega=', f12.4, ' meV')
    105 FORMAT(5x, 'lambda_tr( tot )=', f15.6)
    !
    RETURN
    !
    !-----------------------------------------------------------------------
    END SUBROUTINE selfen_phon_q_MBC


    ! ZS added
    SUBROUTINE MBC_phon_q(iqq, iq, totq)
    !-----------------------------------------------------------------------
    !!    Compute the Mass Weighted MBC (Niu 2022)
    !!

    !-----------------------------------------------------------------------
    USE kinds,      ONLY : DP
    USE io_global,  ONLY : stdout, ionode_id
    USE modes,      ONLY : nmodes
    USE epwcom,     ONLY : nbndsub, fsthick, efermi_read, fermi_energy,  &
                           nstemp, ngaussw, degaussw, shortrange,        &
                           nsmear, delta_smear, eps_acustic, specfun_ph, &
                           delta_approx, vme, mbc_accustic_limit, mbc_smearing ! ZS added
    USE pwcom,      ONLY : nelec, ef
    USE cell_base,        ONLY : at
    USE ions_base,     ONLY : amass, tau, nat, ityp    ! ZS added
    USE constants_epw, ONLY : eps4, eps8, eps16, ci
    USE cell_base,     ONLY : at, bg
    USE klist_epw,  ONLY : isk_dummy
    USE elph2,      ONLY : epf17, ibndmax, ibndmin, etf, wkf, xqf, wqf, nkqf,   &
                           nkf, wf, nkqtotf, lambda_all, lambda_v_all,     &
                           dmef, vmef, gamma_all, gamma_v_all, efnew, nbndfst, &
                           gtemp, nktotf, nqtotf, adapt_smearing, MBC   ! ZS added
    USE mp,         ONLY : mp_barrier, mp_sum
    USE mp_global,  ONLY : inter_pool_comm
    USE mp_world,  ONLY : mpime
    USE constants_epw, ONLY : kelvin2eV, ryd2mev, ryd2ev, one, two, zero, eps4, eps6, eps8, czero ! ZS added
    USE constants,  ONLY : pi
    !
    IMPLICIT NONE
    !
    INTEGER, INTENT(in) :: iqq
    !! Current q-point index from the selecq
    INTEGER, INTENT(in) :: iq
    !! Current q-point index
    INTEGER, INTENT(in) :: totq
    !! Total number of q-points in selecq.fmt
    !
    ! Local variables
    !
    CHARACTER(LEN = 20) :: tp
    !! String for temperatures
    INTEGER :: ik
    !! Counter on the k-point index
    INTEGER :: ikk
    !! k-point index
    INTEGER :: ikq
    !! q-point index
    INTEGER :: iqm
    !! Current minus q index
    INTEGER :: ibnd
    !! Counter on bands at k
    INTEGER :: jbnd
    !! Counter on bands at k+q
    INTEGER :: imode
    !! Counter on mode
    INTEGER :: jmode
    !! atom index
    INTEGER :: iat
    !! atom index j
    INTEGER :: jat


    !! error msg
    INTEGER :: ierr

    INTEGER :: fermicount
    !! Number of states on the Fermi surface
    INTEGER :: ismear
    !! Number of smearing values for the Gaussian function
    INTEGER :: n
    !! Counter on number of mode degeneracies
    INTEGER :: itemp
    !! Counter on temperatuers
    INTEGER :: itmp
    !! temperatral integer
    !
    REAL(KIND = DP) :: g2
    !! Electron-phonon matrix elements squared in Ry^2
    REAL(KIND = DP) :: ef0
    !! Fermi energy level
    REAL(KIND = DP) :: dosef
    !! Density of state N(Ef)
    REAL(KIND = DP) :: ekk
    !! Eigen energy at k on the fine grid relative to the Fermi level
    REAL(KIND = DP) :: ekq
    !! Eigen energy at k+q on the fine grid relative to the Fermi level
    REAL(KIND = DP) :: wgkk
    !! Fermi-Dirac occupation factor $f_{nk}(T)$
    REAL(KIND = DP) :: wgkq
    !! Fermi-Dirac occupation factor $f_{nk+q}(T)$
    REAL(KIND = DP) :: weight
    !! Imaginary part of the phonhon self-energy factor
    !!$$ \pi N_q \Im(\frac{f_{nk}(T) - f_{mk+q(T)}}{\varepsilon_{nk}-\varepsilon_{mk+q}-\omega_{q\nu}+i\delta}) $$
    !! In practice the imaginary is performed with a delta Dirac
    REAL(KIND = DP) :: w0g1
    !! Dirac delta at k for the imaginary part of $\Sigma$
    REAL(KIND = DP) :: w0g2
    !! Energy of occ electron states at k
    REAL(KIND = DP) :: Eck
    !! Energy of occ electron states at k+q
    REAL(KIND = DP) :: Eckq
    !! Energy of valance electron states at k
    REAL(KIND = DP) :: Evk
    !! Energy of valance electron states at k+q
    REAL(KIND = DP) :: Evkq
    !! Energy of electron state
    REAL(KIND = DP) :: Ej
    !! Dirac delta at k+q for the imaginary part of $\Sigma$
    REAL(KIND = DP) :: massfac
    !! Dot product function
    REAL(KIND = DP) :: degaussw0
    !! degaussw0 = (ismear-1) * delta_smear + degaussw
    REAL(KIND = DP) :: inv_degaussw0
    !! Inverse degaussw0 for efficiency reasons
    REAL(KIND = DP) :: inv_eptemp
    !! Inverse of temperature define for efficiency reasons
    REAL(KIND = DP) :: lambda_tot
    !! Integrated lambda function
    REAL(KIND = DP) :: lambda_tr_tot
    !! Integrated transport lambda function
    REAL(KIND = DP) :: tmp1
    !! Temporary value of lambda for av.
    REAL(KIND = DP) :: tmp2
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: tmp3
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: tmp4
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: DDOT
    !! Dot product function
    REAL(KIND = DP), EXTERNAL :: dos_ef
    !! Function to compute the Density of States at the Fermi level
    REAL(KIND = DP), EXTERNAL :: efermig
    !! Return the fermi energy
    REAL(KIND = DP), EXTERNAL :: wgauss
    !! Fermi-Dirac distribution function (when -99)
    REAL(KIND = DP), EXTERNAL :: w0gauss
    !! This function computes the derivative of the Fermi-Dirac function
    !! It is therefore an approximation for a delta function
    REAL(KIND = DP) :: wq(nmodes)
    !! Phonon frequency on the fine grid
    COMPLEX(KIND = DP) :: tmp_MBC1
    !! tmp_MBC for each MBC sumation
    COMPLEX(KIND = DP) :: tmp_MBC2

    COMPLEX(KIND = DP), ALLOCATABLE :: MBC_q(:, :)
    COMPLEX(KIND = DP), ALLOCATABLE :: MBC_qm(:, :)

    REAL(KIND = DP) :: q(3)   ! q in fractional
    REAL(KIND = DP) :: qm(3)  ! -q (minus q) in fractional
    REAL(KIND = DP) :: qtmp(3)  ! -q (minus q) in fractional

    LOGICAL :: fermi_q, fermi_qm

    fermi_q = .FALSE.
    fermi_qm = .FALSE.

    !
    IF (adapt_smearing) CALL errore('MBC_phon_q', 'adapt_smearing cannot be used with phonon MBC', 1)
    IF (iq /= iqq) THEN
      WRITE(stdout, '(5x, a, i5, a, i5)') 'MBC_phon_q: iq /= iqq, problems happen', iq, ' /= ', iqq
      CALL errore('MBC_phon_q', 'iqq /= iq, problems happen', 1)
    ENDIF


    ALLOCATE(MBC_q(nmodes, nmodes), STAT = ierr)
    IF (ierr /= 0) CALL errore('MBC_phon_q', 'Error allocating MBC_q', 1)
    ALLOCATE(MBC_qm(nmodes, nmodes), STAT = ierr)
    IF (ierr /= 0) CALL errore('MBC_phon_q', 'Error allocating MBC_qm', 1)
    MBC_q = czero
    MBC_qm = czero


    iqm = totq - iq + 1
    q = xqf(:, iq)
    ! qm = xqf(:, iqm)

    CALL cryst_to_cart(1, q, bg, 1)
    ! CALL cryst_to_cart(1, qm, bg, 1)

    ! assert that q = -qm
    ! qtmp = q + qm
    WRITE(stdout, '(5x, "iq", i5)'), iq
    ! WRITE(stdout, '(5x, "iqm", i5)'), iqm
    WRITE(stdout, '(5x, "totq", i5)'), totq
    WRITE(stdout, '(5x, "Q is", 3f10.6)'), q
    ! WRITE(stdout, '(5x, "Qm is", 3f10.6)'), qm
    ! IF (NORM2(qtmp) > eps16) CALL errore("MBC_phon_q", 'Q and -Q is not matched, please check you filqf', 1)

    IF (iq == 1) THEN
      WRITE(stdout, '(/5x, a)') REPEAT('=',67)
      WRITE(stdout, '(5x, "Calculating Molecular Berry Curvature (MBC)")')
      WRITE(stdout, '(5x, a/)') REPEAT('=',67)
      !
      IF (fsthick < 1.d3 ) WRITE(stdout, '(/5x, a, f10.6, a)' ) &
           'Fermi Surface thickness = ', fsthick * ryd2ev, ' eV'
      ! WRITE(stdout, '(/5x, a, f10.6, a)' ) 'Golden Rule strictly enforced with T = ', gtemp(itemp) * ryd2ev, ' eV'
      !
    ENDIF

      ! ZS added: Check the mass
    DO itmp = 1, nat
      WRITE(stdout, '(/,5x,a, i5, a, i5)' )    'MBC: Atom ', itmp,  ' type is= ', ityp(itmp)
      WRITE(stdout, '(/,5x,a, i5, a, pe20.5E3)' ) 'MBC: Atom ', itmp , ' mass is= ', amass(ityp(itmp))
    ENDDO
    ! WRITE(stdout, '(/,5x,a, i5)' )    'MBC: Atom 2 type is= ', ityp(2)
    ! WRITE(stdout, '(/,5x,a, f12.6)' ) 'MBC: Atom 2 mass is= ', amass(ityp(3))
    ! WRITE(stdout, '(/,5x,a, i5)' )    'MBC: Atom 3 type is= ', ityp(3)
    ! WRITE(stdout, '(/,5x,a, f12.6)' ) 'MBC: Atom 3 mass is= ', amass(itjyp(3))
    !

    IF (efermi_read) THEN
      ef0 = fermi_energy ! ZS added: We alway suppose that the Fermi energy is read from the epw input file.
      ! ZS Debug
      ! WRITE(stdout, '(/,5x,a, f20.5, f20.5)' )    'ef0 and ef are: ', ef0 * ryd2ev, ef * ryd2ev
    ELSE 
      CALL errore('MBC_phon_q', 'MBC requrest efermi_read = .true.', 1)
    ENDIF
    
    CALL start_clock('MBC_phon_q')
    !
    fermicount = 0     ! ZS added:  number of states on Fermi level.

    DO ik = 1, nkf
      !
      ikk = 2 * ik - 1
      ikq = ikk + 1
      !
      ! Here we must have ef, not ef0, to be consistent with ephwann_shuffle
      IF ((MINVAL(ABS(etf(:, ikk) - ef)) < fsthick) .AND. &
          (MINVAL(ABS(etf(:, ikq) - ef)) < fsthick)) THEN
        !
        DO imode = 1, nmodes  ! ZS added: Loop for the phonon modes, 
          iat = INT((imode - 1) / 3) + 1
          DO jmode = 1, nmodes  ! ZS added: Loop for the phonon modes  
            jat = INT((jmode-1) / 3) + 1
            massfac = (1.d0 / 2.d0) / DSQRT(amass(ityp(iat)) * amass(ityp(jat)))
            ! massfac = 1 ! ZS TODO: Fix it

            !
            ! here we take into account the zero-point DSQRT(hbar/2M\omega)
            ! with hbar = 1 and M already contained in the eigenmodes
            !

            ! ZS added
            ! In EPW code and PRB 2007 Eq. 6, g_{mn, v}(k, q) = <m k+q|\partial_qv V| nk>, i.e., g_EPW=<k+q|M_q|q>
            ! However, In Niu 2022 PRB, they use the form if g_Niu = <k|M_q|k+q>, i.e., g_Niu = g_EPW^{\dagger}

            ! Moreover, there are two convention for the Fourier transformation of the annaliation
            ! operator for phonons, i.e., a^{\dagger}_{-q} (convention 1, which is the convention in PRB 2022 Qian Niu)
            ! or a_{q} (convention 2)
            ! Meanwhile, we adopt the Convention 2 in the coding note.


            ! [<phi_c k+q|g_a q|phi_v k>]^* \cdot [<phi_c k+q|g_b q|phi_v k>]^
            DO ibnd = 1, nbndfst   ! ZS added: Loop for electron bands in the Fermi window at k and k+q

              Eckq = etf(ibndmin - 1 + ibnd, ikq)
              Evkq = etf(ibndmin - 1 + ibnd, ikq)


              DO jbnd = 1, nbndfst
                Eck = etf(ibndmin - 1 + jbnd, ikk)
                Evk = etf(ibndmin - 1 + jbnd, ikk)

                IF ((Eckq > ef0) .AND. (Evk < ef0) .AND. (ABS(Eckq-Evk) > mbc_accustic_limit)) THEN
                  MBC_q(imode, jmode) = MBC_q(imode, jmode) + massfac * CONJG(epf17(ibnd, jbnd, imode, ik)) * epf17(ibnd, jbnd, jmode, ik)  / ((Eckq-Evk)**2 + mbc_smearing)
                  fermi_q = .TRUE.
                ENDIF

                IF ((Evkq < ef0) .AND. (Eck > ef0) .AND. (ABS(Evkq-Eck) > mbc_accustic_limit)) THEN
                  MBC_qm(imode, jmode) = MBC_qm(imode, jmode) + massfac * CONJG(epf17(ibnd, jbnd, imode, ik)) * epf17(ibnd, jbnd, jmode, ik)  / ((Evkq-Eck)**2 + mbc_smearing)
                  fermi_qm = .TRUE.
                ENDIF

                IF ((iq == 2) .AND.  fermi_q .AND. fermi_qm) THEN
                  WRITE(stdout, '(5x, a)') 'MBC WARNING !!!: MBC the valence and conductive condition is fufilled for both of the q and -q !!!'
                ENDIF
                ! IF ((iq == 2) .AND.  ((fermi_q == .FALSE.) .AND. (fermi_qm == .FALSE.))) THEN
                !   WRITE(stdout, '(5x, a)') 'MBC WARNING !!!: MBC the valence and conductive consition is fufilled for both of the q and -q !!!'
                !   WRITE(stdout, '(5x, a, I5, a, I5)') 'This hapen for ibnd=', ibnd, '&jbnd=', jbnd
                !   WRITE(stdout, '(5x, a, f20.5, f20.5)') 'and the energy of them are', Eckq *  ryd2ev, Evkq * ryd2ev
                ! ENDIF

                ! IF (((Eckq-ef0)*(Evk-ef0) < eps8) .AND. ((Eck-ef0)*(Evkq-ef0) < eps8) ) THEN

                ! IF ((iq == 2) .AND. (imode == 1) .AND (jmode == 1))
                ! ENDIF

                fermi_q  = .FALSE.
                fermi_qm = .FALSE.

              ENDDO ! jbnd
            ENDDO   ! ibnd
          ENDDO ! jmode q
        ENDDO ! imode q
      ENDIF ! endif fsthick
    ENDDO ! loop on k
    !
    ! WRITE(stdout, '(5x, "Ev-Ec > 1e-10 times (MBC fermi counts) is: ", 100i5)') fermicount
    CALL stop_clock('MBC_phon_q')
    !
    ! collect contributions from all pools (sum over k-points)
    ! this finishes the integral over the BZ  (k)
    !

    CALL mp_barrier(inter_pool_comm)
    CALL mp_sum(MBC_q(:,:), inter_pool_comm) ! electron k points is distributed by MPI, but not phonon q point
    CALL mp_sum(MBC_qm(:,:), inter_pool_comm)
    CALL mp_barrier(inter_pool_comm)

    ! MBC(:,:,iq) =  (ci / nktotf) * (MBC_q(:,:) - MBC_qm(:,:))
    ! MBC(:,:,iq) =  (ci / nktotf) * (MBC_q(:,:) - MBC_qm(:,:)) / 11000.0
    MBC(:,:,iq) =  (ci / nktotf) * (MBC_q(:,:) - MBC_qm(:,:))
    ! MBC(:,:,iq) =  (ci / nktotf) * MBC_qm(:,:)
    ! MBC(:,:,iq) =  (ci / nktotf) * MBC_q(:,:) 

    DEALLOCATE(MBC_q)
    DEALLOCATE(MBC_qm)

    RETURN
    !
    !-----------------------------------------------------------------------
    END SUBROUTINE MBC_phon_q

    ! ZS added
    SUBROUTINE write_MBC()
    !-----------------------------------------------------------------------
    !-----------------------------------------------------------------------
    USE kinds,      ONLY : DP
    USE io_global,  ONLY : stdout
    USE modes,      ONLY : nmodes
    USE epwcom,     ONLY : nbndsub, fsthick, efermi_read, fermi_energy,  &
                           nstemp, ngaussw, degaussw, shortrange,        &
                           nsmear, delta_smear, eps_acustic, specfun_ph, &
                           delta_approx, vme
    USE pwcom,      ONLY : nelec, ef
    USE ions_base,     ONLY : amass, tau, nat, ityp    ! ZS added
    USE constants_epw, ONLY : eps4, eps8, eps16, ci
    USE cell_base,     ONLY : at, bg
    USE klist_epw,  ONLY : isk_dummy
    USE elph2,      ONLY : epf17, ibndmax, ibndmin, etf, wkf, xqf, wqf, nkqf,   &
                           nkf, wf, nkqtotf, lambda_all, lambda_v_all,     &
                           dmef, vmef, gamma_all, gamma_v_all, efnew, nbndfst, &
                           gtemp, nktotf, nqtotf, adapt_smearing, MBC   ! ZS added
    USE mp,         ONLY : mp_barrier, mp_sum
    USE mp_world,  ONLY : mpime
    USE mp_global,  ONLY : inter_pool_comm
    USE io_global, ONLY : ionode_id, stdout
    USE constants_epw, ONLY : kelvin2eV, ryd2mev, ryd2ev, one, two, zero, eps4, eps6, eps8, czero ! ZS added
    USE constants,  ONLY : pi
    !
    IMPLICIT NONE
    !
    !
    CHARACTER(LEN = 20) :: tp
    !! String for temperatures
    CHARACTER(LEN = 256) :: fileMBC
    !! File name for phonon self energy
    INTEGER :: ik
    !! Counter on the k-point index
    INTEGER :: ikk
    !! k-point index
    INTEGER :: ikq
    !! q-point index
    INTEGER :: iqm
    !! Current minus q index
    INTEGER :: ibnd
    !! Counter on bands at k
    INTEGER :: jbnd
    !! Counter on bands at k+q
    INTEGER :: imode
    !! Counter on mode
    INTEGER :: jmode
    !! atom index
    INTEGER :: iat
    !! atom index j
    INTEGER :: jat


    !! error msg
    INTEGER :: ierr

    INTEGER :: mbcdata
    INTEGER :: im
    INTEGER :: iqt
    !
    REAL(KIND = DP) :: g2
    !! Electron-phonon matrix elements squared in Ry^2
    REAL(KIND = DP) :: ef0
    !! Fermi energy level
    REAL(KIND = DP) :: dosef
    !! Density of state N(Ef)
    REAL(KIND = DP) :: ekk
    !! Eigen energy at k on the fine grid relative to the Fermi level
    REAL(KIND = DP) :: ekq
    !! Eigen energy at k+q on the fine grid relative to the Fermi level
    REAL(KIND = DP) :: wgkk
    !! Fermi-Dirac occupation factor $f_{nk}(T)$
    REAL(KIND = DP) :: wgkq
    !! Fermi-Dirac occupation factor $f_{nk+q}(T)$
    REAL(KIND = DP) :: weight
    !! Imaginary part of the phonhon self-energy factor
    !!$$ \pi N_q \Im(\frac{f_{nk}(T) - f_{mk+q(T)}}{\varepsilon_{nk}-\varepsilon_{mk+q}-\omega_{q\nu}+i\delta}) $$
    !! In practice the imaginary is performed with a delta Dirac
    REAL(KIND = DP) :: w0g1
    !! Dirac delta at k for the imaginary part of $\Sigma$
    REAL(KIND = DP) :: w0g2
    !! Energy of occ electron states at k
    REAL(KIND = DP) :: Eck
    !! Energy of occ electron states at k+q
    REAL(KIND = DP) :: Eckq
    !! Energy of valance electron states at k
    REAL(KIND = DP) :: Evk
    !! Energy of valance electron states at k+q
    REAL(KIND = DP) :: Evkq
    !! Energy of electron state
    REAL(KIND = DP) :: Ej
    !! Dirac delta at k+q for the imaginary part of $\Sigma$
    REAL(KIND = DP) :: massfac
    !! Dot product function
    REAL(KIND = DP) :: degaussw0
    !! degaussw0 = (ismear-1) * delta_smear + degaussw
    REAL(KIND = DP) :: inv_degaussw0
    !! Inverse degaussw0 for efficiency reasons
    REAL(KIND = DP) :: inv_eptemp
    !! Inverse of temperature define for efficiency reasons
    REAL(KIND = DP) :: lambda_tot
    !! Integrated lambda function
    REAL(KIND = DP) :: lambda_tr_tot
    !! Integrated transport lambda function
    REAL(KIND = DP) :: tmp1
    !! Temporary value of lambda for av.
    REAL(KIND = DP) :: tmp2
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: tmp3
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: tmp4
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: DDOT
    !! Dot product function
    REAL(KIND = DP), EXTERNAL :: dos_ef
    !! Function to compute the Density of States at the Fermi level
    REAL(KIND = DP), EXTERNAL :: efermig
    !! Return the fermi energy
    REAL(KIND = DP), EXTERNAL :: wgauss
    !! Fermi-Dirac distribution function (when -99)
    REAL(KIND = DP), EXTERNAL :: w0gauss
    !! This function computes the derivative of the Fermi-Dirac function
    !! It is therefore an approximation for a delta function
    REAL(KIND = DP) :: wq(nmodes)
    !! Phonon frequency on the fine grid
    COMPLEX(KIND = DP) :: tmp_MBC1
    !! tmp_MBC for each MBC sumation
    COMPLEX(KIND = DP) :: tmp_MBC2

    COMPLEX(KIND = DP), ALLOCATABLE :: MBC_q(:, :)

    REAL(KIND = DP) :: q(3)   ! q in fractional
    REAL(KIND = DP) :: qm(3)  ! -q (minus q) in fractional
    REAL(KIND = DP) :: qtmp(3)  ! -q (minus q) in fractional


    CALL start_clock('write_MBC')
    !

    IF (mpime == ionode_id) THEN

      OPEN(UNIT = mbcdata, FILE = 'MBCmat.fmt', status = "unknown", action = "write")

      DO iqt = 1, nqtotf
        WRITE(mbcdata, '(5x, "#####################################################################")')
        WRITE(mbcdata, '(5x, "MBC Matrix for iq: ", i5)'), iqt

        DO im = 1, nmodes
          WRITE(mbcdata, '(5x, 1000e15.3)') , MBC(im, : , iqt)
        ENDDO

      ENDDO

      CLOSE(mbcdata)

    ENDIF

    CALL stop_clock('write_MBC')

    RETURN
    !
    !-----------------------------------------------------------------------
    END SUBROUTINE write_MBC


    ! ZS added
    SUBROUTINE write_MBC_k_diss()
    !-----------------------------------------------------------------------
    !-----------------------------------------------------------------------
    USE kinds,      ONLY : DP
    USE io_global,  ONLY : stdout
    USE modes,      ONLY : nmodes
    USE epwcom,     ONLY : nbndsub, fsthick, efermi_read, fermi_energy,  &
                           nstemp, ngaussw, degaussw, shortrange,        &
                           nsmear, delta_smear, eps_acustic, specfun_ph, &
                           delta_approx, vme
    USE pwcom,      ONLY : nelec, ef
    USE ions_base,     ONLY : amass, tau, nat, ityp    ! ZS added
    USE constants_epw, ONLY : eps4, eps8, eps16, ci
    USE cell_base,     ONLY : at, bg
    USE klist_epw,  ONLY : isk_dummy
    USE elph2,      ONLY : epf17, ibndmax, ibndmin, etf, wkf, xqf, wqf, nkqf,   &
                           nkf, wf, nkqtotf, lambda_all, lambda_v_all,     &
                           dmef, vmef, gamma_all, gamma_v_all, efnew, nbndfst, &
                           gtemp, nktotf, nqtotf, adapt_smearing, MBC_Gamma_total, nkp_total  ! ZS added
    USE mp,         ONLY : mp_barrier, mp_sum
    USE mp_world,  ONLY : mpime
    USE mp_global,  ONLY : inter_pool_comm
    USE io_global, ONLY : ionode_id, stdout
    USE constants_epw, ONLY : kelvin2eV, ryd2mev, ryd2ev, one, two, zero, eps4, eps6, eps8, czero ! ZS added
    USE constants,  ONLY : pi
    !
    IMPLICIT NONE
    !
    !
    CHARACTER(LEN = 20) :: tp
    !! String for temperatures
    CHARACTER(LEN = 256) :: fileMBC
    !! File name for phonon self energy
    INTEGER :: ik
    !! Counter on the k-point index
    INTEGER :: ikk
    !! k-point index
    INTEGER :: ikq
    !! q-point index
    INTEGER :: iqm
    !! Current minus q index
    INTEGER :: ibnd
    !! Counter on bands at k
    INTEGER :: jbnd
    !! Counter on bands at k+q
    INTEGER :: imode
    !! Counter on mode
    INTEGER :: jmode
    !! atom index
    INTEGER :: iat
    !! atom index j
    INTEGER :: jat


    !! error msg
    INTEGER :: ierr

    INTEGER :: mbcdata
    INTEGER :: im
    INTEGER :: ikp
    !
    REAL(KIND = DP) :: g2
    !! Electron-phonon matrix elements squared in Ry^2
    REAL(KIND = DP) :: ef0
    !! Fermi energy level
    REAL(KIND = DP) :: dosef
    !! Density of state N(Ef)
    REAL(KIND = DP) :: ekk
    !! Eigen energy at k on the fine grid relative to the Fermi level
    REAL(KIND = DP) :: ekq
    !! Eigen energy at k+q on the fine grid relative to the Fermi level
    REAL(KIND = DP) :: wgkk
    !! Fermi-Dirac occupation factor $f_{nk}(T)$
    REAL(KIND = DP) :: wgkq
    !! Fermi-Dirac occupation factor $f_{nk+q}(T)$
    REAL(KIND = DP) :: weight
    !! Imaginary part of the phonhon self-energy factor
    !!$$ \pi N_q \Im(\frac{f_{nk}(T) - f_{mk+q(T)}}{\varepsilon_{nk}-\varepsilon_{mk+q}-\omega_{q\nu}+i\delta}) $$
    !! In practice the imaginary is performed with a delta Dirac
    REAL(KIND = DP) :: w0g1
    !! Dirac delta at k for the imaginary part of $\Sigma$
    REAL(KIND = DP) :: w0g2
    !! Energy of occ electron states at k
    REAL(KIND = DP) :: Eck
    !! Energy of occ electron states at k+q
    REAL(KIND = DP) :: Eckq
    !! Energy of valance electron states at k
    REAL(KIND = DP) :: Evk
    !! Energy of valance electron states at k+q
    REAL(KIND = DP) :: Evkq
    !! Energy of electron state
    REAL(KIND = DP) :: Ej
    !! Dirac delta at k+q for the imaginary part of $\Sigma$
    REAL(KIND = DP) :: massfac
    !! Dot product function
    REAL(KIND = DP) :: degaussw0
    !! degaussw0 = (ismear-1) * delta_smear + degaussw
    REAL(KIND = DP) :: inv_degaussw0
    !! Inverse degaussw0 for efficiency reasons
    REAL(KIND = DP) :: inv_eptemp
    !! Inverse of temperature define for efficiency reasons
    REAL(KIND = DP) :: lambda_tot
    !! Integrated lambda function
    REAL(KIND = DP) :: lambda_tr_tot
    !! Integrated transport lambda function
    REAL(KIND = DP) :: tmp1
    !! Temporary value of lambda for av.
    REAL(KIND = DP) :: tmp2
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: tmp3
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: tmp4
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: DDOT
    !! Dot product function
    REAL(KIND = DP), EXTERNAL :: dos_ef
    !! Function to compute the Density of States at the Fermi level
    REAL(KIND = DP), EXTERNAL :: efermig
    !! Return the fermi energy
    REAL(KIND = DP), EXTERNAL :: wgauss
    !! Fermi-Dirac distribution function (when -99)
    REAL(KIND = DP), EXTERNAL :: w0gauss
    !! This function computes the derivative of the Fermi-Dirac function
    !! It is therefore an approximation for a delta function
    REAL(KIND = DP) :: wq(nmodes)
    !! Phonon frequency on the fine grid
    COMPLEX(KIND = DP) :: tmp_MBC1
    !! tmp_MBC for each MBC sumation
    COMPLEX(KIND = DP) :: tmp_MBC2


    REAL(KIND = DP) :: q(3)   ! q in fractional
    REAL(KIND = DP) :: qm(3)  ! -q (minus q) in fractional
    REAL(KIND = DP) :: qtmp(3)  ! -q (minus q) in fractional


    CALL start_clock('write_MBC_k_diss')
    !

    IF (mpime == ionode_id) THEN

      OPEN(NEWUNIT = mbcdata, FILE = 'MBC_Gamma_kk.fmt', status = "unknown", action = "write")

      DO ikp = 1, nkp_total
        WRITE(mbcdata, '(5x, 1000(pe15.5E3))') , MBC_Gamma_total(: , ikp)
      ENDDO

      CLOSE(mbcdata)

    ENDIF

    CALL stop_clock('write_MBC_k_diss')

    RETURN
    !
    !-----------------------------------------------------------------------
    END SUBROUTINE write_MBC_k_diss


    ! ZS added
    SUBROUTINE write_uf_phonon()
    !-----------------------------------------------------------------------
    !-----------------------------------------------------------------------
    USE kinds,      ONLY : DP
    USE io_global,  ONLY : stdout
    USE modes,      ONLY : nmodes
    USE epwcom,     ONLY : nbndsub, fsthick, efermi_read, fermi_energy,  &
                           nstemp, ngaussw, degaussw, shortrange,        &
                           nsmear, delta_smear, eps_acustic, specfun_ph, &
                           delta_approx, ep_raman_nummodes, ep_raman_modes_str ! ZS added
    USE pwcom,      ONLY : nelec, ef
    USE ions_base,     ONLY : amass, tau, nat, ityp    ! ZS added
    USE constants_epw, ONLY : eps4, eps8, eps16, ci
    USE cell_base,     ONLY : at, bg
    USE klist_epw,  ONLY : isk_dummy
    USE elph2,      ONLY : nkf, wf, nkqtotf, lambda_all, lambda_v_all,     &
                           dmef, vmef, gamma_all, gamma_v_all, efnew, nbndfst, &         
                           gtemp, nktotf, nqtotf, adapt_smearing, ufe_allq, ufe1_allq ! ZS added 
                           
    USE mp,         ONLY : mp_barrier, mp_sum
    USE mp_world,  ONLY : mpime
    USE mp_global,  ONLY : inter_pool_comm
    USE io_global, ONLY : ionode_id, stdout
    USE constants_epw, ONLY : kelvin2eV, ryd2mev, ryd2ev, one, two, zero, eps4, eps6, eps8, czero ! ZS added
    USE constants,  ONLY : pi
    !
    IMPLICIT NONE
    !


    ! INTEGER, INTENT(in) :: mode
    ! !! Current q-point index
    ! INTEGER, INTENT(in) :: iq
    !! Current q-point index
    !
    INTEGER :: ik
    !! Counter on the k-point index
    INTEGER :: ikk
    !! k-point index
    INTEGER :: ikq
    !! q-point index
    INTEGER :: iqm
    !! Current minus q index
    INTEGER :: ibnd
    !! Counter on bands at k
    INTEGER :: jbnd
    !! Counter on bands at k+q
    INTEGER :: imode
    !! Counter on mode
    INTEGER :: jmode
    !! atom index
    INTEGER :: iat
    !! atom index j
    INTEGER :: jat


    !! error msg
    INTEGER :: ierr

    INTEGER :: ufefileunit, ufe1fileunit
    INTEGER :: i, im, nmodes_inputed
    INTEGER :: iqt

    CHARACTER(LEN=200) :: trimed_modes_str, str_tmp
    CHARACTER(LEN=200) :: splited_mode_str(100)
    INTEGER :: index_of_modes(100)
    !
    REAL(KIND = DP) :: tmp1
    !! Temporary value of lambda for av.
    REAL(KIND = DP) :: tmp2
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: tmp3
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: tmp4
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: wq(nmodes)
    !! Phonon frequency on the fine grid
    COMPLEX(KIND = DP) :: tmp_MBC1
    !! tmp_MBC for each MBC sumation
    COMPLEX(KIND = DP) :: tmp_MBC2

    COMPLEX(KIND = DP), ALLOCATABLE :: MBC_q(:, :)

    REAL(KIND = DP) :: q(3)   ! q in fractional


    CALL start_clock('write_uf_phonon')
    !

    IF (mpime == ionode_id) THEN
      ufefileunit = 5001
      ufe1fileunit = ufefileunit + 1

      OPEN(UNIT = ufefileunit, FILE = 'ufe_no_mbc.fmt', status = "unknown", action = "write")
      OPEN(UNIT = ufe1fileunit, FILE = 'ufe_with_mbc.fmt', status = "unknown", action = "write")

      IF (ep_raman_nummodes < 0) THEN
        DO iqt = 1, nqtotf
          WRITE(ufefileunit, '(5x, "#####################################################################")')
          WRITE(ufefileunit, '(5x, "Phonon Wavefunction (no MBC) for iq: ", i5)'), iqt


          WRITE(ufe1fileunit, '(5x, "#####################################################################")')
          WRITE(ufe1fileunit, '(5x, "Phonon Wavefunction (with MBC) for iq: ", i5)'), iqt

          DO im = 1, nmodes
            WRITE(ufefileunit, '(5x, 1000(pe15.3))') , ufe_allq(im, : , iqt)
            WRITE(ufe1fileunit, '(5x, 1000(pe15.3))') , ufe1_allq(im, : , iqt)
          ENDDO

        ENDDO
      ENDIF

      IF (ep_raman_nummodes > 0) THEN
        ! WRITE(stdout, '(5x, "ep_raman_modes_str before trim: ", a)') ep_raman_modes_str
        trimed_modes_str = TRIM(ADJUSTL(ep_raman_modes_str))
        ! WRITE(stdout, '(5x, "ep_raman_modes_str after  trim: ", a)') trimed_modes_str
        CALL split_string(trimed_modes_str, ",", splited_mode_str, nmodes_inputed)
        ! WRITE(stdout, '(5x, "The number of phonon modes to be writen is: ", i5)') nmodes_inputed

        DO i = 1, nmodes_inputed
          str_tmp =  TRIM(ADJUSTL(splited_mode_str(i)))
          READ(str_tmp, *, iostat=ierr) index_of_modes(i)
          IF (ierr /= 0) THEN
            WRITE(stdout, '(5x, "Wrong Format of ep_raman_modes_str")') 
          ENDIF
         ! WRITE(stdout, '(5x, "index are", i5)') index_of_modes(i)
        ENDDO


        DO iqt = 1, nqtotf
          WRITE(ufefileunit, '(5x, "#####################################################################")')
          WRITE(ufefileunit, '(5x, "Phonon Wavefunction for iq (row vector): ", i5)'), iqt

          WRITE(ufe1fileunit, '(5x, "#####################################################################")')
          WRITE(ufe1fileunit, '(5x, "Phonon Wavefunction for iq (row vector): ", i5)'), iqt

          DO i = 1, nmodes_inputed
            im = index_of_modes(i)
            WRITE(ufefileunit, '(5x, 1000(pe15.3))') , ufe_allq(:, im , iqt)
            WRITE(ufe1fileunit, '(5x, 1000(pe15.3))') , ufe1_allq(:, im , iqt)
          ENDDO

        ENDDO
      ENDIF


      CLOSE(ufefileunit)
      CLOSE(ufe1fileunit)

    ENDIF ! end if io node

    CALL stop_clock('write_uf_phonon')

    RETURN
    !
    !-----------------------------------------------------------------------
    END SUBROUTINE write_uf_phonon



    ! ZS added
    SUBROUTINE calc_am_of_phonon()
    !-----------------------------------------------------------------------
    !-----------------------------------------------------------------------
    USE kinds,      ONLY : DP
    USE io_global,  ONLY : stdout
    USE modes,      ONLY : nmodes
    USE epwcom,     ONLY : mbc_write_am ! ZS added
    USE pwcom,      ONLY : nelec, ef
    USE ions_base,     ONLY : amass, tau, nat, ityp    ! ZS added
    USE constants_epw, ONLY : eps4, eps8, eps16, ci
    USE cell_base,     ONLY : at, bg
    USE klist_epw,  ONLY : isk_dummy
    USE elph2,      ONLY : nkf, wf, nkqtotf, gtemp, nktotf, nqtotf, ufe_allq ,ufe1_allq, xqf, wf, wf1r ! ZS added 
                           
    USE mp,         ONLY : mp_barrier, mp_sum
    USE mp_world,  ONLY : mpime
    USE mp_global,  ONLY : inter_pool_comm
    USE io_global, ONLY : ionode_id, stdout
    USE constants_epw, ONLY : kelvin2eV, ryd2mev, ryd2ev, one, two, zero, eps4, eps6, eps8, czero, cone, ci ! ZS added
    USE constants,  ONLY : pi
    !
    IMPLICIT NONE
    !
    CHARACTER(LEN=256) :: amfilename

    !
    INTEGER :: ik
    !! Counter on the k-point index
    INTEGER :: ikk
    !! k-point index
    INTEGER :: ikq
    !! q-point index
    INTEGER :: iqm
    !! Current minus q index
    INTEGER :: ibnd
    !! Counter on bands at k
    INTEGER :: jbnd
    !! Counter on bands at k+q
    INTEGER :: imode
    !! Counter on mode
    INTEGER :: jmode
    !! atom index
    INTEGER :: iat
    !! atom index j
    INTEGER :: jat

    !! error msg
    INTEGER :: ierr

    INTEGER :: amfileunit
    INTEGER :: i, im
    INTEGER :: iqt

    INTEGER :: index_of_modes(100)
    !
    REAL(KIND = DP) :: tmp1
    !! Temporary value of lambda for av.
    REAL(KIND = DP) :: tmp2
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: tmp3
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: tmp4



    REAL(KIND = DP) :: q_delta(3)
    REAL(KIND = DP), ALLOCATABLE :: q_dist(:)  ! 

    REAL(KIND = DP), ALLOCATABLE :: AM_z_allq(:, :)  ! 
    !! Temporary value of lambda_v for av.

    ! COMPLEX(KIND = DP), ALLOCATABLE :: Mx(:, :)
    ! COMPLEX(KIND = DP), ALLOCATABLE :: My(:, :)
    COMPLEX(KIND = DP), ALLOCATABLE :: DMz(:, :)  ! = \otimes _ Natoms mz
    COMPLEX(KIND = DP), ALLOCATABLE :: ufvec(:)  ! 
    COMPLEX(KIND = DP) :: mz(3, 3) ! ZS added: The Lie Algebra of SO(3) group



    ALLOCATE(q_dist(nqtotf), STAT = ierr)
    IF (ierr /= 0) CALL errore('calc_am_of_phonon', 'Error allocating q_dist', 1)
    ALLOCATE(DMz(nmodes, nmodes), STAT = ierr)
    IF (ierr /= 0) CALL errore('calc_am_of_phonon', 'Error allocating DMz', 1)
    ALLOCATE(ufvec(nmodes), STAT = ierr)
    IF (ierr /= 0) CALL errore('calc_am_of_phonon', 'Error allocating uf', 1)
    ALLOCATE(AM_z_allq(nmodes, nqtotf), STAT = ierr)
    IF (ierr /= 0) CALL errore('calc_am_of_phonon', 'Error allocating AM_z', 1)

    q_dist = zero
    DMz = czero
    mz = czero
    mz(1, 2) = -ci
    mz(2, 1) = ci

    DO i = 1, nat
      DMz((i-1)*3 + 1:(i-1)*3 + 3, (i-1)*3 + 1:(i-1)*3 + 3) = mz
    ENDDO

    CALL start_clock('calc_am_of_phonon')

    DO iqt = 1, nqtotf
      DO im = 1, nmodes
        IF (mbc_write_am == 1) THEN
          ufvec(:) = ufe_allq(:, im, iqt)
        ELSE
          ufvec(:) = ufe1_allq(:, im, iqt)
        ENDIF
        AM_z_allq(im, iqt) = REAL(DOT_PRODUCT(ufvec, MATMUL(DMz, ufvec)))
      ENDDO
    ENDDO


    IF (mpime == ionode_id) THEN

      !! For debug
      ! WRITE(stdout, '(5x, "Mz is: ")') 
      ! DO i = 1, 3 
      !   WRITE(stdout, '(5x,  1000(pe15.3))') , mz(i, :)
      ! ENDDO
      ! WRITE(stdout, '(5x, "DMz is: ")') 
      ! DO i = 1, 6 
      !   WRITE(stdout, '(5x, 1000(f4.1))') , DMz(i,:)
      ! ENDDO
      ! WRITE(stdout, '(5x, "CALC_AM HERE 2")') 


      ! crystal to cartesian coordinates
      CALL cryst_to_cart(nqtotf, xqf, bg, 1)


      DO iqt = 1, nqtotf
        IF (iqt == 1) THEN
          tmp1 = 0 ! The q point distance
        ELSE
          q_delta = xqf(:, iqt) - xqf(:, iqt-1)
          tmp1 = tmp1 + SQRT(DOT_PRODUCT(q_delta, q_delta))
        ENDIF
        q_dist(iqt) = tmp1
      ENDDO

      ! back from cartesian to crystal coordinates
      CALL cryst_to_cart(nqtotf, xqf, at, -1)

      IF (mbc_write_am == 1) THEN
        amfilename = "am_no_mbc.dat"
      ELSE
        amfilename = "am_with_mbc.dat"
      ENDIF

      OPEN(UNIT = amfileunit, FILE = amfilename, status = "unknown", action = "write")
      WRITE(amfileunit, '(a, 5x, a, 5x, a)') '# q', 'frequency (meV)', 'AM_z'

      DO im = 1, nmodes
        DO iqt = 1, nqtotf
          IF (mbc_write_am == 1) THEN
            WRITE(amfileunit, '(f10.5, f10.5, f10.5)') q_dist(iqt), ryd2mev * wf(im, iqt), AM_z_allq(im, iqt)
          ELSE
            WRITE(amfileunit, '(f10.5, f10.5, f10.5)') q_dist(iqt), ryd2mev * wf1r(im, iqt), AM_z_allq(im, iqt)
          ENDIF
        ENDDO
        WRITE(amfileunit, '(a)')  ' '
      ENDDO

      CLOSE(amfileunit)

    ENDIF

    CALL stop_clock('calc_am_of_phonon')
    DEALLOCATE(q_dist, STAT = ierr)
    IF (ierr /= 0) CALL errore('calc_am_of_phonon', 'Error deallocating q_dist', 1)
    DEALLOCATE(DMz, STAT = ierr)
    IF (ierr /= 0) CALL errore('calc_am_of_phonon', 'Error deallocating DMz', 1)
    DEALLOCATE(ufvec, STAT = ierr)
    IF (ierr /= 0) CALL errore('calc_am_of_phonon', 'Error deallocating ufvec', 1)
    DEALLOCATE(AM_z_allq, STAT = ierr)
    IF (ierr /= 0) CALL errore('calc_am_of_phonon', 'Error deallocating AM_z_allq', 1)

    RETURN
    !
    !-----------------------------------------------------------------------
    END SUBROUTINE calc_am_of_phonon



    SUBROUTINE plot_band_mbc()
    !-----------------------------------------------------------------------
    !!
    !! This routine writes output files for phonon dispersion and band structure
    !! SP : Modified so that it works with the current plotband.x of QE 5
    !! Zhang Shuai: This program  is modified for write the phonon freq. with the MBC
    !!
    USE kinds,         ONLY : DP
    USE cell_base,     ONLY : at, bg
    USE modes,         ONLY : nmodes
    USE epwcom,        ONLY : nbndsub, filqf, filkf
    USE elph2,         ONLY : etf, nkf, nqtotf, wf, xkf, xqf, nkqtotf, nktotf, wf1r
    USE constants_epw, ONLY : ryd2mev, ryd2ev, zero
    USE io_var,        ONLY : iufilfreq, iufileig
    USE elph2,         ONLY : nkqf
    USE io_global,     ONLY : ionode_id
    USE mp,            ONLY : mp_barrier, mp_sum
    USE mp_global,     ONLY : inter_pool_comm, my_pool_id
    USE poolgathering, ONLY : poolgather2
    !
    IMPLICIT NONE
    !
    ! Local variables
    INTEGER :: ik
    !! Global k-point index
    INTEGER :: ikk
    !! Index for the k-point
    INTEGER :: ikq
    !! Index for the q-point
    INTEGER :: ibnd
    !! Band index
    INTEGER :: imode
    !! Mode index
    INTEGER :: iq
    !! Global q-point index
    INTEGER :: ierr
    !! Error status
    REAL(KIND = DP) :: dist
    !! Distance from G-point
    REAL(KIND = DP) :: dprev
    !! Previous distance
    REAL(KIND = DP) :: dcurr
    !! Current distance
    REAL(KIND = DP), ALLOCATABLE :: xkf_all(:, :)
    !! K-points on the full k grid (all pools)
    REAL(KIND = DP), ALLOCATABLE :: etf_all(:, :)
    !! Eigenenergies on the full k grid (all pools)
    !
    IF (filqf /= ' ') THEN
      !
      IF (my_pool_id == ionode_id) THEN
        !
        OPEN(iufilfreq, FILE = "phband.freq", FORM = 'formatted')
        WRITE(iufilfreq, '(" &plot nbnd=", i4, ", nks=", i6, " /")') nmodes, nqtotf
        !
        ! crystal to cartesian coordinates
        CALL cryst_to_cart(nqtotf, xqf, bg, 1)
        !
        dist  = zero
        dprev = zero
        dcurr = zero
        DO iq = 1, nqtotf
          !
          IF (iq /= 1) THEN
            dist = DSQRT((xqf(1, iq) - xqf(1, iq - 1)) * (xqf(1, iq) - xqf(1, iq - 1)) &
                       + (xqf(2, iq) - xqf(2, iq - 1)) * (xqf(2, iq) - xqf(2, iq - 1)) &
                       + (xqf(3, iq) - xqf(3, iq - 1)) * (xqf(3, iq) - xqf(3, iq - 1)))
          ELSE
            dist = zero
          ENDIF
          dcurr = dprev + dist
          dprev = dcurr
          WRITE(iufilfreq, '(10x, 3f10.6)') xqf(:, iq)
          WRITE(iufilfreq, '(1000f14.4)') (wf1r(imode, iq) * ryd2mev, imode = 1, nmodes)
          !
        ENDDO
        CLOSE(iufilfreq)
        !
        ! back from cartesian to crystal coordinates
        CALL cryst_to_cart(nqtotf, xqf, at, -1)
        !
      ENDIF
    ENDIF ! filqf
    !
    IF (filkf /= ' ') THEN
      !
      DO ik = 1, nkf
        !
        ikk = 2 * ik - 1
        ikq = ikk + 1
        !
      ENDDO
      !
      ALLOCATE(xkf_all(3, nkqtotf), STAT = ierr)
      IF (ierr /= 0) CALL errore('plot_band', 'Error allocating xkf_all', 1)
      ALLOCATE(etf_all(nbndsub, nkqtotf), STAT = ierr)
      IF (ierr /= 0) CALL errore('plot_band', 'Error allocating etf_all', 1)
      !
#if defined(__MPI)
      CALL poolgather2(3,       nkqtotf, nkqf, xkf, xkf_all)
      CALL poolgather2(nbndsub, nkqtotf, nkqf, etf, etf_all)
      CALL mp_barrier(inter_pool_comm)
#else
      !
      xkf_all = xkf
      etf_all = etf
#endif
      !
      IF (my_pool_id == ionode_id) THEN
        !
        OPEN(iufileig, FILE = "band.eig", FORM = 'formatted')
        WRITE(iufileig, '(" &plot nbnd=", i4, ", nks=", i6, " /")') nbndsub, nktotf
        !
        ! crystal to cartesian coordinates
        CALL cryst_to_cart(nkqtotf, xkf_all, bg, 1)
        !
        dist  = zero
        dprev = zero
        dcurr = zero
        DO ik = 1, nktotf
          !
          ikk = 2 * ik - 1
          ikq = ikk + 1
          !
          IF (ikk /= 1) THEN
            dist = DSQRT((xkf_all(1, ikk) - xkf_all(1, ikk - 2)) * (xkf_all(1, ikk) - xkf_all(1, ikk - 2)) &
                       + (xkf_all(2, ikk) - xkf_all(2, ikk - 2)) * (xkf_all(2, ikk) - xkf_all(2, ikk - 2)) &
                       + (xkf_all(3, ikk) - xkf_all(3, ikk - 2)) * (xkf_all(3, ikk) - xkf_all(3, ikk - 2)))
          ELSE
            dist = 0.d0
          ENDIF
          dcurr = dprev + dist
          dprev = dcurr
          WRITE(iufileig, '(10x, 3f10.6)') xkf_all(:, ikk)
          WRITE(iufileig, '(1000f20.12)') (etf_all(ibnd, ikk) * ryd2ev, ibnd = 1, nbndsub)
          !
        ENDDO
        CLOSE(iufileig)
        !
        ! back from cartesian to crystal coordinates
        CALL cryst_to_cart(nkqtotf, xkf_all, at, -1)
        !
      ENDIF
      CALL mp_barrier(inter_pool_comm)
      !
      DEALLOCATE(xkf_all, STAT = ierr)
      IF (ierr /= 0) CALL errore('plot_band', 'Error deallocating xkf_all', 1)
      DEALLOCATE(etf_all, STAT = ierr)
      IF (ierr /= 0) CALL errore('plot_band', 'Error deallocating etf_all', 1)
      !
    ENDIF ! filkf
    !
    RETURN
    !
    !----------------------------------------------------------------------------
    END SUBROUTINE plot_band_mbc



    ! ZS added
    SUBROUTINE Nesting_phon_q(iqq, iq, totq)
    !-----------------------------------------------------------------------
    !!    Compute the Nesting vector of q for the given q list (Ref. PhysRevB.77.165135)
    !!
    !-----------------------------------------------------------------------
    USE kinds,      ONLY : DP
    USE io_global,  ONLY : stdout, ionode_id
    USE modes,      ONLY : nmodes
    USE epwcom,     ONLY : nbndsub, fsthick, efermi_read, fermi_energy,  &
                           nstemp, ngaussw, degaussw, shortrange,        &
                           nsmear, delta_smear, eps_acustic, specfun_ph, &
                           delta_approx, vme, mbc_accustic_limit ! ZS added
    USE pwcom,      ONLY : nelec, ef
    USE cell_base,        ONLY : at
    USE ions_base,     ONLY : amass, tau, nat, ityp    ! ZS added
    USE constants_epw, ONLY : eps4, eps8, eps16, ci
    USE cell_base,     ONLY : at, bg
    USE klist_epw,  ONLY : isk_dummy
    USE elph2,      ONLY : epf17, ibndmax, ibndmin, etf, wkf, xqf, wqf, nkqf,   &
                           nkf, wf, nkqtotf, lambda_all, lambda_v_all,     &
                           dmef, vmef, gamma_all, gamma_v_all, efnew, nbndfst, &
                           gtemp, nktotf, nqtotf, adapt_smearing, Nesting_q ! ZS added
    USE mp,         ONLY : mp_barrier, mp_sum
    USE mp_global,  ONLY : inter_pool_comm, my_pool_id
    USE mp_world,  ONLY : mpime
    USE constants_epw, ONLY : kelvin2eV, ryd2mev, ryd2ev, one, two, zero, eps4, eps6, eps8, czero ! ZS added
    USE constants,  ONLY : pi
    !
    IMPLICIT NONE
    !
    INTEGER, INTENT(in) :: iqq
    !! Current q-point index from the selecq
    INTEGER, INTENT(in) :: iq
    !! Current q-point index
    INTEGER, INTENT(in) :: totq
    !! Total number of q-points in selecq.fmt
    !
    CHARACTER(LEN = 20) :: tp
    !! String for temperatures
    CHARACTER(LEN = 256) :: fileMBC
    !! File name for phonon self energy
    INTEGER :: ik
    !! Counter on the k-point index
    INTEGER :: ikk
    !! k-point index
    INTEGER :: ikq
    !! q-point index
    INTEGER :: iqm
    !! Current minus q index
    INTEGER :: ibnd
    !! Counter on bands at k
    INTEGER :: jbnd
    !! Counter on bands at k+q
    INTEGER :: imode
    !! Counter on mode
    INTEGER :: jmode
    !! atom index
    INTEGER :: iat
    !! atom index j
    INTEGER :: jat
    INTEGER :: itmp 
    INTEGER :: nestingfileunit


    !! error msg
    INTEGER :: ierr

    !! Number of states on the Fermi surface
    INTEGER :: ismear
    !! Number of smearing values for the Gaussian function
    INTEGER :: n
    !! Counter on number of mode degeneracies
    !
    REAL(KIND = DP) :: ef0
    !! Fermi energy level
    REAL(KIND = DP) :: Eck
    !! Energy of occ electron states at k+q
    REAL(KIND = DP) :: Eckq
    !! Energy of valance electron states at k
    REAL(KIND = DP) :: Evk
    !! Energy of valance electron states at k+q
    REAL(KIND = DP) :: Evkq
    !! Energy of electron state
    REAL(KIND = DP) :: Ej
    !! Dirac delta at k+q for the imaginary part of $\Sigma$
    REAL(KIND = DP) :: massfac
    !! Dot product function
    REAL(KIND = DP) :: degaussw0
    !! degaussw0 = (ismear-1) * delta_smear + degaussw
    REAL(KIND = DP) :: inv_degaussw0
    !! Inverse degaussw0 for efficiency reasons
    REAL(KIND = DP) :: inv_eptemp
    !! Inverse of temperature define for efficiency reasons
    REAL(KIND = DP) :: lambda_tot
    !! Integrated lambda function
    REAL(KIND = DP) :: lambda_tr_tot
    !! Integrated transport lambda function
    REAL(KIND = DP) :: tmp1
    !! Temporary value of lambda for av.
    REAL(KIND = DP) :: tmp2
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: tmp3
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: tmp4
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP), EXTERNAL :: wgauss
    !! Fermi-Dirac distribution function (when -99)
    REAL(KIND = DP), EXTERNAL :: w0gauss
    !! This function computes the derivative of the Fermi-Dirac function
    !! It is therefore an approximation for a delta function


    REAL(KIND = DP) :: q_delta(3)
    REAL(KIND = DP), ALLOCATABLE :: q_dist(:)  ! 
    ! REAL(KIND = DP), ALLOCATABLE :: Nesting_q(:)

    REAL(KIND = DP) :: q(3)   ! q in fractional
    !

    REAL(KIND = DP) :: fermicount_q, fermicount_qm



    ! WRITE(stdout, '(5x, "iq", i5)'), iq
    ! WRITE(stdout, '(5x, "totq", i5)'), totq
    ! WRITE(stdout, '(5x, "Q is", 3f10.6)'), q
    ! ! WRITE(stdout, '(5x, "Qm is", 3f10.6)'), qm
    ! IF (NORM2(qtmp) > eps16) CALL errore("MBC_phon_q", 'Q and -Q is not matched, please check you filqf', 1)

    IF (iq == 1) THEN
      WRITE(stdout, '(/5x, a)') REPEAT('=',67)
      WRITE(stdout, '(5x, "Calculating The nesting of q (i.e, the equaly weighted MBC)")')
      WRITE(stdout, '(5x, a/)') REPEAT('=',67)
      !
      IF (fsthick < 1.d3 ) WRITE(stdout, '(/5x, a, f10.6, a)' ) &
           'Fermi Surface thickness = ', fsthick * ryd2ev, ' eV'
      ! WRITE(stdout, '(/5x, a, f10.6, a)' ) 'Golden Rule strictly enforced with T = ', gtemp(itemp) * ryd2ev, ' eV'
      !
    ENDIF

    IF (efermi_read) THEN
      ef0 = fermi_energy ! ZS added: We alway suppose that the Fermi energy is read from the epw input file.
    ELSE 
      CALL errore('Nesting_phon_q', 'Nesting_phonon_q requrest efermi_read = .true.', 1)
    ENDIF
    
    CALL start_clock('Nesting_phon_q')
    !
    fermicount_q = 0     ! ZS added:  number of states on Fermi level.
    fermicount_qm = 0     ! ZS added:  number of states on Fermi level.


    tmp2 = 1.0 * nkf

    DO ik = 1, nkf
      !
      ikk = 2 * ik - 1
      ikq = ikk + 1
      !


      ! Here we must have ef, not ef0, to be consistent with ephwann_shuffle
      IF ((MINVAL(ABS(etf(:, ikk) - ef)) < fsthick) .AND. &
          (MINVAL(ABS(etf(:, ikq) - ef)) < fsthick)) THEN
        !
        ! DO imode = 1, nmodes  ! ZS added: Loop for the phonon modes, 
        !   iat = INT((imode - 1) / 3) + 1
        !   DO jmode = 1, nmodes  ! ZS added: Loop for the phonon modes  
            ! jat = INT((jmode-1) / 3) + 1
            ! massfac = (1.d0 / 2.d0) / DSQRT(amass(ityp(iat)) * amass(ityp(jat)))
            DO ibnd = 1, nbndfst   ! ZS added: Loop for electron bands in the Fermi window at k and k+q

              Eckq = etf(ibndmin - 1 + ibnd, ikq)
              Evkq = etf(ibndmin - 1 + ibnd, ikq)


              DO jbnd = 1, nbndfst
                Eck = etf(ibndmin - 1 + jbnd, ikk)
                Evk = etf(ibndmin - 1 + jbnd, ikk)

                IF ((Eckq > ef0) .AND. (Evk < ef0) .AND. (ABS(Eckq-Evk) > mbc_accustic_limit)) THEN
                  ! MBC_q(imode, jmode) = MBC_q(imode, jmode) + massfac * CONJG(epf17(ibnd, jbnd, imode, ik)) * epf17(ibnd, jbnd, jmode, ik)  / (Eckq-Evk)**2 
                  Nesting_q(iq) = Nesting_q(iq) + 1.0  / (Eckq-Evk)**2 
                  fermicount_q = fermicount_q + 1
                ENDIF

                IF ((Evkq < ef0) .AND. (Eck > ef0) .AND. (ABS(Evkq-Eck) > mbc_accustic_limit)) THEN
                  ! MBC_qm(imode, jmode) = MBC_qm(imode, jmode) + massfac * CONJG(epf17(ibnd, jbnd, imode, ik)) * epf17(ibnd, jbnd, jmode, ik)  / (Evkq-Eck)**2 
                  Nesting_q(iq) = Nesting_q(iq) - 1.0  / (Evkq-Eck)**2 
                  ! Nesting_q(iq) = Nesting_q(iq) + 1.0  / (Evkq-Eck)**2 
                  fermicount_qm = fermicount_qm + 1
                ENDIF

                ! IF (((Eckq-ef0)*(Evk-ef0) < eps8) .AND. ((Eck-ef0)*(Evkq-ef0) < eps8) ) THEN
                ! ENDIF

              ENDDO ! jbnd
            ENDDO   ! ibnd
        !   ENDDO ! jmode q
        ! ENDDO ! imode q
      ENDIF ! endif fsthick
    ENDDO ! loop on k

    Nesting_q(iq) = (1.0 / nktotf) * Nesting_q(iq)

    CALL stop_clock('Nesting_phon_q')

    !
    !
    ! collect contributions from all pools (sum over k-points)
    ! this finishes the integral over the BZ  (k)
    CALL mp_barrier(inter_pool_comm)
    CALL mp_sum(Nesting_q(iq), inter_pool_comm) ! electron k points is distributed by MPI, but not phonon q point
    CALL mp_sum(fermicount_q, inter_pool_comm) ! electron k points is distributed by MPI, but not phonon q point
    CALL mp_sum(fermicount_qm, inter_pool_comm) ! electron k points is distributed by MPI, but not phonon q point
    CALL mp_sum(tmp2, inter_pool_comm) ! electron k points is distributed by MPI, but not phonon q point
    CALL mp_barrier(inter_pool_comm)

    WRITE(stdout, '("====================================================")')
    WRITE(stdout, '("At iq = ", I5, "  nkf is:", pe20.5E3 )') iq, tmp2
    WRITE(stdout, '("At iq = ", I5, "  Fermi count of q and -q are", pe20.5E3, pe20.5e3 )') iq, fermicount_q, fermicount_qm
    WRITE(stdout, '("====================================================")')


    RETURN
    !
    !-----------------------------------------------------------------------
    END SUBROUTINE Nesting_phon_q


    ! ZS added
    SUBROUTINE write_mbc_nesting()
    !-----------------------------------------------------------------------
    !!    Compute the Nesting vector of q for the given q list (Ref. PhysRevB.77.165135)
    !!
    !-----------------------------------------------------------------------
    USE kinds,      ONLY : DP
    USE io_global,  ONLY : stdout, ionode_id
    USE modes,      ONLY : nmodes
    USE epwcom,     ONLY : nbndsub, fsthick, efermi_read, fermi_energy,  &
                           nstemp, ngaussw, degaussw, shortrange,        &
                           nsmear, delta_smear, eps_acustic, specfun_ph, &
                           delta_approx, vme 
    USE pwcom,      ONLY : nelec, ef
    USE cell_base,        ONLY : at
    USE ions_base,     ONLY : amass, tau, nat, ityp    ! ZS added
    USE constants_epw, ONLY : eps4, eps8, eps16, ci
    USE cell_base,     ONLY : at, bg
    USE klist_epw,  ONLY : isk_dummy
    USE elph2,      ONLY : epf17, ibndmax, ibndmin, etf, wkf, xqf, wqf, nkqf,   &
                           nkf, wf, nkqtotf, lambda_all, lambda_v_all,     &
                           dmef, vmef, gamma_all, gamma_v_all, efnew, nbndfst, &
                           gtemp, nktotf, nqtotf, adapt_smearing, Nesting_q ! ZS added
    USE mp,         ONLY : mp_barrier, mp_sum
    USE mp_global,  ONLY : inter_pool_comm, my_pool_id
    USE mp_world,  ONLY : mpime
    USE constants_epw, ONLY : kelvin2eV, ryd2mev, ryd2ev, one, two, zero, eps4, eps6, eps8, czero ! ZS added
    USE constants,  ONLY : pi
    !
    IMPLICIT NONE
    !
    CHARACTER(LEN = 20) :: tp
    !! String for temperatures
    CHARACTER(LEN = 256) :: fileMBC
    !! File name for phonon self energy
    INTEGER :: ik
    !! Counter on the k-point index
    INTEGER :: ikk
    !! k-point index
    INTEGER :: ikq
    !! q-point index
    INTEGER :: iqm
    !! Current minus q index
    INTEGER :: ibnd
    !! Counter on bands at k
    INTEGER :: jbnd
    !! Counter on bands at k+q
    INTEGER :: imode
    !! Counter on mode
    INTEGER :: jmode
    !! atom index
    INTEGER :: iat
    !! atom index j
    INTEGER :: jat
    INTEGER :: itmp 
    INTEGER :: iq ! index of q
    INTEGER :: nestingfileunit


    !! error msg
    INTEGER :: ierr

    INTEGER :: fermicount
    !! Number of states on the Fermi surface
    INTEGER :: ismear
    !! Number of smearing values for the Gaussian function
    INTEGER :: n
    !! Counter on number of mode degeneracies
    !
    REAL(KIND = DP) :: ef0
    !! Fermi energy level
    REAL(KIND = DP) :: Eck
    !! Energy of occ electron states at k+q
    REAL(KIND = DP) :: Eckq
    !! Energy of valance electron states at k
    REAL(KIND = DP) :: Evk
    !! Energy of valance electron states at k+q
    REAL(KIND = DP) :: Evkq
    !! Energy of electron state
    REAL(KIND = DP) :: Ej
    !! Dirac delta at k+q for the imaginary part of $\Sigma$
    REAL(KIND = DP) :: massfac
    !! Dot product function
    REAL(KIND = DP) :: degaussw0
    !! degaussw0 = (ismear-1) * delta_smear + degaussw
    REAL(KIND = DP) :: inv_degaussw0
    !! Inverse degaussw0 for efficiency reasons
    REAL(KIND = DP) :: inv_eptemp
    !! Inverse of temperature define for efficiency reasons
    REAL(KIND = DP) :: lambda_tot
    !! Integrated lambda function
    REAL(KIND = DP) :: lambda_tr_tot
    !! Integrated transport lambda function
    REAL(KIND = DP) :: tmp1
    !! Temporary value of lambda for av.
    REAL(KIND = DP) :: tmp2
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: tmp3
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: tmp4
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP), EXTERNAL :: wgauss
    !! Fermi-Dirac distribution function (when -99)
    REAL(KIND = DP), EXTERNAL :: w0gauss
    !! This function computes the derivative of the Fermi-Dirac function
    !! It is therefore an approximation for a delta function


    REAL(KIND = DP) :: q_delta(3)
    REAL(KIND = DP), ALLOCATABLE :: q_dist(:)  ! 

    REAL(KIND = DP) :: q(3)   ! q in fractional
    !

    IF (mpime == ionode_id) THEN

      ALLOCATE(q_dist(nqtotf), STAT = ierr)
      IF (ierr /= 0) CALL errore('Nesting_phon_q', 'Error allocating q_dist', 1)

      ! crystal to cartesian coordinates
      CALL cryst_to_cart(nqtotf, xqf, bg, 1)

      DO iq = 1, nqtotf
        IF (iq == 1) THEN
          tmp1 = 0 ! The q point distance
        ELSE
          q_delta = xqf(:, iq) - xqf(:, iq-1)
          tmp1 = tmp1 + SQRT(DOT_PRODUCT(q_delta, q_delta))
        ENDIF
        q_dist(iq) = tmp1
      ENDDO

      ! back from cartesian to crystal coordinates
      CALL cryst_to_cart(nqtotf, xqf, at, -1)


      nestingfileunit = 6005

      OPEN(UNIT = nestingfileunit, FILE = "Nesting.dat", status = "unknown", action = "write")
      WRITE(nestingfileunit, '(a, 5x, a, 5x)') '# q', '# Equaly weitht MBC (a.u.)'

      DO iq = 1, nqtotf
        WRITE(nestingfileunit, '(f10.5, pe20.5E3)') q_dist(iq), Nesting_q(iq)
      ENDDO

      CLOSE(nestingfileunit)

      DEALLOCATE(q_dist, STAT = ierr)
      IF (ierr /= 0) CALL errore('Nesting_phonon_q', 'Error deallocating q_dist', 1)


    ENDIF

    RETURN

    !-----------------------------------------------------------------------
    END SUBROUTINE write_mbc_nesting 


    ! ZS added
    SUBROUTINE MBC_diss_k()
    !-----------------------------------------------------------------------
    !!    Compute the Mass Weighted MBC (Niu 2022)
    !!

    !-----------------------------------------------------------------------
    USE kinds,      ONLY : DP
    USE io_global,  ONLY : stdout, ionode_id
    USE modes,      ONLY : nmodes
    USE epwcom,     ONLY : nbndsub, fsthick, efermi_read, fermi_energy,  &
                           nstemp, ngaussw, degaussw, shortrange,        &
                           nsmear, delta_smear, eps_acustic, specfun_ph, &
                           delta_approx, vme, mbc_accustic_limit, mbc_smearing ! ZS added
    USE pwcom,      ONLY : nelec, ef
    USE cell_base,        ONLY : at
    USE ions_base,     ONLY : amass, tau, nat, ityp    ! ZS added
    USE constants_epw, ONLY : eps4, eps8, eps16, ci
    USE cell_base,     ONLY : at, bg
    USE klist_epw,  ONLY : isk_dummy
    USE elph2,      ONLY : epf17, ibndmax, ibndmin, etf, wkf, xqf, wqf, nkqf,   &
                           nkf, wf, nkqtotf, lambda_all, lambda_v_all,     &
                           dmef, vmef, gamma_all, gamma_v_all, efnew, nbndfst, &
                           gtemp, nktotf, nqtotf, adapt_smearing, MBC_Gamma_total, epf17_plane, etf_plane, &
                           ikp_loc, ikp_loc_begin, ikp_loc_begin, nkp_local, nkp_total, ufe1_allq, kplane, UF_GAMMA   ! ZS added
    USE mp,         ONLY : mp_barrier, mp_sum
    USE mp_global,  ONLY : inter_pool_comm
    USE mp_world,  ONLY : mpime
    USE constants_epw, ONLY : kelvin2eV, ryd2mev, ryd2ev, one, two, zero, eps4, eps6, eps8, czero ! ZS added
    USE constants,  ONLY : pi
    !
    IMPLICIT NONE
    !
    ! Local variables
    !
    CHARACTER(LEN = 20) :: tp
    !! String for temperatures
    INTEGER :: ik
    !! Counter on the k-point index
    INTEGER :: ikk
    !! k-point index
    INTEGER :: ikq
    !! q-point index
    INTEGER :: iqm
    !! Current minus q index
    INTEGER :: ibnd
    !! Counter on bands at k
    INTEGER :: jbnd
    !! Counter on bands at k+q
    INTEGER :: imode
    !! Counter on mode
    INTEGER :: jmode
    !! atom index
    INTEGER :: iat
    !! atom index j
    INTEGER :: jat


    !! error msg
    INTEGER :: ierr

    INTEGER :: fermicount
    !! Number of states on the Fermi surface
    INTEGER :: ismear
    !! Number of smearing values for the Gaussian function
    INTEGER :: n
    !! Counter on number of mode degeneracies
    INTEGER :: itemp
    !! Counter on temperatuers
    INTEGER :: itmp
    !! temperatral integer
    !
    REAL(KIND = DP) :: g2
    !! Electron-phonon matrix elements squared in Ry^2
    REAL(KIND = DP) :: ef0
    !! Fermi energy level
    REAL(KIND = DP) :: dosef
    !! Density of state N(Ef)
    REAL(KIND = DP) :: ekk
    !! Eigen energy at k on the fine grid relative to the Fermi level
    REAL(KIND = DP) :: ekq
    !! Eigen energy at k+q on the fine grid relative to the Fermi level
    REAL(KIND = DP) :: wgkk
    !! Fermi-Dirac occupation factor $f_{nk}(T)$
    REAL(KIND = DP) :: wgkq
    !! Fermi-Dirac occupation factor $f_{nk+q}(T)$
    REAL(KIND = DP) :: weight
    !! Imaginary part of the phonhon self-energy factor
    !!$$ \pi N_q \Im(\frac{f_{nk}(T) - f_{mk+q(T)}}{\varepsilon_{nk}-\varepsilon_{mk+q}-\omega_{q\nu}+i\delta}) $$
    !! In practice the imaginary is performed with a delta Dirac
    REAL(KIND = DP) :: w0g1
    !! Dirac delta at k for the imaginary part of $\Sigma$
    REAL(KIND = DP) :: w0g2
    !! Energy of occ electron states at k
    REAL(KIND = DP) :: Eck
    !! Energy of occ electron states at k+q
    REAL(KIND = DP) :: Eckq
    !! Energy of valance electron states at k
    REAL(KIND = DP) :: Evk
    !! Energy of valance electron states at k+q
    REAL(KIND = DP) :: Evkq
    !! Energy of electron state
    REAL(KIND = DP) :: Ej
    !! Dirac delta at k+q for the imaginary part of $\Sigma$
    REAL(KIND = DP) :: massfac
    !! Dot product function
    REAL(KIND = DP) :: degaussw0
    !! degaussw0 = (ismear-1) * delta_smear + degaussw
    REAL(KIND = DP) :: inv_degaussw0
    !! Inverse degaussw0 for efficiency reasons
    REAL(KIND = DP) :: inv_eptemp
    !! Inverse of temperature define for efficiency reasons
    REAL(KIND = DP) :: lambda_tot
    !! Integrated lambda function
    REAL(KIND = DP) :: lambda_tr_tot
    !! Integrated transport lambda function
    REAL(KIND = DP) :: tmp1
    !! Temporary value of lambda for av.
    REAL(KIND = DP) :: tmp2
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: tmp3
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: tmp4
    !! Temporary value of lambda_v for av.
    REAL(KIND = DP) :: DDOT
    !! Dot product function
    REAL(KIND = DP), EXTERNAL :: dos_ef
    !! Function to compute the Density of States at the Fermi level
    REAL(KIND = DP), EXTERNAL :: efermig
    !! Return the fermi energy
    REAL(KIND = DP), EXTERNAL :: wgauss
    !! Fermi-Dirac distribution function (when -99)
    REAL(KIND = DP), EXTERNAL :: w0gauss
    !! This function computes the derivative of the Fermi-Dirac function
    !! It is therefore an approximation for a delta function
    REAL(KIND = DP) :: wq(nmodes)
    !! Phonon frequency on the fine grid
    COMPLEX(KIND = DP) :: tmp_MBC1
    !! tmp_MBC for each MBC sumation
    COMPLEX(KIND = DP) :: tmp_MBC2

    COMPLEX(KIND = DP), ALLOCATABLE :: MBC_q(:, :)
    COMPLEX(KIND = DP), ALLOCATABLE :: MBC_qm(:, :)

    REAL(KIND = DP) :: q(3)   ! q in fractional
    REAL(KIND = DP) :: qm(3)  ! -q (minus q) in fractional
    REAL(KIND = DP) :: qtmp(3)  ! -q (minus q) in fractional

    LOGICAL :: fermi_q, fermi_qm


    COMPLEX(KIND = DP), ALLOCATABLE :: uf_tmp1(:) ! tmp wave function
    COMPLEX(KIND = DP), ALLOCATABLE :: uf_tmp2(:) ! tmp wave function
    COMPLEX(KIND = DP), ALLOCATABLE :: mattmp(:,:) ! tmp wave function


    fermi_q = .FALSE.
    fermi_qm = .FALSE.

    !
    IF (adapt_smearing) CALL errore('MBC_phon_q', 'adapt_smearing cannot be used with phonon MBC', 1)

    ALLOCATE(MBC_q(nmodes, nmodes), STAT = ierr)
    IF (ierr /= 0) CALL errore('MBC_phon_q', 'Error allocating MBC_q', 1)
    ALLOCATE(MBC_qm(nmodes, nmodes), STAT = ierr)
    IF (ierr /= 0) CALL errore('MBC_phon_q', 'Error allocating MBC_qm', 1)

    ALLOCATE(uf_tmp1(nmodes), STAT = ierr)
    ALLOCATE(uf_tmp2(nmodes), STAT = ierr)
    ALLOCATE(mattmp(nmodes, nmodes), STAT = ierr)



    q = zero
    ! qm = xqf(:, iqm)

    CALL cryst_to_cart(1, q, bg, 1)
    ! CALL cryst_to_cart(1, qm, bg, 1)

    ! assert that q = -qm
    ! qtmp = q + qm

    IF (efermi_read) THEN
      ef0 = fermi_energy ! ZS added: We alway suppose that the Fermi energy is read from the epw input file.
      WRITE(stdout, '(/,5x,a, f20.5, f20.5)' )    'ef0 and ef are: ', ef0 * ryd2ev, ef * ryd2ev
    ELSE 
      CALL errore('MBC_phon_q', 'MBC requrest efermi_read = .true.', 1)
    ENDIF
    
    !
    fermicount = 0     ! ZS added:  number of states on Fermi level.

    DO ik = 1, nkp_local
      ikp_loc = ikp_loc_begin + ik - 1

      MBC_q = czero
      MBC_qm = czero

      ! Here we must have ef, not ef0, to be consistent with ephwann_shuffle
      IF ((MINVAL(ABS(etf_plane(:, ikp_loc) - ef)) < fsthick)) THEN
        !
        DO imode = 1, nmodes  ! ZS added: Loop for the phonon modes, 
          iat = INT((imode - 1) / 3) + 1
          DO jmode = 1, nmodes  ! ZS added: Loop for the phonon modes  
            jat = INT((jmode-1) / 3) + 1
            massfac = (1.d0 / 2.d0) / DSQRT(amass(ityp(iat)) * amass(ityp(jat)))

            ! [<phi_c k+q|g_a q|phi_v k>]^* \cdot [<phi_c k+q|g_b q|phi_v k>]^
            DO ibnd = 1, nbndfst! ZS added: Loop for electron bands in the Fermi window at k and k+q

              Eck = etf_plane(ibndmin - 1 + ibnd, ikp_loc)

              DO jbnd = 1, nbndfst
                Evk = etf_plane(ibndmin - 1 + jbnd, ikp_loc)

                IF ((Eck > ef0) .AND. (Evk < ef0) .AND. (ABS(Eck-Evk) > mbc_accustic_limit)) THEN
                  ! MBC_q(imode, jmode) = MBC_q(imode, jmode) + 1.0 / ((Eck-Evk)**2 + mbc_smearing)
                  ! MBC_q(imode, jmode) = MBC_q(imode, jmode) + 1.0 / ((Eckq-Evk)**2 + mbc_smearing)
                  ! MBC_q(imode, jmode) = MBC_q(imode, jmode) + 1.0 / ((Eck-Evk)**2)
                  ! MBC_q(imode, jmode) = MBC_q(imode, jmode) + 1.0 / ((Eck-Evk)**2)
                  ! WRITE(stdout, '(/,5x,a, f20.5)' )    '(Eck-Evk)^2 is: ', (Eck-Evk)**2 * ryd2ev * ryd2ev
                  ! MBC_q(imode, jmode) = MBC_q(imode, jmode) + 1.0 / ((Eck-Evk)**2 + mbc_smearing)
                  ! MBC_q(imode, jmode) = MBC_q(imode, jmode) + CONJG(epf17_plane(ibnd, jbnd, imode, ikp_loc)) * epf17_plane(ibnd, jbnd, jmode, ikp_loc)  / ((Eck-Evk)**2 + mbc_smearing)
                  MBC_q(imode, jmode) = MBC_q(imode, jmode) + massfac * CONJG(epf17_plane(ibnd, jbnd, imode, ikp_loc)) * epf17_plane(ibnd, jbnd, jmode, ikp_loc)  / ((Eck-Evk)**2 + mbc_smearing)
                ENDIF

                IF ((Eck < ef0) .AND. (Evk > ef0) .AND. (ABS(Eck-Evk) > mbc_accustic_limit)) THEN
                  ! MBC_q(imode, jmode) = MBC_q(imode, jmode) + 1.0 / ((Eck-Evk)**2 + mbc_smearing)
                  ! MBC_q(imode, jmode) = MBC_q(imode, jmode) + 1.0 / ((Eckq-Evk)**2 + mbc_smearing)
                  ! MBC_q(imode, jmode) = MBC_q(imode, jmode) + 1.0 / ((Eck-Evk)**2)
                  ! MBC_q(imode, jmode) = MBC_q(imode, jmode) + 1.0 / ((Eck-Evk)**2)
                  ! WRITE(stdout, '(/,5x,a, f20.5)' )    '(Eck-Evk)^2 is: ', (Eck-Evk)**2 * ryd2ev * ryd2ev
                  MBC_qm(imode, jmode) = MBC_qm(imode, jmode) + massfac * CONJG(epf17_plane(ibnd, jbnd, imode, ikp_loc)) * epf17_plane(ibnd, jbnd, jmode, ikp_loc)  / ((Eck-Evk)**2 + mbc_smearing)
                ENDIF


              ENDDO ! jbnd
            ENDDO   ! ibnd

            ! ZS DEBUG MPI
            ! MBC_Gamma_total(:, :, ikp_loc) = mpime + 1
          ENDDO ! jmode q
        ENDDO ! imode q
      ENDIF ! endif fsthick

      DO imode = 1, nmodes
        uf_tmp1(:) = UF_GAMMA(:, imode) 
        mattmp = ci * ci * (MBC_q(:,:) - MBC_qm(:,:))  ! the different to mbc with constant number, we only plot the relative value
        uf_tmp2 = MATMUL(mattmp, uf_tmp1)        ! Check and fix
        MBC_Gamma_total(imode, ikp_loc) = REAL(DOT_PRODUCT(uf_tmp2, uf_tmp1))     ! Check and fix; If vec1, and vec2 are complex, dot_product doing conjg(vec1)*vec2
        ! MBC_Gamma_total(imode, ikp_loc) = MAXVAL(REAL(epf17_plane(:, :, imode, ikp_loc)))     ! Check and fix; If vec1, and vec2 are complex, dot_product doing conjg(vec1)*vec2
        ! MBC_Gamma_total(imode, ikp_loc) = REAL(MBC_q(imode, imode))     ! Check and fix; If vec1, and vec2 are complex, dot_product doing conjg(vec1)*vec2
        ! MBC_Gamma_total(imode, ikp_loc) = REAL(DOT_PRODUCT(uf_tmp2, uf_tmp1))     ! Check and fix; If vec1, and vec2 are complex, dot_product doing conjg(vec1)*vec2
        ! MBC_Gamma_total(imode, ikp_loc) = mpime + 1     ! Check and fix; If vec1, and vec2 are complex, dot_product doing conjg(vec1)*vec2
        ! MBC_Gamma_total(imode, ikp_loc) = etf_plane(imode, ikp_loc)*ryd2ev
        ! MBC_Gamma_total(imode, ikp_loc) = etf_plane(43, ikp_loc)*ryd2ev
        ! MBC_Gamma_total(imode, ikp_loc) = REAL(MBC_q(imode, imode))     ! Check and fix; If vec1, and vec2 are complex, dot_product doing conjg(vec1)*vec2
      ENDDO

      ! ZS DEBUG MPI
      ! MBC_Gamma_total(:, ikp_loc) = kplane(1, ikp_loc)*kplane(1, ikp_loc) + kplane(2, ikp_loc)*kplane(2, ikp_loc) 
    ENDDO ! loop on k

    WRITE(stdout, '(/,5x,a)') 'UF_Gamma: '
    DO imode = 1, nmodes
      WRITE(stdout, '(5x, 1000(pe15.3))') , UF_GAMMA(imode, :)
    ENDDO
    !

    CALL mp_barrier(inter_pool_comm)
    !CALL mp_sum(MBC_qm(:,:), inter_pool_comm)
    !CALL mp_barrier(inter_pool_comm)
    CALL mp_sum(MBC_Gamma_total(:,:), inter_pool_comm)
    CALL mp_barrier(inter_pool_comm)

    DEALLOCATE(uf_tmp1, STAT = ierr)
    DEALLOCATE(uf_tmp2, STAT = ierr)
    DEALLOCATE(MBC_q, STAT = ierr)
    DEALLOCATE(MBC_qm, STAT = ierr)


    ! MBC(:,:,iq) =  (ci / nktotf) * (MBC_q(:,:) - MBC_qm(:,:))


    RETURN
    !
    !-----------------------------------------------------------------------
    END SUBROUTINE MBC_diss_k


    SUBROUTINE  split_string(s, sep, parts, n)
        ! ChatGPT
        implicit none
        character(len=*), intent(in) :: s         ! input string
        character(len=*), intent(in) :: sep       ! seperator
        character(len=*), dimension(:), intent(out) :: parts  ! out put array of string
        integer, intent(out) :: n                 ! the number of output string length
    
        integer :: i, start, pos, count, len_s, len_sep
    
        len_s = len_trim(s)
        len_sep = len_trim(sep)
        start = 1
        count = 0
    
        do
            pos = index(s(start:), sep)
            if (pos == 0) then
                count = count + 1
                parts(count) = trim(s(start:))
                exit
            else
                count = count + 1
                parts(count) = trim(s(start:start+pos-2))
                start = start + pos
            end if
        end do
        n = count

    END SUBROUTINE


    subroutine eigensystem_c(JOBZ,UPLO,N,A,W)
       ! Modified from the code of Quansheng Wu' WannierTools
       ! A pack of Lapack subroutine zheev, which is 
       ! a subroutine to calculate eigenvector and eigenvalue for a 
       ! complex hermite matrix

       ! use para, only : Dp, stdout
       USE kinds,      ONLY : DP
       USE io_global,  ONLY : stdout
       implicit none

  !  JOBZ    (input) CHARACTER*1
  !          = 'N':  Compute eigenvalues only;
  !          = 'V':  Compute eigenvalues and eigenvectors.
  !
       character*1, intent(in) :: JOBZ

  !  UPLO    (input) CHARACTER*1
  !          = 'U':  Upper triangle of A is stored;
  !          = 'L':  Lower triangle of A is stored.
       character*1, intent(in) :: UPLO

  !  N       (input) INTEGER
  !          The order of the matrix A.  N >= 0.
       integer,   intent(in) :: N

  !  A       (input/output) COMPLEX*16 array, dimension (LDA, N)
  !          On entry, the Hermitian matrix A.  If UPLO = 'U', the
  !          leading N-by-N upper triangular part of A contains the
  !          upper triangular part of the matrix A.  If UPLO = 'L',
  !          the leading N-by-N lower triangular part of A contains
  !          the lower triangular part of the matrix A.
  !          On exit, if JOBZ = 'V', then if INFO = 0, A contains the
  !          orthonormal eigenvectors of the matrix A.
  !          If JOBZ = 'N', then on exit the lower triangle (if UPLO='L')
  !          or the upper triangle (if UPLO='U') of A, including the
  !          diagonal, is destroyed.

       complex(DP),intent(inout) :: A(N,N)

  !  W       (output) DOUBLE PRECISION array, dimension (N)
  !          If INFO = 0, the eigenvalues in ascending order.

       real(DP), intent(inout) :: W(N)

       integer :: info
       integer :: lwork

       real(DP),allocatable ::  rwork(:)

       complex(DP),allocatable :: work(:)

       lwork=16*N
       allocate(rwork(lwork))
       allocate( work(lwork))
       rwork= 0d0
       work= (0d0, 0d0)

       info=0
       W=0.0d0

       !> if N==1, you don't have to do the diagonalization
       if (N==1) then 
          W=A(1, 1)
          A(1, 1)= 1d0
          return
       endif

       call zheev( JOBZ, UPLO, N, A, N,  &
                W, work, lwork, rwork, info )

       if (info.ne.0) then
          write(stdout, *) 'eigensystem_c ERROR : something wrong with zheev'
          stop
       endif

       deallocate(rwork, work)
       return
    end subroutine eigensystem_c

    !-----------------------------------------------------------------------
    SUBROUTINE selfen_pl_q(iqq, iq, totq, first_cycle)
    !-----------------------------------------------------------------------
    !!
    !!  Compute the imaginary part of the electron self energy due to electron-
    !!  plasmon interaction.
    !!
    !!  The coupling coefficients have been evaluated analytically employing a
    !!  Lindhard function model for the dielectric function contribution due to
    !!  the extrinsic carriers.
    !!
    !!  There are 3 parameters that the users should provide in the input:
    !!    - DOS effective mass;
    !!    - carrier concentration (Only for doped semiconductors, it shouldn't be used for insulators);
    !!    - epsilon_infinity (e.g, from exp. or from RPA).
    !!
    !!  F. Caruso and S. Ponce - 2017
    !!
    !-----------------------------------------------------------------------
    USE kinds,         ONLY : DP
    USE io_global,     ONLY : stdout
    USE io_var,        ONLY : linewidth_elself
    USE epwcom,        ONLY : nbndsub, fsthick, ngaussw, efermi_read, &
                              fermi_energy, degaussw, nel, meff, epsiheg, &
                              restart, restart_step, nstemp
    USE pwcom,         ONLY : ef
    USE elph2,         ONLY : etf, ibndmin, ibndmax, nkqf, xqf, dmef, adapt_smearing, &
                              nkf, wqf, xkf, nkqtotf, efnew, nbndfst, nktotf,  &
                              gtemp, sigmar_all, sigmai_all, zi_all, lower_bnd
    USE constants_epw, ONLY : kelvin2eV, ryd2mev, one, ryd2ev, two, zero, ci, eps6, eps8
    USE constants,     ONLY : pi
    USE mp,            ONLY : mp_barrier, mp_sum
    USE mp_global,     ONLY : inter_pool_comm
    USE cell_base,     ONLY : omega, alat, bg
    USE mp_world,      ONLY : mpime
    USE io_global,     ONLY : ionode_id
    USE io_selfen,     ONLY : selfen_el_write
    USE poolgathering, ONLY : poolgather2
    !
    IMPLICIT NONE
    !
    LOGICAL, INTENT(inout) :: first_cycle
    !! Use to determine weather this is the first cycle after restart
    INTEGER, INTENT(in) :: iqq
    !! Q-index from the selected q
    INTEGER, INTENT(in) :: iq
    !! Q-index from the global q
    INTEGER, INTENT(in) :: totq
    !! Number of q-points in selecq window
    !
    ! Local varialbes
    CHARACTER(LEN = 20) :: tp
    !! String for temperatures
    CHARACTER(LEN = 256) :: fileselfen
    !! File name for self energy
    INTEGER :: ik
    !! Counter on k-points
    INTEGER :: ikk
    !! k-point index
    INTEGER :: ikq
    !! q-point index
    INTEGER :: ibnd
    !! Counter on bands at k
    INTEGER :: jbnd
    !! Counter on bands at k+q
    INTEGER :: fermicount
    !! Number of states on the Fermi surface
    INTEGER :: n
    !! Integer for the degenerate average over eigenstates
    INTEGER :: itemp
    !! Counter on temperatures
    INTEGER :: ierr
    !! Error status
    !
    REAL(KIND = DP) :: g2
    !! Electron-phonon matrix elements squared in Ry^2
    REAL(KIND = DP) :: ef0
    !! Fermi energy level
    REAL(KIND = DP) :: ekk
    !! Eigen energy at k on the fine grid relative to the Fermi level
    REAL(KIND = DP) :: ekk1
    !! Eigen energy at k on the fine grid relative to the Fermi level
    REAL(KIND = DP) :: ekq
    !! Eigen energy at k+q on the fine grid relative to the Fermi level
    REAL(KIND = DP) :: wq
    !! Plasmon frequency
    REAL(KIND = DP) :: etmp1
    !! Temporary variable to store etmp1 = ekk - (ekq - wq)
    REAL(KIND = DP) :: etmp2
    !! Temporary variable to strore etmp2 = ekk - (ekq + wq)
    REAL(KIND = DP) :: sq_etmp1
    !! Temporary variable to store etmp1^2
    REAL(KIND = DP) :: sq_etmp2
    !! Temporary variable to store etmp2^2
    REAL(KIND = DP) :: wgq
    !! Bose occupation factor $n_{q wpl}(T)$
    REAL(KIND = DP) :: wgkq
    !! Fermi-Dirac occupation factor $f_{nk+q}(T)$
    REAL(KIND = DP) :: fact1
    !! Temporary variable to store $f_{mk+q}(T) + n_{q wpl}(T)$
    REAL(KIND = DP) :: fact2
    !! Temporary variable to store $1 - f_{mk+q}(T) + n_{q wpl}(T)$
    REAL(KIND = DP) :: weight
    !! SE factors
    REAL(KIND = DP) :: w0g1
    !! Dirac delta at k for the imaginary part of $\Sigma$
    REAL(KIND = DP) :: w0g2
    !! Dirac delta at k+q for the imaginary part of $\Sigma$
    REAL(KIND = DP) :: inv_eptemp
    !! Inverse of temperature defined for efficiency reasons
    REAL(KIND = DP) :: inv_degaussw
    !! Inverse of degaussw defined for efficiency reasons
    REAL(KIND = DP) :: sq_degaussw
    !! Squared degaussw defined for efficiency reasons
    REAL(KIND = DP) :: g2_tmp
    !! Temporary variable defined for efficiency reasons
    REAL(KIND = DP) :: tmp1
    !! Temporary variable to store real part of Sigma for the degenerate average
    REAL(KIND = DP) :: tmp2
    !! Temporary variable to store imag part of Sigma for the degenerate average
    REAL(KIND = DP) :: tmp3
    !! Temporary variable to store Z for the degenerate average
    REAL(KIND = DP) :: tpiba_new
    !! 2 \pi / alat
    REAL(KIND = DP) :: kf
    !! Fermi wave-vector
    REAL(KIND = DP) :: vf
    !! Fermi velocity
    REAL(KIND = DP) :: fermiheg
    !! Fermi energy of a homageneous electron gas
    REAL(KIND = DP) :: qnorm
    !! |q|
    REAL(KIND = DP) :: qin
    !! (2 \pi / alat) |q|
    REAL(KIND = DP) :: sq_qin
    !! Squared qin defined for efficiency reasons
    REAL(KIND = DP) :: wpl0
    !! Plasmon frequency
    REAL(KIND = DP) :: eps0
    !! Dielectric function at zero frequency
    REAL(KIND = DP) :: deltaeps
    !!
    REAL(KIND = DP) :: qcut
    !! Cut-off of the maximum wave-vector of plasmon modes (qcut = wpl0 / vf)
    REAL(KIND = DP) :: qtf
    !! Thomas-Fermi screening wave-vector
    REAL(KIND = DP) :: dipole
    !! Dipole
    REAL(KIND = DP) :: rs
    !! Spherical radius used to describe the density of an electron gas
    REAL(KIND = DP) :: degen
    !! Degeneracy of the electron gas
    REAL(KIND = DP), EXTERNAL :: wgauss
    !! Fermi-Dirac distribution function (when -99)
    REAL(KIND = DP), EXTERNAL :: w0gauss
    !! This function computes the derivative of the Fermi-Dirac function
    !! It is therefore an approximation for a delta function
    REAL(KIND = DP) :: q(3)
    !! The q-point in cartesian unit.
    REAL(KIND = DP) :: sigmar_tmp(nbndfst)
    !! Temporary array to store the real-part of Sigma
    REAL(KIND = DP) :: sigmai_tmp(nbndfst)
    !! Temporary array to store the imag-part of Sigma
    REAL(KIND = DP) :: zi_tmp(nbndfst)
    !! Temporary array to store the Z
    REAL(KIND = DP), ALLOCATABLE :: xkf_all(:, :)
    !! Collect k-point coordinate from all pools in parallel case
    REAL(KIND = DP), ALLOCATABLE :: etf_all(:, :)
    !! Collect eigenenergies from all pools in parallel case
    !
    IF (adapt_smearing) CALL errore('selfen_pl_q', 'adapt_smearing cannot be used with plasmon self-energy', 1)
    !
    !
    DO itemp = 1, nstemp
      ! SP: Define the inverse so that we can efficiently multiply instead of dividing
      inv_eptemp   = one / gtemp(itemp)
      inv_degaussw = one / degaussw
      sq_degaussw  = degaussw * degaussw
      !
      IF (iqq == 1) THEN
        !
        WRITE(stdout, '(/5x, a)') REPEAT('=', 67)
        WRITE(stdout, '(5x, "Electron-plasmon Self-Energy in the Migdal Approximation")')
        WRITE(stdout, '(5x, a/)') REPEAT('=', 67)
        !
        IF (fsthick < 1.d3) WRITE(stdout, '(/5x, a, f10.6, a)' ) 'Fermi Surface thickness = ', fsthick * ryd2ev, ' eV'
        WRITE(stdout, '(/5x, a, f10.6, a)' ) 'Golden Rule strictly enforced with T = ', gtemp(itemp) * ryd2ev, ' eV'
        !
      ENDIF
      !
      ! Fermi level
      !
      IF (efermi_read) THEN
        ef0 = fermi_energy
      ELSE
        ef0 = efnew
      ENDIF
      !
      IF (iqq == 1) THEN
        WRITE (stdout, 100) degaussw * ryd2ev, ngaussw
        WRITE (stdout,'(a)') ' '
      ENDIF
      !
      !nel      =  0.01    ! this should be read from input - # of doping electrons
      !epsiheg  =  12.d0   ! this should be read from input - # dielectric constant at zero doping
      !meff     =  0.25    ! this should be read from input - effective mass
      !
      tpiba_new = two * pi / alat
      degen     = one
      !
      ! Based on Eqs. (5.3)-(5.6) and (5.127) of Mahan 2000.
      !
      ! omega is the unit cell volume in Bohr^3
      rs = (3.d0 / (4.d0 * pi * nel / omega / degen))**(1.d0 / 3.d0) * meff * degen
      kf = (3.d0 * (pi**2.d0) * nel / omega / degen)**(1.d0 / 3.d0)
      vf = (1.d0 / meff) * kf
      !
      ! fermiheg in [Ry] (multiplication by 2 converts from Ha to Ry)
      fermiheg = 2.d0 * (1.d0 / (2.d0 * meff)) * kf**2.d0
      ! qtf in ! [a.u.]
      qtf = DSQRT(6.d0 * pi * nel / omega / degen / (fermiheg / 2.d0))
      ! wpl0 in [Ry] (multiplication by 2 converts from Ha to Ry)
      wpl0 = two * DSQRT(4.d0 * pi * nel / omega / meff / epsiheg)
      wq = wpl0
      !
      q(:) = xqf(:, iq)
      CALL cryst_to_cart(1, q, bg, 1)
      qnorm = DSQRT(q(1)**two + q(2)**two + q(3)**two)
      qin = qnorm * tpiba_new
      sq_qin = qin * qin
      !
      ! qcut in [Ha] (1/2 converts from Ry to Ha)
      qcut = wpl0 / vf / tpiba_new / 2.d0
      !
      !IF (.TRUE.) qcut = qcut / 2.d0 ! renormalize to account for Landau damping
      !
      ! qin should be in atomic units for Mahan formula
      CALL get_eps_mahan(qin, rs, kf, eps0)
      deltaeps = -(1.d0 / (epsiheg + eps0 - 1.d0) - 1.d0 / epsiheg)
      !
      g2_tmp = 4.d0 * pi * (wq * deltaeps / 2.d0) / omega * 2.d0
      !
      IF (iqq == 1) THEN
        WRITE(stdout, '(12x, " nel       = ", E15.6)') nel
        WRITE(stdout, '(12x, " meff      = ", E15.6)') meff
        WRITE(stdout, '(12x, " rs        = ", E15.6)') rs
        WRITE(stdout, '(12x, " kf        = ", E15.6)') kf
        WRITE(stdout, '(12x, " vf        = ", E15.6)') vf
        WRITE(stdout, '(12x, " fermi_en  = ", E15.6)') fermiheg
        WRITE(stdout, '(12x, " qtf       = ", E15.6)') qtf
        WRITE(stdout, '(12x, " wpl       = ", E15.6)') wpl0
        WRITE(stdout, '(12x, " qcut      = ", E15.6)') qcut
        WRITE(stdout, '(12x, " eps0      = ", E15.6)') eps0
        WRITE(stdout, '(12x, " epsiheg   = ", E15.6)') epsiheg
        WRITE(stdout, '(12x, " deltaeps  = ", E15.6)') deltaeps
      ENDIF
      !
      IF (restart) THEN
        ! Make everythin 0 except the range of k-points we are working on
        sigmar_all(:, 1:lower_bnd - 1, :) = zero
        sigmar_all(:, lower_bnd + nkf:nktotf, :) = zero
        sigmai_all(:, 1:lower_bnd - 1, :) = zero
        sigmai_all(:, lower_bnd + nkf:nktotf, :) = zero
        zi_all(:, 1:lower_bnd - 1, :) = zero
        zi_all(:, lower_bnd + nkf:nktotf, :) = zero
        !
      ENDIF
      !
      ! In the case of a restart do not add the first step
      IF (first_cycle .and. itemp == nstemp) THEN
        first_cycle = .FALSE.
      ELSE
        IF (qnorm < qcut) THEN
          !
          ! wq is the plasmon frequency
          ! Bose occupation factor
          wgq = wgauss(-wq * inv_eptemp, -99)
          wgq = wgq / (one - two * wgq)
          !
          ! loop over all k points of the fine mesh
          !
          fermicount = 0
          DO ik = 1, nkf
            !
            ikk = 2 * ik - 1
            ikq = ikk + 1
            !
            ! here we must have ef, not ef0, to be consistent with ephwann_shuffle
            ! (but in this case they are the same)
            !
            IF ((MINVAL(ABS(etf(:, ikk) - ef)) < fsthick) .AND. &
                (MINVAL(ABS(etf(:, ikq) - ef)) < fsthick)) THEN
              !
              fermicount = fermicount + 1
              !
              DO ibnd = 1, nbndfst
                !
                !  the energy of the electron at k (relative to Ef)
                ekk = etf(ibndmin - 1 + ibnd, ikk) - ef0
                !
                DO jbnd = 1, nbndfst
                  !
                  ekk1 = etf(ibndmin - 1 + jbnd, ikk) - ef0
                  ! the energy of the electron at k+q (relative to Ef)
                  ekq = etf(ibndmin - 1 + jbnd, ikq) - ef0
                  ! the Fermi occupation at k+q
                  wgkq = wgauss(-ekq * inv_eptemp, -99)
                  !
                  ! Computation of the dipole
                  IF (ibnd == jbnd) THEN
                    IF (qnorm > eps8) THEN
                      dipole = one / sq_qin
                    ELSE
                      dipole = zero
                    ENDIF
                  ELSE
                    IF (ABS(ekk - ekk1) > eps8) THEN
                      ! TODO: Check the expression to confirm that division by 2 is correct.
                      dipole = REAL(      dmef(1, ibndmin - 1 + jbnd, ibndmin - 1 + ibnd, ikk) / 2.d0 *  &
                                    CONJG(dmef(1, ibndmin - 1 + jbnd, ibndmin - 1 + ibnd, ikk) / 2.d0) / &
                                    ((ekk1 - ekk)**two + sq_degaussw))
                    ELSE
                      dipole = zero
                    ENDIF
                  ENDIF
                  !
                  IF (ABS(dipole * sq_qin) > 1.d0) THEN
                    dipole = one / sq_qin
                  ENDIF
                  !
                  ! The q^-2 is cancelled by the q->0 limit of the dipole.
                  ! See e.g., pg. 258 of Grosso Parravicini.
                  ! electron-plasmon scattering matrix elements squared
                  g2 = dipole * g2_tmp
                  !
                  fact1 =       wgkq + wgq
                  fact2 = one - wgkq + wgq
                  etmp1 = ekk - (ekq - wq)
                  etmp2 = ekk - (ekq + wq)
                  sq_etmp1 = etmp1 * etmp1
                  sq_etmp2 = etmp2 * etmp2
                  !
                  weight = wqf(iq) * REAL(fact1 / (etmp1 - ci * degaussw) + fact2 / (etmp2 - ci * degaussw))
                  !
                  ! \Re\Sigma [Eq. 1 in PRB 94, 115208 (2016)]
                  sigmar_all(ibnd, ik + lower_bnd - 1, itemp) = sigmar_all(ibnd, ik + lower_bnd - 1, itemp) + g2 * weight
                  !
                  ! Delta implementation
                  w0g1 = w0gauss(etmp1 * inv_degaussw, 0) * inv_degaussw
                  w0g2 = w0gauss(etmp2 * inv_degaussw, 0) * inv_degaussw
                  !
                  weight = pi * wqf(iq) * (fact1 * w0g1 + fact2 * w0g2)
                  !
                  ! \Im\Sigma using delta approx. [Eq. 1 in PRB 94, 115208 (2016)]
                  sigmai_all(ibnd, ik + lower_bnd - 1, itemp) = sigmai_all(ibnd, ik + lower_bnd - 1, itemp) + g2 * weight
                  !
                  ! Z FACTOR: -\frac{\partial\Re\Sigma}{\partial\omega}
                  !
                  weight = wqf(iq) * &
                          (fact1 * (sq_etmp1 - sq_degaussw) / (sq_etmp1 + sq_degaussw)**two +  &
                           fact2 * (sq_etmp2 - sq_degaussw) / (sq_etmp2 + sq_degaussw)**two)
                  !
                  zi_all(ibnd, ik + lower_bnd - 1, itemp) = zi_all(ibnd, ik + lower_bnd - 1, itemp) + g2 * weight
                  !
                ENDDO !jbnd
              ENDDO !ibnd
            ENDIF ! endif  fsthick
          ENDDO ! end loop on k
        ENDIF ! endif qnorm
        !
        ! Creation of a restart point
        IF (restart) THEN
          IF (MOD(iqq, restart_step) == 0 .and. itemp == nstemp) THEN
            WRITE(stdout, '(5x, a, i10)' ) 'Creation of a restart point at ', iqq
            CALL mp_sum(sigmar_all, inter_pool_comm)
            CALL mp_sum(sigmai_all, inter_pool_comm)
            CALL mp_sum(zi_all, inter_pool_comm)
            CALL mp_sum(fermicount, inter_pool_comm)
            CALL mp_barrier(inter_pool_comm)
            CALL selfen_el_write(iqq, totq, nktotf, sigmar_all, sigmai_all, zi_all)
          ENDIF
        ENDIF
      ENDIF ! in case of restart, do not do the first one
      !
    ENDDO ! itemp
    !
    ! The k points are distributed among pools: here we collect them
    !
    IF (iqq == totq) THEN
      !
      ALLOCATE(xkf_all(3, nkqtotf), STAT = ierr)
      IF (ierr /= 0) CALL errore('selfen_pl_q', 'Error allocating xkf_all', 1)
      ALLOCATE(etf_all(nbndsub, nkqtotf), STAT = ierr)
      IF (ierr /= 0) CALL errore('selfen_pl_q', 'Error allocating etf_all', 1)
      xkf_all(:, :) = zero
      etf_all(:, :) = zero
      !
#if defined(__MPI)
      !
      ! note that poolgather2 works with the doubled grid (k and k+q)
      !
      CALL poolgather2(3, nkqtotf, nkqf, xkf, xkf_all)
      CALL poolgather2(nbndsub, nkqtotf, nkqf, etf, etf_all)
      CALL mp_sum(sigmar_all, inter_pool_comm)
      CALL mp_sum(sigmai_all, inter_pool_comm)
      CALL mp_sum(zi_all, inter_pool_comm)
      CALL mp_sum(fermicount, inter_pool_comm)
      CALL mp_barrier(inter_pool_comm)
#else
      !
      xkf_all = xkf
      etf_all = etf
      !
#endif
      !
      DO itemp = 1, nstemp
        !
        ! Average over degenerate eigenstates:
        WRITE(stdout, '(5x, "Average over degenerate eigenstates is performed")')
        WRITE(stdout, '(5x, a, f8.3, a)') "Temperature: ", gtemp(itemp) * ryd2ev / kelvin2eV, "K"
        !
        DO ik = 1, nktotf
          ikk = 2 * ik - 1
          ikq = ikk + 1
          !
          DO ibnd = 1, nbndfst
            ekk = etf_all(ibndmin - 1 + ibnd, ikk)
            n = 0
            tmp1 = zero
            tmp2 = zero
            tmp3 = zero
            DO jbnd = 1, nbndfst
              ekk1 = etf_all(ibndmin - 1 + jbnd, ikk)
              IF (ABS(ekk1 - ekk) < eps6) THEN
                n = n + 1
                tmp1 = tmp1 + sigmar_all(jbnd, ik, itemp)
                tmp2 = tmp2 + sigmai_all(jbnd, ik, itemp)
                tmp3 = tmp3 + zi_all(jbnd, ik, itemp)
              ENDIF
              !
            ENDDO ! jbnd
            sigmar_tmp(ibnd) = tmp1 / FLOAT(n)
            sigmai_tmp(ibnd) = tmp2 / FLOAT(n)
            zi_tmp(ibnd)     = tmp3 / FLOAT(n)
            !
          ENDDO ! ibnd
          sigmar_all(:, ik, itemp) = sigmar_tmp(:)
          sigmai_all(:, ik, itemp) = sigmai_tmp(:)
          zi_all(:, ik, itemp)     = zi_tmp(:)
          !
        ENDDO ! nktotf
        !
        ! Output plasmon SE here after looping over all q-points (with their contributions summed in sigmar_all, etc.)
        !
        WRITE(stdout, '(5x, "WARNING: only the eigenstates within the Fermi window are meaningful")')
        !
        IF (mpime == ionode_id) THEN
          ! Write to file
          WRITE(tp, "(f8.3)") gtemp(itemp) * ryd2ev / kelvin2eV
          fileselfen = 'linewidth.plself.' // trim(adjustl(tp)) // 'K'
          OPEN(UNIT = linewidth_elself, FILE = fileselfen)
          WRITE(linewidth_elself, '(a)') '# Electron lifetime (meV)'
          WRITE(linewidth_elself, '(a)') '#      ik       ibnd                 E(ibnd)      Im(Sigma)(meV)'
          !
          DO ik = 1, nktotf
            !
            ikk = 2 * ik - 1
            ikq = ikk + 1
            !
            WRITE(stdout, '(/5x, "ik = ", i7, " coord.: ", 3f12.7)') ik, xkf_all(:, ikk)
            WRITE(stdout, '(5x, a)') REPEAT('-', 67)
            !
            DO ibnd = 1, nbndfst
              !
              ! note that ekk does not depend on q
              ekk = etf_all(ibndmin - 1 + ibnd, ikk) - ef0
              !
              ! calculate Z = 1 / ( 1 -\frac{\partial\Sigma}{\partial\omega} )
              zi_all(ibnd, ik, itemp) = one / (one + zi_all(ibnd, ik, itemp))
              !
              WRITE(stdout, 102) ibndmin - 1 + ibnd, ryd2ev * ekk, ryd2mev * sigmar_all(ibnd, ik, itemp), &
                                 ryd2mev * sigmai_all(ibnd, ik, itemp), zi_all(ibnd, ik, itemp), &
                                 one / zi_all(ibnd, ik, itemp) - one
              WRITE(linewidth_elself, '(i9, 2x)', ADVANCE = 'no') ik
              WRITE(linewidth_elself, '(i9, 2x)', ADVANCE = 'no') ibndmin - 1 + ibnd
              WRITE(linewidth_elself, '(E22.14, 2x)', ADVANCE = 'no') ryd2ev * ekk
              WRITE(linewidth_elself, '(E22.14, 2x)') ryd2mev * sigmai_all(ibnd, ik, itemp)
              !
            ENDDO
            WRITE(stdout, '(5x, a/)') REPEAT('-', 67)
          ENDDO
          CLOSE(linewidth_elself)
        ENDIF
        !
      ENDDO ! itemp
      !
      DEALLOCATE(xkf_all, STAT = ierr)
      IF (ierr /= 0) CALL errore('selfen_pl_q', 'Error deallocating xkf_all', 1)
      DEALLOCATE(etf_all, STAT = ierr)
      IF (ierr /= 0) CALL errore('selfen_pl_q', 'Error deallocating etf_all', 1)
      !
    ENDIF
    !
    100 FORMAT(5x, 'Gaussian Broadening: ', f10.6, ' eV, ngauss=', i4)
    102 FORMAT(5x, 'E( ', i3, ' )=', f9.4, ' eV   Re[Sigma]=', f15.6, ' meV Im[Sigma]=', &
               f15.6, ' meV     Z=', f15.6, ' lam=', f15.6)
    !
    RETURN
    !
    !--------------------------------------------------------------------------
    END SUBROUTINE selfen_pl_q
    !--------------------------------------------------------------------------
    !
    !--------------------------------------------------------------------------
    SUBROUTINE get_eps_mahan(q, rs, kf, eps0)
    !--------------------------------------------------------------------------
    !!
    !! Based on Eq. 5.166 of Mahan 2000.
    !!
    USE kinds,         ONLY : DP
    USE constants_epw, ONLY : eps6, eps10
    USE constants,     ONLY : pi
    !
    IMPLICIT NONE
    !
    REAL(KIND = DP), INTENT(out) :: eps0
    !! Output dielectric function at zero frequency
    REAL(KIND = DP), INTENT(in) ::  q
    !! Norm of q wave-vector
    REAL(KIND = DP), INTENT(in) :: rs
    !! Spherical radius used to describe the density of an electron gas
    REAL(KIND = DP), INTENT(in) :: kf
    !! Fermi wave-vector
    !
    !Local variable
    REAL(KIND = DP) :: x
    !! Temporary variable for q / (2 kf)
    REAL(KIND = DP) :: alpha
    !!Temporary variable
    !
    alpha = (4.d0 / (9.d0 * pi))**(1.d0/3.d0)
    !
    IF (ABS(q) > eps10) THEN
      x    = q / (2.d0 * kf)
      eps0 = 1.d0 + (1.d0 - x**2.d0) / (2.d0 * x) * LOG(ABS((1.d0 + x)/(1.d0 - x)))
      eps0 = 1.d0 + alpha * rs * eps0 / (2.d0 * pi * (x**2.d0))
    ELSE
      x    = (q + eps6) / 2.d0 / kf
      eps0 = 1.d0 + (1.d0 - x**2.d0) / (2.d0 * x) * LOG(ABS((1.d0 + x) / (1.d0 - x)))
      eps0 = 1.d0 + alpha * rs / 2.d0 / pi / x**2.d0 * eps0
    ENDIF
    !
    !--------------------------------------------------------------------------
    END SUBROUTINE get_eps_mahan
    !--------------------------------------------------------------------------
    !
    !-----------------------------------------------------------------------
    FUNCTION dos_ef_seq(ngauss, degauss, ef, et, wk, nks, nbnd)
    !-----------------------------------------------------------------------
    !
    USE kinds, ONLY : DP
    USE mp,    ONLY : mp_sum
    USE constants_epw, ONLY : zero
    !
    IMPLICIT NONE
    !
    INTEGER, INTENT(in) :: ngauss
    !! Number of smearing
    INTEGER, INTENT(in) :: nbnd
    !! Total number of bands considered
    INTEGER, INTENT(in) :: nks
    !!  Number of kpoints
    REAL(KIND = DP), INTENT(in) :: et(nbnd, nks)
    !! Eigenenergies
    REAL(KIND = DP), INTENT(in) :: wk(nks)
    !! K-point weights
    REAL(KIND = DP), INTENT(in) :: ef
    !! Fermi level
    REAL(KIND = DP), INTENT(in) :: degauss
    !! Smearing value
    !
    REAL(KIND = DP) :: dos_ef_seq
    !! Output of the function
    !
    ! Local variables
    INTEGER :: ik
    !! K-point value
    INTEGER :: ibnd
    !! Band number
    REAL(KIND = DP), EXTERNAL :: w0gauss
    !! Fermi-Dirac function
    !
    ! Compute DOS at E_F (states per Ry per unit cell)
    !
    dos_ef_seq = zero
    DO ik = 1, nks
      DO ibnd = 1, nbnd
        dos_ef_seq = dos_ef_seq + wk(ik) * w0gauss((et(ibnd, ik) - ef) / degauss, ngauss) / degauss
      ENDDO
    ENDDO
    !
    RETURN
    !-----------------------------------------------------------------------
    END FUNCTION dos_ef_seq
    !-----------------------------------------------------------------------
    !
    !-----------------------------------------------------------------------
    SUBROUTINE nesting_fn_q(iqq, iq)
    !-----------------------------------------------------------------------
    !!
    !! Compute the imaginary part of the phonon self energy due to electron-
    !! phonon interaction in the Migdal approximation. This corresponds to
    !! the phonon linewidth (half width). The phonon frequency is taken into
    !! account in the energy selection rule.
    !!
    !! Use matrix elements, electronic eigenvalues and phonon frequencies
    !! from ep-wannier interpolation.
    !!
    !-----------------------------------------------------------------------
    USE kinds,     ONLY : DP
    USE io_global, ONLY : stdout
    USE epwcom,    ONLY : nbndsub, fsthick, ngaussw, degaussw, &
                          nsmear, delta_smear, efermi_read, fermi_energy
    USE pwcom,     ONLY : ef
    USE elph2,     ONLY : ibndmin, etf, wkf, xqf, wqf, nkqf, nktotf, &
                          nkf, xqf, nbndfst, efnew
    USE constants_epw, ONLY : ryd2ev, zero, one, two
    USE mp,        ONLY : mp_barrier, mp_sum
    USE mp_global, ONLY : inter_pool_comm
    !
    IMPLICIT NONE
    !
    INTEGER, INTENT(in) :: iqq
    !! Current q-point index from selecq
    INTEGER, INTENT(in) :: iq
    !! Current q-point index
    !
    ! Local variables
    INTEGER :: ik
    !! Counter on the k-point index
    INTEGER :: ikk
    !! k-point index
    INTEGER :: ikq
    !! q-point index
    INTEGER :: ibnd
    !! Counter on bands
    INTEGER :: jbnd
    !! Counter on bands
    INTEGER :: fermicount
    !! Number of states on the Fermi surface
    INTEGER :: ismear
    !! Counter on smearing values
    !
    REAL(KIND = DP) :: ekk
    !! Eigen energy on the fine grid relative to the Fermi level
    REAL(KIND = DP) :: ekq
    !! Eigen energy of k+q on the fine grid relative to the Fermi level
    REAL(KIND = DP) :: ef0
    !! Fermi energy level
    REAL(KIND = DP) :: weight
    !! Imaginary part of the phonhon self-energy factor, sans e-ph matrix elements
    REAL(KIND = DP) :: dosef
    !! Density of state N(Ef)
    REAL(KIND = DP) :: w0g1
    !! Dirac delta at k for the imaginary part of $\Sigma$
    REAL(KIND = DP) :: w0g2
    !! Dirac delta at k+q for the imaginary part of $\Sigma$
    REAL(KIND = DP) :: degaussw0
    !! degaussw0 = (ismear-1) * delta_smear + degaussw
    REAL(KIND = DP) :: inv_degaussw0
    !! Inverse degaussw0 for efficiency reasons
    REAL(KIND = DP) :: gamma
    !! Nesting function
    REAL(KIND = DP) :: dos_ef
    !! Function returning the density of states at the Fermi level
    REAL(KIND = DP) :: w0gauss
    !! This function computes the derivative of the Fermi-Dirac function
    !! It is therefore an approximation for a delta function
    !
    IF (iqq == 1) THEN
      WRITE(stdout, '(/5x, a)') REPEAT('=', 67)
      WRITE(stdout, '(5x, "Nesting Function in the double delta approx")')
      WRITE(stdout, '(5x, a/)') REPEAT('=', 67)
      !
      IF (fsthick < 1.d3) WRITE(stdout, '(/5x, a, f10.6, a)' ) &
        'Fermi Surface thickness = ', fsthick * ryd2ev, ' eV'
    ENDIF
    !
    ! SP: The Gamma function needs to be put to 0 for each q
    gamma = zero
    !
    ! Here we loop on smearing values
    DO ismear = 1, nsmear
      !
      degaussw0 = (ismear - 1) * delta_smear + degaussw
      inv_degaussw0 = one / degaussw0
      !
      ! Fermi level and corresponding DOS
      !
      !   Note that the weights of k+q points must be set to zero here
      !   no spin-polarized calculation here
      IF (efermi_read) THEN
        ef0 = fermi_energy
      ELSE
        ef0 = efnew
      ENDIF
      !
      dosef = dos_ef(ngaussw, degaussw0, ef0, etf, wkf, nkqf, nbndsub)
      !  N(Ef) in the equation for lambda is the DOS per spin
      dosef = dosef / two
      !
      IF (iqq == 1) THEN
        WRITE(stdout, 100) degaussw0 * ryd2ev, ngaussw
        WRITE(stdout, 101) dosef / ryd2ev, ef0 * ryd2ev
      ENDIF
      !
      !
      CALL start_clock('nesting')
      !
      fermicount = 0
      DO ik = 1, nkf
        !
        ikk = 2 * ik - 1
        ikq = ikk + 1
        !
        ! here we must have ef, not ef0, to be consistent with ephwann_shuffle
        IF ((MINVAL(ABS(etf(:, ikk) - ef)) < fsthick) .AND. &
            (MINVAL(ABS(etf(:, ikq) - ef)) < fsthick)) then
          !
          fermicount = fermicount + 1
          !
          DO ibnd = 1, nbndfst
            !
            ekk = etf(ibndmin - 1 + ibnd, ikk) - ef0
            w0g1 = w0gauss(ekk * inv_degaussw0, 0) * inv_degaussw0
            !
            DO jbnd = 1, nbndfst
              !
              ekq = etf(ibndmin - 1 + jbnd, ikq) - ef0
              w0g2 = w0gauss(ekq *inv_degaussw0, 0) * inv_degaussw0
              !
              ! = k-point weight * [f(E_k) - f(E_k+q)]/ [E_k+q - E_k -w_q +id]
              ! This is the imaginary part of the phonon self-energy, sans the matrix elements
              !
              ! weight = wkf (ikk) * (wgkk - wgkq) * &
              !      aimag ( cone / ( ekq - ekk  - ci * degaussw ) )
              !
              ! the below expression is positive-definite, but also an approximation
              ! which neglects some fine features
              !
              weight = wkf(ikk) * w0g1 * w0g2
              !
              gamma  = gamma  + weight
              !
            ENDDO ! jbnd
          ENDDO ! ibnd
        ENDIF ! endif fsthick
      ENDDO ! loop on k
      !
      ! collect contributions from all pools (sum over k-points)
      ! this finishes the integral over the BZ  (k)
      !
      CALL mp_sum(gamma, inter_pool_comm)
      CALL mp_sum(fermicount, inter_pool_comm)
      CALL mp_barrier(inter_pool_comm)
      !
      WRITE(stdout, '(/5x, "iq = ",i5," coord.: ", 3f9.5, " wt: ", f9.5)') iq, xqf(:, iq) , wqf(iq)
      WRITE(stdout, '(5x, a)') REPEAT('-', 67)
      !
      WRITE(stdout, 102) gamma
      WRITE(stdout, '(5x,a/)') REPEAT('-', 67)
      !
      WRITE(stdout, '(/5x, a, i8, a, i8/)') &
        'Number of (k,k+q) pairs on the Fermi surface: ', fermicount, ' out of ', nktotf
      !
      CALL stop_clock('nesting')
    ENDDO !smears
    !
100 FORMAT(5x, 'Gaussian Broadening: ', f7.3,' eV, ngauss=', i4)
101 FORMAT(5x, 'DOS =', f10.6, ' states/spin/eV/Unit Cell at Ef=', f10.6, ' eV')
102 FORMAT(5x, 'Nesting function (q)=', E15.6, ' [Adimensional]')
    !
    !-----------------------------------------------------------------------
    END SUBROUTINE nesting_fn_q
    !-----------------------------------------------------------------------

  !-----------------------------------------------------------------------
  END MODULE selfen
  !-----------------------------------------------------------------------
